import java.io.*;
import java.util.*;

public class Staff {
	private String id;
	private String staffName;
	private String DoH;
	private String position;
	private String pw;
	private int number;
	
	
	public String getId()
	{
		return id;
	}
	public String getStaffName()
	{
		return staffName;
	}
	
	public String getDoH()
	{
		return DoH;
	}
	
	public String getPosition()
	{
		return position;
	}
	
	public String getPw()
	{
		return pw;
	}
	
	public int getNum()
	{
		return number;
	}
	
	public Staff(String theId, String theName, String theDate, String thePost, String thePw)
	{
	    this.staffName = theName;
	    this.id = theId;
	    this.DoH = theDate;
	    this.position = thePost;
	    this.pw = thePw;
	}
	
	public Staff(String theId, String theName, String theDate, String thePost, String thePw, int theNumber)
	{
	    this.staffName = theName;
	    this.id = theId;
	    this.DoH = theDate;
	    this.position = thePost;
	    this.pw = thePw;
	    this.number = theNumber;
	}
	
	public void setName(String aName)
	{
		staffName=aName;
	}
	
	public void setPost(String aPost)
	{
		position=aPost;
	}
	
	public void setID(String aID)
	{
		id= aID;
	}
	
	public static void viewAndEditAvailableTime(String aName, ArrayList<Stylist> stylistList)
	{
		boolean repeat = true;
		String choice;
		String dateAndTime = LoginSystemForStaff.CurrentDateAndTimeToString();
		do
		{
			System.out.println("--------------------------------------------------------------------------------------------------------------------");
	        System.out.println("Time Slots Management\t\t\t\t\t\t\t\t\t\t" + dateAndTime);
	        System.out.println("--------------------------------------------------------------------------------------------------------------------");
	        
			Scanner input = new Scanner(System.in);
			System.out.println("<1> View My Available Time Slots");
			System.out.println("<2> Add My Available Time Slot");
			System.out.println("<3> Back To Menu");
			System.out.println("Enter your choice: ");
			choice = input.next();
			
			if(choice.equals("1"))
			{
				for (Stylist stylist : stylistList) 
			    {
			        if (stylist.getName().equals(aName))
			        {
			        	System.out.println("Available TimeSlots:");
			        	System.out.println(stylist.getAvailableTimeSlots());
			        }
			    }
			}
			
			else if(choice.equals("2"))
			{
				System.out.println("Enter the date you want to add(yyyy-mm-dd):");
				String newDate = input.next();
				//input.next();
				System.out.println("Enter the time you want to add(HH:mm):");
				String newTime = input.next();
				//input.next();
				
				for (Stylist stylist : stylistList) 
			    {
			        if (stylist.getName().equals(aName))
			        {
			        	
			        	stylist.addAvailableTimeSlots(newDate);
			        	stylist.addAvailableTimeSlots(newTime);
			        	stylist.saveStylistsToFile(stylistList);
			        	repeat = false;
			        }
			    }
		
				
			}
			else if(choice.equals("3"))
			{
				repeat = false;
			}
			else
			{
				if (!choice.equals("1") && !choice.equals("2"))
				{
					System.out.println("Invalid option, Please try again...");
					repeat = true;
				}
			}

		}while(repeat == true);
		
	}
	
	
	public static void viewScheduledTimeSlot(String aName, ArrayList<Stylist>stylistList, ArrayList<Appointment>appointmentList)
	{
		String dateAndTime = LoginSystemForStaff.CurrentDateAndTimeToString();
		
		System.out.println("--------------------------------------------------------------------------------------------------------------------");
        System.out.println("Scheduled Time Slots\t\t\t\t\t\t\t\t\t\t" + dateAndTime);
        System.out.println("--------------------------------------------------------------------------------------------------------------------");
        System.out.println();
        
		ArrayList<Appointment> customerAppointments = new ArrayList<>();
		 for (Appointment appointment : appointmentList) 
	     {
			 if (appointment.getStylistName().equals(aName)) 
	         {
	                customerAppointments.add(appointment);
	         }
	     }
		 
		 if (customerAppointments.isEmpty()) 
	     {
			 System.out.println("No appointments found.");
	         return;
	     }
		 
		 System.out.println("Your Appoinments for this week:");
		 for (int i = 0; i < customerAppointments.size(); i++) 
	        {
	            Appointment appointment = customerAppointments.get(i);
	            System.out.println((i + 1) + ". Date: " + appointment.getDate() +
	                    "\t Time: " + appointment.getTime() +
	                    "\tCustomer Name: " + appointment.getCustomerName() + "\t\t\t\t\tSelected Package: " + appointment.getSelectedPackage());
	        }
		 
	}

	public static ArrayList<Staff> loadStaffListFromFile(String aName) //read staff list from StaffList.txt
	{
		int number = 1;
		ArrayList<Staff> staff = new ArrayList<Staff>();
		try
		{
			File myFile = new File ("StaffList.txt");
			Scanner inputFile = new Scanner(myFile);
			
			while (inputFile.hasNext())
			{
				String str = inputFile.nextLine();
				String[] parts = str.split(",");
				if(!parts[1].equals(aName))
				{
					number++;
				}
				else
				{
					staff.add(new Staff(parts[0], parts[1], parts[2], parts[3], parts[4], number)); 
					return staff;
				}
				
			}
			inputFile.close();
		}
		catch(FileNotFoundException ex)
		{
			System.out.print("error");
		}
		
		
		return staff;
	}
	
	public static void editAndSaveLine(String filePath, int lineToEdit, String newText)
    {
        try 
        {
        	Scanner input = new Scanner(System.in);
            // Read the original content into memory
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            StringBuilder content = new StringBuilder();
            String line;
           
            int lineNumber = 0;

            while ((line = reader.readLine()) != null) 
            {
                lineNumber++;

                if (lineNumber == lineToEdit) {
                    // Replace the line you want to edit with the new text
                    content.append(newText).append("\n");
                } else {
                    // Keep other lines unchanged
                    content.append(line).append("\n");
                }
            }

            reader.close();

            // Write the modified content back to the file
            PrintWriter writer = new PrintWriter(new FileWriter(filePath));
            writer.write(content.toString());
            writer.close();

            System.out.println("Data edited and saved.");
            System.out.println("Please Login again...");
            input.nextLine();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
	
	public static boolean DisplayProfile(ArrayList<Staff> staffList, String staffFile)
	{
		Scanner input = new Scanner(System.in);
		boolean progress = true;
		
		String dateAndTime = LoginSystemForStaff.CurrentDateAndTimeToString();
		
		System.out.println("--------------------------------------------------------------------------------------------------------------------");
        System.out.println("Profile\t\t\t\t\t\t\t\t\t\t\t\t" + dateAndTime);
        System.out.println("--------------------------------------------------------------------------------------------------------------------");
        System.out.print("Staff ID for Verification: ");
        for(Staff staffs : staffList)
		{
			String id = staffs.getId();
			String name = staffs.getStaffName();
			String DoH = staffs.getDoH();
			String position = staffs.getPosition();
			String password = staffs.getPw();
			int number = staffs.getNum();
			
			String verification = input.next(); //change after discussion
			input.nextLine();

			
	        if (!verification.equals(id))
	        {
	            System.out.println("Wrong ID Entered");
	        } 
	        else 
	        {
	        	System.out.println();
	            System.out.println("Staff ID: " + id);
	            System.out.println("Name: " + name);
	            System.out.println("Date of Hire: " + DoH);
	            System.out.println("Position: " + position);
	            System.out.println();
	           
	            String choice;
	            do
	            {
	            	System.out.print("Edit Profile ( <Y>es / <N>o ): ");
		            choice = input.next();
		            choice = choice.toUpperCase();
		            input.nextLine();
		            
		            if (choice.equals("Y")) 
		            {
		    			
		            	System.out.println("--------------------------------------------------------------------");
		                System.out.println("Please Enter Your Latest Information");
		                System.out.println("--------------------------------------------------------------------");
		                
		                System.out.print("Name: ");
		                String newName = input.nextLine();
		                System.out.print("Position: ");
		                String newPost = input.nextLine();
		                String newText = (verification + "," + newName + "," + DoH + "," + newPost + "," + password);
		                
		                editAndSaveLine("StaffList.txt", number, newText);
		                
		                progress = false;
		            }
		            else if(choice.equals("N"))
		            {
		            	progress = true;
		            }
		            else
		            {
		            	if (!choice.equals("Y") && !choice.equals("N"))
		            	{
		            		System.out.println("Invalid option, Please try again...");
		            	}
		            }
	            }while(!choice.equals("Y") && !choice.equals("N"));
	            
	        }
	        
		} 
        return progress;
	}
	
}