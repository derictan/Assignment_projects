import java.util.*;
import java.io.*;
import java.io.IOException;

public class Appointment 
{
	private String stylistName;
	private String customerName;
	private String date;
	private String time;
	private String selectedPackage;
	
	public String getStylistName()
	{
		return stylistName;
		
	}
	
	public String getCustomerName()
	{
		return customerName;
		
	}
	
	public String getDate()
	{
		return date;
	}

	public String getTime()
	{
		return time;
	}
	
	public String getSelectedPackage()
	{
		return selectedPackage;
	}
	
	public void setDate(String date)
	{
		this.date = date;
	}
	
	public void setTime(String time)
	{
		this.time = time;
	}
	
	public void setSelectedPackage(String selectedPackage)
	{
		this.selectedPackage = selectedPackage;
	}
	
	public Appointment(String stylistName,  String selectedPackage, String customerName, String date, String time)
	{
		this.stylistName = stylistName;
		this.customerName = customerName;
		this.date = date;
		this.time = time;
		this.selectedPackage = selectedPackage;
	}
	
	public static ArrayList<Appointment> loadAppointmentFromFile() //Read the appointment list from appoitment.txt
	{
		ArrayList<Appointment> appointmentList = new ArrayList<>();
		
		try(Scanner scanner = new Scanner(new FileReader("appointments.txt")))
		{
			while(scanner.hasNextLine())
			{
				String line = scanner.nextLine();
				String[] parts = line.split(",");
				if(parts.length == 5)
				{
					String stylistName = parts[0];
					String packageNum = parts[1];
					String customerName = parts[2];
					String date = parts[3];
					String time = parts[4];
					
					appointmentList.add(new Appointment(stylistName, packageNum, customerName, date, time));
				}
			}
		}catch(IOException e)
		{
			System.out.println("An error occurred while reading appointment file.");
			e.printStackTrace();
		}
		
		return appointmentList;
	}
	
	public static void saveAppointmentsToFile(ArrayList<Appointment> appointmentList) //Save the appointment to the appointment.txt
	{
		try(FileWriter writer = new FileWriter("appointments.txt"))
		{
			for(Appointment appointment : appointmentList)
			{
				String line = String.format("%s,%s,%s,%s,%s\n",appointment.getStylistName(),appointment.getSelectedPackage(),appointment.getCustomerName(),appointment.getDate(),appointment.getTime());
				writer.write(line);
				
			}
		
			System.out.println("Appointments saved to file.");
			
		}catch(IOException e)
		{
			System.out.println("An error occurred while saving appointment data to file.");
			e.printStackTrace();
		}
	}
}
