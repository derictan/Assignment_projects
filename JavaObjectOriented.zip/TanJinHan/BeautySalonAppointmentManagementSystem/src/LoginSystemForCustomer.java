import java.util.*;
import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.LocalTime;


public class LoginSystemForCustomer
{                                             
	private String name;
	private String password;
	private int number;
	
	public String getName()
	{
		return name;
	}
	
	public String getPassword()
	{
		return password;
	}
	
	public int getNumber()
	{
		return number;
	}
	
	public LoginSystemForCustomer(String theName, String thePassword, int theNumber)
	{
		this.name = theName;
		this.password = thePassword;
		this.number = theNumber;
	}
	
	public static LoginSystemForCustomer loadListFromFile(String aName, String aPassword) //Read the customer list from Customer.txt
	{
		boolean isValid = false;
		
		try
		{
			int number = 1;
			int ttlNumber = 1;
			
			File myFile = new File ("CustomerList.txt");
			Scanner inputFile = new Scanner(myFile);
			
			while (inputFile.hasNext())
			{
				String str = inputFile.nextLine();
				String[] parts = str.split(",");
				ttlNumber ++;

				if(!parts[0].equals(aName) || !parts[1].equals(aPassword))
				{
					number++;
				}
				else
				{
					LoginSystemForCustomer login = new LoginSystemForCustomer(parts[0], parts[1], number); 
					isValid = true;
					return login;
				}
				
			}
			
			if (number == ttlNumber || isValid == false)
			{
				System.out.println("Invalid, Please Try Again...");
			}
			
			inputFile.close();
		}
		catch(FileNotFoundException ex)
		{
			System.out.print("error");
		}
		return null;
	}
	
	public static int coverPage()
	{
		String dateAndTime = CurrentDateAndTimeToString() ;
		
		Scanner input = new Scanner(System.in);
		System.out.println("--------------------------------------------------------------------------------------------------------------------");
		System.out.println("Welcome to Beauty Salon\t\t\t\t\t\t\t\t\t\t" + dateAndTime); 
		System.out.println("--------------------------------------------------------------------------------------------------------------------");
		
		System.out.println("<1> LogIn ");
		System.out.println("<2> Sign Up");
		System.out.println("<3> Exit");
		System.out.println("Enter your option:");
		

		String InitialOption = input.next();
		int FinalOption = 0;
		
		switch(InitialOption)
		{
			case"1":
			{
				FinalOption = 1; //Login funtion
				break;
			}
			case"2":
			{
				SignUp(); //Sign up function
				break;
			}
			case"3":
			{
				FinalOption = 3; //Exit
				System.out.println("See you next time~~");
				break;
			}
			default:
				System.out.println("Invalid Option, Please Try Again...");
				System.out.println();
				
		}
		return FinalOption;
		
		
	}

	public static boolean CheckRepeatedName(String aName)
	{
		try
		{
			File myFile = new File ("CustomerList.txt");
			Scanner inputFile = new Scanner(myFile);
			
			while (inputFile.hasNext())
			{
				String str = inputFile.nextLine();
				String[] parts = str.split(",");
				if(parts[1].equals(aName))
				{
					return false;
				}
				
			}
			inputFile.close();
		}
		catch(FileNotFoundException ex)
		{
			System.out.print("error");
		}
		return true;
	}
	
	public static void SignUp()
	{
		boolean repeat = true;
		do
		{
			try
			{
				Scanner input = new Scanner(System.in);
				
				String newName;
				do
				{
					System.out.println("Enter your name: ");
					newName = input.nextLine(); //Enter the username
					if(CheckRepeatedName(newName) == false) //Check if the name has been used before
					{
						System.out.println("This name is already in use, please try again...");
					}
				}while(CheckRepeatedName(newName) == false);
	
				
				System.out.println("Enter your phone number: ");
				String newPhoneNum = input.next();
				
				String newPassword;
				String newPassword2;
					
				do
				{
					newPassword = null;
					newPassword2 = null;
					System.out.println("Enter your password: ");
					newPassword = input.next();
					System.out.println("Enter your password again: ");
					newPassword2 = input.next();
					if(!newPassword.equals(newPassword2)) 
					{
						System.out.println("Your Password is not similar to the FIRST Password");
						System.out.println("Please try again...");	
					}
					
				}while(!newPassword.equals(newPassword2));
				
				
				String answer;
				do
				{
					System.out.println("Your name: " + newName);
					System.out.println("Your phone number: " + newPhoneNum);
					System.out.println("Your password: " + newPassword);
					System.out.println("Is this information correct? <Y>es / <N>o :");
					answer = input.next();
					answer = answer.toUpperCase();
					
					if(answer.equals("N"))
					{
						repeat = false;
					}
					else if(answer.equals("Y")) //If the information is confirmed correct, then create a new account
					{
						String newStaffList = (newName + "," + newPassword + "," + newPhoneNum);
						FileWriter fw = new FileWriter("CustomerList.txt", true);
						PrintWriter outputFile = new PrintWriter(fw);
						outputFile.println(newStaffList);
						outputFile.close();
						repeat = false;
					}
					else
					{
						System.out.println("Invalid option, Please try again...");
					}
				}while (!answer.equals("Y") && !answer.equals("N"));
			
			}
			catch(IOException e)
			{
				System.out.println(e);
			}
		}while(repeat == true);
	}

	public static String CurrentDateToString() 
	{
	  	// Get the current date
		LocalDate currentDate = LocalDate.now();
	        
		// Define a date format
	  	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	        
	  	// Format the current date as a string
		String date = currentDate.format(formatter);

		return date;
	}
	
	public static String CurrentDateAndTimeToString() 
	{
		//get the current time
		LocalDate currentDate = LocalDate.now();
		LocalTime currentTime = LocalTime.now();
        
        // Define a time format
		DateTimeFormatter formatterDate = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter formatterTime = DateTimeFormatter.ofPattern("HH:mm:ss");
        
        // Format the current time as a string
        String dateString = currentDate.format(formatterDate);
        String timeString = currentTime.format(formatterTime);
        
        String dateAndTime = (dateString + " " + timeString);

		return dateAndTime;
		
	}
	
	
	public static void writeFeedback(String name)
	{
		try
		{
			Scanner input = new Scanner(System.in);
			System.out.println("Please leave a comment :");
			String comment = input.nextLine();
			String commentList = (comment);
			
			FileWriter fw = new FileWriter("feedback.txt", true);
			PrintWriter outputFile = new PrintWriter(fw);
			outputFile.println(name + "," + commentList);
			outputFile.close();
		}
		catch(IOException ex)
		{
			System.out.print("error");
		}
	}
}