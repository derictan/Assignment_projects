import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.InputMismatchException;


public class Manager {
	private String name;
	private String password;
	
	public String getName()
	{
		return name;
	}
	
	public String getPassword()
	{
		return password;
	}
	
	Manager(String theName, String thePassword)
	{
		this.name = theName;
		this.password = thePassword;
	}
	
	public static Manager loadManagerFromFile(String aName, String aPassword) 
	{
		try
		{
			File myFile = new File ("Manager.txt");
			Scanner inputFile = new Scanner(myFile);
			
			while (inputFile.hasNext())
			{
				String str = inputFile.nextLine();
				String[] parts = str.split(",");

				if(parts[0].equals(aName) && parts[1].equals(aPassword))
				{
					Manager login = new Manager(parts[0], parts[1]);
					return login;
				}
				else
				{
					System.out.println("Invalid, please try again");
				}
				
			}
			
			inputFile.close();
		}
		catch(FileNotFoundException ex)
		{
			System.out.print("error");
		}
		return null;
	}
	
	public static void viewProfile() //View the stylist's informations
	{
		try
		{
			File myFile = new File ("StaffList.txt");
			Scanner inputFile = new Scanner(myFile);
			
			int number = 0;
			
			while (inputFile.hasNext())
			{
				number++;
				String str = inputFile.nextLine();
				String[] parts = str.split(",");
				
				System.out.println("Staff " + number + ":");
				System.out.println("ID\t\t: " + parts[0]);
				System.out.println("Name\t\t: " + parts[1]);
				System.out.println("Date of hire\t: " + parts[2]);
				System.out.println("Position\t: " + parts[3]);
				System.out.println("Password\t: " + parts[4]);
				System.out.println();
				
			}
			inputFile.close();
		}
		catch(FileNotFoundException ex)
		{
			System.out.print("error");
		}
		
	}
	
	public static void viewStylistName() 
	{
		try
		{
			File myFile = new File ("StaffList.txt");
			Scanner inputFile = new Scanner(myFile);
			
			int number = 0;
			
			while (inputFile.hasNext())
			{
				number++;
				String str = inputFile.nextLine();
				String[] parts = str.split(",");
				
				System.out.println("Stylist " + number + " : " + parts[1]);
				
				System.out.println();
				
			}
			inputFile.close();
		}
		catch(FileNotFoundException ex)
		{
			System.out.print("error");
		}
	}
	
	public static void viewLeaveApplication() 
	{
		try
		{
			File myFile = new File ("LeaveList.txt");
			Scanner inputFile = new Scanner(myFile);
			
			int number = 0;
			
			while (inputFile.hasNext())
			{
				number++;
				String str = inputFile.nextLine();
				String[] parts = str.split(",");
				
				System.out.println(number + ". " + parts[1]);
				System.out.println("Reason\t:" + parts[2]);
				System.out.println("From\t:" + parts[3]);
				System.out.println("To\t:" + parts[4]);
				System.out.println("Status\t:" + parts[5]);
				System.out.println();
				
			}
			inputFile.close();
		}
		catch(FileNotFoundException ex)
		{
			System.out.print("error");
		}
	}
	
	public static void ApprovedTheLeave() 
	{
		String option;
		Scanner input = new Scanner(System.in);
		viewLeaveApplication(); //view all the leave requested by staffs
		do
		{
			System.out.println("<1> Approve the Leave");
			System.out.println("<2> Exit to menu");
			option = input.next();
		
			switch(option)
			{
			case"1":
			{
				boolean isValid = true;
				do
				{
					System.out.println("Which leave you want to approve? (Enter the number on the list): ");
					String number = input.next();
					try 
					{
			            int num = Integer.parseInt(number);
			            isValid = EditTheLeaveList(num); 
			            System.out.println("Data edited and saved.");
			            viewLeaveApplication();
			        } 
					catch (NumberFormatException e)
					{
			            System.out.println("Invalid, please enter the number in the list");
			            isValid = false;
			        }
				} while(isValid == false);
				
				break;
			}
			default:	
				if(!option.equals("1") && !option.equals("2"))
				{
					System.out.println("Invalid, please try again...");
				}
				break;
			}
		}while(!option.equals("2"));
	}
	
	public static boolean EditTheLeaveList(int num) //Approved the leave
	{
		try
		{
			File myFile = new File ("LeaveList.txt");
			Scanner inputFile = new Scanner(myFile);
			
			int currentNumber = 0;
			
			while (inputFile.hasNext())
			{
				currentNumber++;
				if(currentNumber == num)
				{
					String str = inputFile.nextLine();
					String[] parts = str.split(",");
					
					String newText = (parts[0] + "," + parts[1] + "," + parts[2] + "," + parts[3] + "," + parts[4] + "," + "Approved");
					editAndSaveTheLeave("LeaveList.txt", num , newText);
					return true;
				}
			}
			inputFile.close();
		}
		catch(FileNotFoundException ex)
		{
			System.out.print("error");
		}
		return false;
	}
	
	public static void viewFeedback() //view the feedback given by customers
	{
		try
		{
			File myFile = new File ("feedback.txt");
			Scanner inputFile = new Scanner(myFile);
			
			int number = 0;
			
			while (inputFile.hasNext())
			{
				number++;
				String str = inputFile.nextLine();
				String[] parts = str.split(",");
				
				System.out.println(number + ". " + parts[0]);
				System.out.println("Comment : " + parts[1]);
				System.out.println();
				
			}
			inputFile.close();
		}
		catch(FileNotFoundException ex)
		{
			System.out.print("error");
		}
	}
	
	public static void editAndAddPackage() 
	{
		String option;
		
		do
		{
			Scanner input = new Scanner(System.in);
			BeautySalonAppointmentManagementSystem.displayPackages();
			System.out.println("<1> Edit package");
			System.out.println("<2> Add new package");
			System.out.println("<3> Exit");
			System.out.println("Enter your option:");
			option = input.next();
				
			switch(option)
			{
			case"1":
				editPackage(); //edit old package
				break;
			case"2":
			{
				addPackage(); //add new package
			}
			default:
			{
				if(!option.equals("3"))
				{
					System.out.println("Invalid option, Please try again...");
					System.out.println();
				}
			}
			}
		}while(!option.contentEquals("3"));
	}

	public static void editPackage() //edit old package
	{
		Scanner input = new Scanner(System.in);
		
		System.out.println("Which package to edit :");
		int num = input.nextInt();
		input.nextLine();
		System.out.println("Package " + num + ": ");
		String newPackage = input.nextLine();
		System.out.println("Price :");
		String newPrice = input.next();
		String thePackage = (newPackage + "," + newPrice + ".00");
		Staff.editAndSaveLine("package.txt", num, thePackage);
	}
	
	public static void addPackage() //add new package
	{
		try
		{
			Scanner input = new Scanner(System.in);
			System.out.println("Package :");
			String newPackage = input.nextLine();
			System.out.println("Price   :");
			String newPrice = input.next();
			String thePackage = (newPackage + "," + newPrice + ".00");
			
			FileWriter fw = new FileWriter("package.txt", true);
			PrintWriter outputFile = new PrintWriter(fw);
			outputFile.println(thePackage);
			outputFile.close();
		}
		catch(IOException ex)
		{
			System.out.print("error");
		}
	}
	
	public static void editAndSaveTheLeave(String filePath, int lineToEdit, String newText) 
    {
		try 
        {
        	Scanner input = new Scanner(System.in);
            // Read the original content into memory
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            StringBuilder content = new StringBuilder();
            String line;
           
            int lineNumber = 0;

            while ((line = reader.readLine()) != null) 
            {
                lineNumber++;

                if (lineNumber == lineToEdit) {
                    // Replace the line you want to edit with the new text
                    content.append(newText).append("\n");
                } else {
                    // Keep other lines unchanged
                    content.append(line).append("\n");
                }
            }
            reader.close();
            

            // Write the modified content back to the file
            PrintWriter writer = new PrintWriter(new FileWriter(filePath));
            writer.write(content.toString());
            writer.close();
            
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
	
	public static void updateAvailabilityForNewWeek() 
	{
		Scanner input = new Scanner(System.in);
		ArrayList <Stylist> Slot = new ArrayList<>();
		
		
		System.out.println("How many stylist wish to add?");
		int num;
		//input.nextLine();
		
		while (true) {
	        try {
	            num = input.nextInt();
	            input.nextLine(); // Consume the newline character
	            break; // Exit the loop if input is a valid integer
	        } catch (InputMismatchException e) {
	            System.out.println("Invalid input. Please enter a valid integer.");
	            System.out.println("Enter your choice again: ");
	            input.nextLine(); // Consume the invalid input
	        }
	    }

		for(int i = 0; i < num; i++)
		{
			ArrayList <String> timeSlots = new ArrayList<>();  //create new list for each stylist
			System.out.println("Enter name for stylist " + (i+1) + " :");
			
			String name = input.nextLine();
			String choice; 
				
			do
			{
				System.out.println("Enter available date(yyyy-MM-dd):");
				String date = input.nextLine();
				System.out.println("Enter available time(HH:mm):");
				String time = input.nextLine();
				timeSlots.add(date + "," + time);
				
				do
				{
					System.out.println("Is there any available time slot?(y/n)");
					choice = input.nextLine();
					if(!choice.equalsIgnoreCase("y") && !choice.equalsIgnoreCase("n"))
					{
						System.out.println("Invalid choice. Please Try Again!");
					}
					
				}while(!choice.equalsIgnoreCase("y") && !choice.equalsIgnoreCase("n"));
			}while(choice.equalsIgnoreCase("y"));
			
			
			String combinedTimeSlots = String.join(",", timeSlots);
			String line = name + "," + combinedTimeSlots;
			String[] parts = line.split(",");
			if(parts.length >= 1)
			{
				String stylistName = parts[0];
				Stylist stylist = new Stylist(stylistName); //create stylist object
				
				for(int a = 1; a < parts.length; a++)
				{
					stylist.addAvailableTimeSlots(parts[a]);
				}
				
				Slot.add(stylist);
			}	
		}
			Stylist.writeStylistAvaibility(Slot);
		}
	

}
