import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class LeaveApplication 
{
	private String Id;
	private String name;
	private String leaveReason;
    private String start;
    private String end;
    private String approval;

    public String getId() 
    {
    	return Id;
    }
    
    public String getName()
    {
    	return name;
    }
    
    public String getLeaveReason() 
    {
    	return leaveReason;
    }
    
    public String getStart() 
    {
    	return start;
    }
    
    public String getEnd()
    {
    	return end;
    }
    
    public String getApproval() 
    {
    	return approval;
    }
    
    public void setLeaveReason(String theReason) //**
	{
		leaveReason = theReason;
	}
    
    public void setApproval(String approve) //**
	{
		approval=approve;
	}
    
    public LeaveApplication(String staffId, String staffName, String leaveReason, String startDate, String endDate, String approval) {
        this.Id = staffId;
        this.name = staffName;
        this.leaveReason = leaveReason;
        this.start = startDate;
        this.end = endDate;
        this.approval = approval;
    }
    
    public static ArrayList<LeaveApplication> loadLeaveApplicationFromFile(String aName) //Read the leave application from LeaveList.txt
    {
    	ArrayList<LeaveApplication> leave = new ArrayList<LeaveApplication>();
		try
		{
			File myFile = new File ("LeaveList.txt");
			Scanner inputFile = new Scanner(myFile);
			while (inputFile.hasNext())
			{
				String str = inputFile.nextLine();
				String[] parts = str.split(",");
				if(parts[1].equals(aName))
				{
					leave.add(new LeaveApplication(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5])); 
				}
			}
			inputFile.close();
		}
		catch(FileNotFoundException ex)
		{
			System.out.print("error");
		}
		
		
		return leave;
    }
    
    public static void Leave(ArrayList<LeaveApplication> leaveList, String aID, String aName) //Print the leave application
	{
		Scanner input = new Scanner(System.in);
		boolean isValidOption = false;
		
		System.out.println("--------------------------------------------------------------------------------------------------------------------");
        System.out.println("Leave Application");
        System.out.println("--------------------------------------------------------------------------------------------------------------------");
        int number = 0;
        //System.out.println("ID\tName\tReason\t\tStart\t\tEnd\t\tApproval");
        for(LeaveApplication leaves : leaveList)
		{
        	number++;
			String reason = leaves.getLeaveReason();
			String start = leaves.getStart();
			String end = leaves.getEnd();
			String approval = leaves.getApproval();
			
			System.out.println(number + ". ");
			System.out.println("Reason\t:" + reason);
			System.out.println("From\t:" + start);
			System.out.println("To\t:" + end);
			System.out.println("Status\t:" + approval);
			System.out.println();
			//System.out.println(id + "\t" + name + "\t" + reason + "\t\t" + start + "\t" + end + "\t" + approval);
		}
			
		String opt;
	   	do
	   	{
	   		System.out.println("Add New Leave Applications (y/n): ");
		   	opt = input.next();
		   	opt = opt.toUpperCase();
	   		if (opt.equals("Y") || opt.equals("N")) 
		  	{
		      	isValidOption = true;
		   	}
		 	else 
		   	{
		       	System.out.println("Invalid option, Please try again...");
		  	}
	   	}while(isValidOption == false);
	  	
	  	do 
		{
	           	if (opt.equals("Y")) //Allow staff to request leave
	    	 	{
	          		try 
	          		{
	          			System.out.print("Enter Start Date (dd/mm/yyyy): ");
	              		String newStart = input.next();
	              		
	              		System.out.print("Enter End Date (dd/mm/yyyy): ");
	              		String newEnd = input.next();

	              		System.out.print("Enter Leave Reason: ");
	              		String newReason = input.next();

	              		String newLeave = (aID + "," + aName + "," + newReason + "," + newStart + "," + newEnd + "," + "Pending");
	              		
	          			FileWriter fw = new FileWriter("LeaveList.txt", true);
	                    PrintWriter outputFile = new PrintWriter(fw);
	                    outputFile.println(newLeave);
	                    
	                    outputFile.close();
	                    break;
	          		}
	    	 		catch (IOException e) 
	    	 		{
	    	 			System.out.println("An error occurred while processing the leave application.");
	    	 			e.printStackTrace();
	    	 		}
	    	 	}
	           	else 
	           	{
	           		break;
	           	}
			
	    }while(isValidOption);
 
	}
}