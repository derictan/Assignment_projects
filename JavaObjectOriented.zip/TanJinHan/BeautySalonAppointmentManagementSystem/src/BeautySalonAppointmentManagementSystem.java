import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class BeautySalonAppointmentManagementSystem 
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		String choice;
		int step;
		do
		{
			String dateAndTime = LoginSystemForStaff.CurrentDateAndTimeToString() ; //print out the date and time in format(day/month/year hour:minutes:seconds)
			
			System.out.println("--------------------------------------------------------------------------------------------------------------------");
			System.out.println("Welcome to Beauty Salon\t\t\t\t\t\t\t\t\t\t" + dateAndTime); 
			System.out.println("--------------------------------------------------------------------------------------------------------------------");
			System.out.println("Log in as customer or staff?");
			System.out.println("<1> Staff");
			System.out.println("<2> Customer");
			System.out.println("<3> Manager");
			System.out.println("<4> Exit");
			System.out.println("Enter your option:");
			choice = input.next();
			
			if(choice.equals("1"))
			{
				ArrayList<Stylist> stylistList = Stylist.loadStylistsFromFile();
				ArrayList <Appointment> appointmentList = Appointment.loadAppointmentFromFile();
				do
				{
					step = LoginSystemForStaff.coverPage(); // Run the Login System cover page
					
					if (step == 1) //Login System for Staff
					{
						String option = null;
						LoginSystemForStaff Login;
						
						do
						{
							String name;
							String password;
							
							System.out.println("--------------------------------------------------------------------------------------------------------------------");
							System.out.println("Welcome to Beauty Salon\t\t\t\t\t\t\t\t\t\t" + dateAndTime);
							System.out.println("--------------------------------------------------------------------------------------------------------------------");
							System.out.println("Login as Staff");
							System.out.print("Username\t:");
							name = input.next(); //Enter the staff's username
							
							System.out.print("Password\t:");
							password = input.next(); //Enter the Staff's password
							
							Login = LoginSystemForStaff.loadListFromFile(name, password); //Check the Staff's username and password to make sure they are correct before logging in
							//If the username and password are incorrect, you will be returned to the login system again
							
							while(Login != null)
							{
								
								String aID = Login.getID();
								String aName = Login.getName();
								
								
								ArrayList<Staff> staffList = Staff.loadStaffListFromFile(aName); //Read StaffList from StaffList.txt based on account login
								ArrayList<LeaveApplication> leaveList = LeaveApplication.loadLeaveApplicationFromFile(aName); //View the leave previously requested by the staff
								
								String staffFile = "StaffList.txt";
								
								System.out.println("--------------------------------------------------------------------------------------------------------------------");
					            System.out.println("Staff System\t\t\t\t\t\t\t\t\t\t\t" + dateAndTime);
					            System.out.println("--------------------------------------------------------------------------------------------------------------------");
					            System.out.println("<1> Profile");
					            System.out.println("<2> Check available time slots");
					            System.out.println("<3> View Scheduled Time slot ");
					            System.out.println("<4> Leave Application");
					            System.out.println("<5> Exit");
					            System.out.println();
					            System.out.println("Enter your option:");
					            option = input.next();
					            switch (option) 
					            {
					                case "1": 
					                {
					                	boolean LoginSystem = Staff.DisplayProfile(staffList, staffFile); //Show profile and allow staff to edit
					                	if (LoginSystem == false)
					                	{
					                		Login = null;
					                	}
					                	break;
					                }
					                case "2": 
					                	Staff.viewAndEditAvailableTime(aName, stylistList); //Allow staff to view and add their available time
					                	break;
					                case "3":
					                	Staff.viewScheduledTimeSlot(aName,stylistList,appointmentList); //Allow staff to view their scheduled time
					                	break;
					                case "4": 
					                	LeaveApplication.Leave(leaveList, aID, aName); //Allow employees to request leave and view previous leave
					                	break;
					                case "5":
					                {
					                	Login = null;
					                	step = 3;
					                	Stylist.saveStylistsToFile(stylistList); //save the stylist's information to the stylist.txt
							            Appointment.saveAppointmentsToFile(appointmentList); //save the appointment to the appointment.txt
							            System.out.println("Log OUT successfully!"); //Logout
					                	break;
					                }
					                default: 
					                	System.out.println("Invalid option, Please try again...");
					                	System.out.println();
					                	break;
					            }
							}
						}while (Login != null);
					}
					else if (step == 2)
					{
						LoginSystemForStaff.SignUp(); //Allow new Staff to sign up
					}
					
				} while(step != 3);
			}
			else if(choice.equals("2"))
			{
				ArrayList<Stylist> stylistList = Stylist.loadStylistsFromFile(); 
				ArrayList <Appointment> appointmentList = Appointment.loadAppointmentFromFile();
				do
				{
					step = LoginSystemForCustomer.coverPage(); // Run the Login System cover page
					LoginSystemForCustomer Login;
					
					if (step == 1) //After LogIn, go thru the Main Menu function
					{
						
						do
						{
							String name;
							String password;
							
							System.out.println("--------------------------------------------------------------------------------------------------------------------");
							System.out.println("Welcome to Beauty Salon\t\t\t\t\t\t\t\t\t\t" + dateAndTime);
							System.out.println("--------------------------------------------------------------------------------------------------------------------");
							System.out.println("Login as Customer");
							System.out.print("Username\t:");
							name = input.next(); //Enter the customer's username
							
							System.out.print("Password\t:");
							password = input.next(); //Enter the customer's password
							
							Login = LoginSystemForCustomer.loadListFromFile(name, password); //Check the customer's username and password to make sure they are correct before logging in
							
							while(Login != null)
							{
								String aName = Login.getName();
								ArrayList<Customer> customerList = Customer.loadCustomerListFromFile(aName); //Read Customer List from CustomerList.txt based on account login
								String customerFile = "CustomerList.txt";
								
									System.out.println("--------------------------------------------------------------------------------------------------------------------");
						            System.out.println("Customer Main Menu\t\t\t\t\t\t\t\t\t\t" + dateAndTime);
						            System.out.println("--------------------------------------------------------------------------------------------------------------------");
						            System.out.println("<1> Profile");
						            System.out.println("<2> View packages offered");
						            System.out.println("<3> View Stylist Available Time Slots");
						            System.out.println("<4> Book an Appointment");
						            System.out.println("<5> Reschedule Appointment");
						            System.out.println("<6> Cancel Appointment");
						            System.out.println("<7> Feedback");
						            System.out.println("<8> Exit");
						            System.out.println("--------------------------------------------------------------------------------------------------------------------");
									System.out.println("      Please check stylist available time BEFORE book an appointment.");
									System.out.println("--------------------------------------------------------------------------------------------------------------------");
									System.out.println("Enter your option:");
							
									
									String num = input.next();
									
									input.nextLine();
									
									switch(num) 
									{
										case "1":
										{
											boolean LoginSystemForCustomer = Customer.DisplayProfile(customerList,appointmentList, customerFile); //Allow customer to view their profile
						                	if (LoginSystemForCustomer == false)
						                	{
						                		Login = null;
						                	}
						                	break;
										}
										case "2":
											displayPackages(); //Allow customers to view packages offered by Beauty Salon
											break;
										case "3":
											viewStylistsAndTimeSlots(stylistList); //Allow customers to view the Stylists available in Beauty Salon
											break;
										case "4":
											bookAppointment(stylistList, appointmentList); //Allow customers to book appointment
											break;
										case "5":
											rescheduleAppointment(appointmentList, stylistList); //Allow customers to reschedule appointment
											break;
										case "6":
											cancelAppointment(appointmentList, stylistList); //Allow customers to cancel appointment
											break;
										case "7":
											LoginSystemForCustomer.writeFeedback(aName); //Allow customers to write a feedback
											break;
										case "8":
										{
								              Login = null;
								              step = 3;
								              Stylist.saveStylistsToFile(stylistList); 
								              Appointment.saveAppointmentsToFile(appointmentList);
								              System.out.println("Log OUT successfully!"); //Logout
								              System.out.println();
								              break;
										}
										default:
											System.out.println("Invalid option, Please try again...");
						                	System.out.println();
						                	break;
									}
								}
						}while (Login != null);
					}
					
					
					else if (step == 2)
					{
						LoginSystemForCustomer.SignUp(); //Allow new customers to sign up a new account
					}
					
				} while(step != 3);
			}
			else if(choice.equals("3"))
			{
				ArrayList<Stylist> stylistList = Stylist.loadStylistsFromFile();
				ArrayList <Appointment> appointmentList = Appointment.loadAppointmentFromFile();
				do
				{
					step = LoginSystemForManager.coverPage(); // Run the Login System cover page
					Manager Login;
					
					if (step == 1) //After LogIn, go thru the Main Menu function
					{
						String option = null;
						do
						{
							String name;
							String password;
							//String date = LoginSystem.CurrentDateToString();
							
							System.out.println("--------------------------------------------------------------------------------------------------------------------");
							System.out.println("Welcome to Beauty Salon\t\t\t\t\t\t\t\t\t\t" + dateAndTime);
							System.out.println("--------------------------------------------------------------------------------------------------------------------");
							System.out.println("Login as Manager");
							System.out.print("Username\t:");
							name = input.next(); //Enter the customer's username
							
							System.out.print("Password\t:");
							password = input.next(); //Enter the customer's password
							
							Login = Manager.loadManagerFromFile(name, password); //Check the Customer's username and password to make sure they are correct before logging in
							
							while(Login != null)
							{	
								System.out.println("--------------------------------------------------------------------------------------------------------------------");
					            System.out.println("Manager System\t\t\t\t\t\t\t\t\t\t\t" + dateAndTime);
					            System.out.println("--------------------------------------------------------------------------------------------------------------------");
					            System.out.println("<1> View Stylists' Profile");
					            System.out.println("<2> View Stylist Available Time Slots");
					            System.out.println("<3> View Scheduled Time slot ");
					            System.out.println("<4> View Package ");
					            System.out.println("<5> Leave Application");
					            System.out.println("<6> View Feedback");
					            System.out.println("<7> Update Stylist avaibility time slots for new week");
					            System.out.println("<8> Exit");
					            System.out.println();
					            System.out.println("Enter your option:");
					            option = input.next();
					            switch (option) 
					            {
					                case "1": 
					                {
					                	Manager.viewProfile(); //Allow manager to view the staff's profile
					                	break;
					                }
					                case "2": 
					                	viewStylistsAndTimeSlots(stylistList); //Allow manager to view the staff's available time slots
					                	break;
					                case "3":
					                {
					                	Manager.viewStylistName(); //Allow the manager to search the stylist
					            		System.out.println();
					            		System.out.println("Stylist name:");
					                	String stylistName = input.next();
					                	Staff.viewScheduledTimeSlot(stylistName,stylistList,appointmentList); //Allow the manager to view the scheduled time slot
					                	break;
					                }
					                	
					                case "4": 
					                	Manager.editAndAddPackage(); //Allow manager to view the edit the package
					                	break;
					                case "5": 
					                	Manager.ApprovedTheLeave(); //Allow manager to approve the leave requested by stylists
					                	break;
					                case "6": 
					                	Manager.viewFeedback(); //Allow manager to view the feedback
					                	break;
					                case "7":
					                	Manager.updateAvailabilityForNewWeek(); //Allow manager to update the available time for new week
					                	break;
					                case "8":
					                {
					                	Login = null;
					                	step = 3;
					                	Stylist.saveStylistsToFile(stylistList); 
							            Appointment.saveAppointmentsToFile(appointmentList);
							            System.out.println("Log OUT successfully!"); //Logout
					                	break;
					                }
					                default: 
					                	System.out.println("Invalid option, Please try again...");
					                	System.out.println();
					                	break;
					            }

							}
							
						}while (Login != null);
					}
				} while(step != 2);
			}	
			else if (choice.equals("4"))
			{
				
				choice = "4"; //Exit the program
			}
			else
			{
				System.out.println("Invalid option, Please try again...");
				System.out.println();
			}
		}while(!choice.equals("4"));	
	}
	
	
	public static void viewStylistsAndTimeSlots(ArrayList<Stylist> stylistList)
	{
		System.out.println("Stylists and Available Time Slots For This Week: ");
		for(Stylist stylist : stylistList)
		{
			stylist.viewAvailableTimeSlots(); //view the stylist's available time
		}
	}
	
	public static void bookAppointment(ArrayList<Stylist> stylistList, ArrayList<Appointment> appointmentList)
	{
		Scanner input = new Scanner(System.in);
		
		System.out.println("Available Stylists: ");
		for(int i = 0; i < stylistList.size(); i++)
		{
			System.out.println((i+1) + ". " + stylistList.get(i).getName()); 
		}
		
		System.out.print("Select a stylist(Enter the number): ") ;
		int stylistnum = input.nextInt();
		input.nextLine();
		
		
		if(stylistnum < 0 || stylistnum > stylistList.size())
		{
			System.out.println("Invalid stylist selection.");
			return;
		}
		
		Stylist selectedstylist = stylistList.get(stylistnum-1);
		System.out.println("Select a package(Package Number): ");
		String packageNum = input.nextLine(); //Enter the package number
		
		
		System.out.print("Enter your name: ");
		String name = input.nextLine(); //Enter the customer's name
		System.out.print("Enter date(Exp:2023-09-14):");
		String date = input.nextLine(); //Enter the date
		System.out.print("Enter time (Exp: 09:00):");
		String time = input.nextLine(); //Enter the time
		
		String requestedTimeSlot =date + "," + time; 
		
		for (Stylist stylist : stylistList) 
        {
            if (stylist.getName().equals(selectedstylist.getName())) 
            {
                if(!stylist.getAvailableTimeSlots().contains(date))
                	if(!stylist.getAvailableTimeSlots().contains(time))
                	{
                		System.out.println("The selected time slot is not available for booking.");
        	            return;
               		}
            	
            }
        }
		
		
		
		for(Appointment appointment : appointmentList)
		{
			if(appointment.getStylistName().equals(selectedstylist.getName()) && appointment.getDate().equals(date) && appointment.getTime().equals(time))
			{
				System.out.println("The selected time slot is already booked. ");
				return;
			}
				
		}
		
		
		//create new arraylist to store temporary new format with(date,time)
		ArrayList <String> newList = new ArrayList<>();
		
		for(int i = 0; i < selectedstylist.getAvailableTimeSlots().size(); i+=2)
		{
			String date1 = selectedstylist.getAvailableTimeSlots().get(i);
			String time1 = selectedstylist.getAvailableTimeSlots().get(i+1);
			newList.add(date1 + "," + time1);
			
		}
	
		for(int i = 0; i < newList.size(); i++)
		{
			if(newList.get(i).equals(requestedTimeSlot))
			{
				int index = i;
				newList.remove(index);
				break;
			}
		}
		
		selectedstylist.getAvailableTimeSlots().clear();
		
		for(String slot : newList)
		{
			String [] parts = slot.split(",");
			selectedstylist.addAvailableTimeSlots(parts[0]);
			selectedstylist.addAvailableTimeSlots(parts[1]);
		}
		
		
				
		Appointment createAppointment = new Appointment(selectedstylist.getName(),packageNum,name, date, time);
		appointmentList.add(createAppointment);
		
		
		System.out.println("Appointment booked successfully! ");
	}
	
	

	public static void rescheduleAppointment(ArrayList<Appointment> appointmentList, ArrayList<Stylist> stylistList)
	{
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter name: ");
        String customerName = scanner.nextLine(); //Enter the customer's name

        // Find appointments for the customer
        ArrayList<Appointment> customerAppointments = new ArrayList<>();
        for (Appointment appointment : appointmentList) 
        {
            if (appointment.getCustomerName().equalsIgnoreCase(customerName)) 
            {
                customerAppointments.add(appointment);
            }
        }

        if (customerAppointments.isEmpty()) 
        {
            System.out.println("No appointments found for the customer.");
            return;
        }

        // Display customer's appointments
        System.out.println("Customer's Appointments:");
        for (int i = 0; i < customerAppointments.size(); i++) 
        {
            Appointment appointment = customerAppointments.get(i);
            System.out.println((i + 1) + ". Stylist: " + appointment.getStylistName() +
                    ", Date: " + appointment.getDate() +
                    ", Time: " + appointment.getTime());
        }

        // Select an appointment to reschedule
        System.out.print("Select an appointment to reschedule (Enter the number): ");
        int appointmentIndex = scanner.nextInt() - 1;
        scanner.nextLine(); 

        if (appointmentIndex < 0 || appointmentIndex >= customerAppointments.size()) 
        {
            System.out.println("Invalid appointment selection.");
            return;
        }

        else
        {
        	Appointment rescheduledAppointment = customerAppointments.get(appointmentIndex);

        	
	        // Enter new date and time for the appointment
	        System.out.print("Enter new date (yyyy-MM-dd): ");
	        String newDate = scanner.nextLine();
	        System.out.print("Enter new time (HH:mm): ");
	        String newTime = scanner.nextLine();

	        // Check if the selected time slot is available
	        String newTimeSlot = newDate + "," + newTime;
	        
	        for (Stylist stylist : stylistList) 
	        {
	            if (stylist.getName().equals(rescheduledAppointment.getStylistName())) 
	            {
	                if(!stylist.getAvailableTimeSlots().contains(newDate))
	                	if(!stylist.getAvailableTimeSlots().contains(newTime))
	                	{
	                		System.out.println("The selected time slot is not available for rescheduling.");
	        	            return;
	               		}
	            }
	        }
	    
	        
	       
	        // Remove the new time slot from stylist's available time slots
	     
	        ArrayList <String> newList2 = new ArrayList<>();
	        for (Stylist stylist : stylistList) 
	        {
	            if (stylist.getName().equals(rescheduledAppointment.getStylistName())) 
	            {
	            	ArrayList<String> availableTimeSlots = stylist.getAvailableTimeSlots();
	            	
	            	  for(int i = 0; i < availableTimeSlots.size(); i+=2)
		                {
							String date1 = availableTimeSlots.get(i);
							String time1 = availableTimeSlots.get(i+1);
							newList2.add(date1 + "," + time1);
		                }   
	            	  break;        
	            }
	       
             }  
	      
	  
	        for(int i = 0; i < newList2.size(); i++)
			{
				if(newList2.get(i).equals(newTimeSlot))
				{
					int index = i;
					newList2.remove(index);
				
				}
			} 
	        
	        //store newList2 back to the timeslots and add the reschedule timeslots back
	        for (Stylist stylist : stylistList) 
	        {
	            if (stylist.getName().equals(rescheduledAppointment.getStylistName())) 
	            {
	            	stylist.getAvailableTimeSlots().clear();
	            }
	        }
	        
	        String dateToAddBack = rescheduledAppointment.getDate();
	        String timeToAddBack = rescheduledAppointment.getTime();
	        
	        for(Stylist stylist : stylistList)
	        {
	        	if(stylist.getName().equals(rescheduledAppointment.getStylistName()))
	        	{
	        		Stylist selectedStylist = stylist;
	        		for(String slot : newList2)
					{
						String [] parts = slot.split(",");
						selectedStylist.addAvailableTimeSlots(parts[0]);
						selectedStylist.addAvailableTimeSlots(parts[1]);
					}
	        		 selectedStylist.addAvailableTimeSlots(dateToAddBack);
		             selectedStylist.addAvailableTimeSlots(timeToAddBack);
	        	}
	        	
	        	
            }
	   
	        // Update the appointment with the new date and time
	        rescheduledAppointment.setDate(newDate);
	        rescheduledAppointment.setTime(newTime);
	        System.out.println("Reschedule successfully!");
       
 }
}
        
	public static void cancelAppointment(ArrayList<Appointment> appointmentList, ArrayList<Stylist> stylistList) 
	{
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter name: ");
		String customerName = scanner.nextLine(); //Enter the customer's name

	   
		ArrayList<Appointment> customerAppointments = new ArrayList<>();
	 	for (Appointment appointment : appointmentList) 
	  	{    
	    	if (appointment.getCustomerName().equalsIgnoreCase(customerName)) 
	    	{
	          	customerAppointments.add(appointment);
	      	}
	  	}
	     
	 	if (customerAppointments.isEmpty()) 
	  	{
	    	System.out.println("No appointments found for the customer.");
	    	return;
	  	}

	 	// Display customer appointments
	 	System.out.println("Customer's Appointments:");
	  	for (int i = 0; i < customerAppointments.size(); i++) 
	  	{
	    	Appointment appointment = customerAppointments.get(i);
	    	System.out.println((i + 1) + ". Stylist: " + appointment.getStylistName() + ", Date: " + appointment.getDate() + ", Time: " + appointment.getTime());
	 	}

	 	// Select an appointment to cancel
	  	System.out.print("Select an appointment to cancel (Enter the number): ");
	   	int appointmentIndex = scanner.nextInt() - 1;  //allow same index num in array
	 	scanner.nextLine(); 

	  	if (appointmentIndex < 0 || appointmentIndex >= customerAppointments.size()) 
	  	{
	    	System.out.println("Invalid appointment selection.");
	    	return;
	  	}

	   	Appointment canceledAppointment = customerAppointments.get(appointmentIndex);
	  	appointmentList.remove(canceledAppointment);

	  	// Find the corresponding stylist to add the time slot back
	  	for (Stylist stylist : stylistList) 
	  	{
	    	if (stylist.getName().equals(canceledAppointment.getStylistName())) 
	    	{
	    		stylist.addAvailableTimeSlots(canceledAppointment.getDate()); 
	    		stylist.addAvailableTimeSlots(canceledAppointment.getTime());
	    		break;
	      	}
	  	}

	  	System.out.println("Appointment canceled successfully!");
	}
	
	
	public static void displayPackages()
	{
		try
		{
			File myFile = new File ("package.txt");
			Scanner inputFile = new Scanner(myFile);
			
			int number = 0;
			
			while (inputFile.hasNext())
			{
				number++;
				String str = inputFile.nextLine();
				String[] parts = str.split(",");
				
				System.out.println("Package\t" + number + ": " + parts[0]);
				System.out.println("Price\t : RM" + parts[1]);
				
				System.out.println();
				
			}
			inputFile.close();
		}
		catch(FileNotFoundException ex)
		{
			System.out.print("error");
		}
	}
	
		
}