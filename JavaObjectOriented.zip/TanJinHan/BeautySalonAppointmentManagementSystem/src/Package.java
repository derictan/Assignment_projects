public class Package 
{
	private String name;
	private String details;
	private double price;
	
	public String getName()
	{
		return name;
	}
	
	public String getDetails()
	{
		return details;
	}
	
	public double getPrice()
	{
		return price;
	}

	public void setName(String name)
	{
		this.name = name;
	}
	
	public void setDetails(String details)
	{
		this.details = details;
	}
	
	public void setPrice(double price)
	{
		this.price = price;
	}
	
	public Package(String name, String details, double price)
	{
		this.name = name;
		this.details = details;
		this.price = price;
	}
	
	public String toString()
	{
		return name + "\t" + details + "\t" + price;
	}
	

}
