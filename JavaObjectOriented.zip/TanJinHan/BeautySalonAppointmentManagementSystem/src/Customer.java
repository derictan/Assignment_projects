import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Customer
{
	private String name;
	private String phoneNum;
	private String password;
	private int lineNum;
	
	public String getName()
	{
		return name;
	}
	
	public String getPhoneNum()
	{
		return phoneNum;
	}
	
	public String getPw()
	{
		return password;
	}
	
	public int getLineNum()
	{
		return lineNum;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public void setPhoneNum(String phoneNum)
	{
		this.phoneNum = phoneNum;
	}
	
	public void setPassword(String pw)
	{
		password = pw;
	}
	
	public Customer(String name, String password,String phoneNum, int lineNum)
	{
		this.name = name;
		this.phoneNum = phoneNum;
		this.lineNum = lineNum;
	}
	
	public static ArrayList<Customer> loadCustomerListFromFile(String aName) //Read the customer list from Customer.txt
	{
		int number = 1;
		ArrayList<Customer> customer = new ArrayList<Customer>();
		try
		{
			File myFile = new File ("CustomerList.txt");
			Scanner inputFile = new Scanner(myFile);
			
			while (inputFile.hasNext())
			{
				String str = inputFile.nextLine();
				String[] parts = str.split(",");
				if(!parts[0].equals(aName))
				{
					number++;
				}
				else
				{
					customer.add(new Customer(parts[0], parts[1], parts[2],number)); 
					return customer;
				}
				
			}
			inputFile.close();
		}
		catch(FileNotFoundException ex)
		{
			System.out.print("error");
		}
		
		
		return customer;
	}
	
	public static void editAndSaveLine(String filePath, int lineToEdit, String newText) //Edit and save the line to the text file
    {
        try 
        {
        	Scanner input = new Scanner(System.in);
            // Read the original content into memory
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            StringBuilder content = new StringBuilder();
            String line;
           
            int lineNumber = 0;

            while ((line = reader.readLine()) != null) 
            {
                lineNumber++;

                if (lineNumber == lineToEdit) {
                    // Replace the line you want to edit with the new text
                    content.append(newText).append("\n");
                } else {
                    // Keep other lines unchanged
                    content.append(line).append("\n");
                }
            }

            reader.close();

            // Write the modified content back to the file
            PrintWriter writer = new PrintWriter(new FileWriter(filePath));
            writer.write(content.toString());
            writer.close();

            System.out.println("Data edited and saved.");
            System.out.println("Please Login again...");
            input.nextLine();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
	
	public static boolean DisplayProfile(ArrayList<Customer> customerList,ArrayList<Appointment> appointmentList, String customerFile) //Display the customer's informations
	{
		Scanner input = new Scanner(System.in);
		boolean progress = true;
		
		String dateAndTime = LoginSystemForStaff.CurrentDateAndTimeToString(); //print the date and time
		
		System.out.println("--------------------------------------------------------------------------------------------------------------------");
        System.out.println("Profile\t\t\t\t\t\t\t\t\t\t\t\t" + dateAndTime);
        System.out.println("--------------------------------------------------------------------------------------------------------------------");
        System.out.print("Phone Number for Verification(without dash): ");
        for(Customer customer : customerList)
		{
        	String name = customer.getName();
        	String phoneNum = customer.getPhoneNum();
        	String password = customer.getPw();
        	int number = customer.getLineNum();
			String verification = input.nextLine();
			
			if (!verification.equals(phoneNum))
	        {
	            System.out.println("Wrong phone number Entered");
	        } 
	        else 
	        {
	        	System.out.println();
	            System.out.println("Name: " + name);
	            System.out.println("Phone Number: " + phoneNum);
	            
	            ArrayList<Appointment> customerAppointments = new ArrayList<>();
		        for (Appointment appointment : appointmentList) 
		        {
		            if (appointment.getCustomerName().equalsIgnoreCase(name)) 
		            {
		                customerAppointments.add(appointment);
		            }
		        }

		        if (customerAppointments.isEmpty()) 
		        {
		            System.out.println("No appointments found for the customer.");
		            break;
		        }

		        // Display customer's appointments
		        System.out.println("Appointments:");
		        for (int i = 0; i < customerAppointments.size(); i++) 
		        {
		            Appointment appointment = customerAppointments.get(i);
		            System.out.println((i + 1) + ". Stylist: " + appointment.getStylistName() +
		                    ", Date: " + appointment.getDate() +
		                    ", Time: " + appointment.getTime() + ", Package: " + appointment.getSelectedPackage());
		           
		        }

	            System.out.println();
	            boolean repeat = true;
	            
	            //Allow Customers to edit their information
	            do
	            {
		            System.out.print("Edit Profile (y/n): ");
		            String choice = input.next();
		            choice = choice.toUpperCase();
		            input.nextLine();
		            
		            if (choice.equals("Y")) 
		            {
		    			
		            	System.out.println("--------------------------------------------------------------------------------------------------------------------");
		                System.out.println("Please Enter Your Latest Information");
		                System.out.println("--------------------------------------------------------------------------------------------------------------------");
		                
		                System.out.print("Name: ");
		                String newName = input.nextLine();
		                System.out.print("Phone Number(without dash): ");
		                String newPhoneNum = input.nextLine();
		                String newText = (newName + "," + newPhoneNum + "," + password);
		                
		                editAndSaveLine("CustomerList.txt", number, newText);
		                progress = false;
		                repeat = false;
		            }
		            else if(choice.equals("N"))
		            {
		            	progress = true;
		            	repeat = false;
		            }
		            else
		            {
		            	if(!choice.equals("Y") && !choice.equals("N"))
		            	{
		            		System.out.println("Invalid option, Please try again...");
		            		repeat = true;
		            	}
		            }
	            }while (repeat == true);
	            
	        }
		} 
        return progress;
	}
}
	


