import java.util.*;
import java.io.*;


public class LoginSystemForManager {
	private String name;
	private String password;
	
	public String getName()
	{
		return name;
	}
	
	public String getPassword()
	{
		return password;
	}
	
	LoginSystemForManager(String theName, String thePassword)
	{
		this.name = theName;
		this.password = thePassword;
	}
	
	public static int coverPage()
	{
		String dateAndTime = LoginSystemForStaff.CurrentDateAndTimeToString() ;
		
		Scanner input = new Scanner(System.in);
		System.out.println("--------------------------------------------------------------------------------------------------------------------");
		System.out.println("Welcome to Beauty Salon\t\t\t\t\t\t\t\t\t\t" + dateAndTime); 
		System.out.println("--------------------------------------------------------------------------------------------------------------------");
		
		System.out.println("<1> LogIn");
		System.out.println("<2> Exit");
		

		String InitialOption = input.next();
		int FinalOption = 0;
		
		switch(InitialOption)
		{
			case"1":
			{
				FinalOption = 1; //Login system
				break;
			}
			case"2":
			{
				FinalOption = 2; //Exit
				System.out.println("See you next time~~");
				break;
			}
			default:
				System.out.println("Invalid Option, Please Try Again...");
				System.out.println();
		}
		return FinalOption;
	}
	
}
	