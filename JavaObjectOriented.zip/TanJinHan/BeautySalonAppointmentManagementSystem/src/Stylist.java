import java.util.*;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Stylist 
{
	private String name; //stylist name
	private ArrayList<String> availableTimeSlots;
	
	public String getName()
	{
		return name;
	}
	
	public ArrayList<String> getAvailableTimeSlots()
	{
		return availableTimeSlots;
	}	
	
	//constructor
	public Stylist(String name)
	{
		this.name = name;
		this.availableTimeSlots = new ArrayList<>();
	}
	
	public void addAvailableTimeSlots(String timeSlot) // add new available time slot
	{
		availableTimeSlots.add(timeSlot);
	}

	public void viewAvailableTimeSlots()
	{
		System.out.println(name + ":");
		for(String timeSlot : availableTimeSlots)
		{
			System.out.println(timeSlot);
		}
		
	}
	
	public static ArrayList<Stylist> loadStylistsFromFile() // view the stylist's available time from stylist.txt
	{
		ArrayList <Stylist> stylistList = new ArrayList<>();
		
		try(Scanner scanner = new Scanner(new FileReader("stylists.txt")))
		{
			while(scanner.hasNextLine())
			{
				String line = scanner.nextLine();
				String[] parts = line.split(",");
				if(parts.length >= 1)
				{
					String name = parts[0];
					Stylist stylist = new Stylist(name); //create stylist object
					
					for(int i = 1; i < parts.length; i++)
					{
						stylist.addAvailableTimeSlots(parts[i]);
					}
					
					stylistList.add(stylist);
				}
			}
		} catch(IOException e)
		{
			System.out.println("An error occurred while reading stylist data from file. ");
			e.printStackTrace();
		}
		
		return stylistList;
	}
	
	public static void saveStylistsToFile(ArrayList<Stylist> stylistList) //save the stylist's available time to stylist.txt
	{
		try(FileWriter writer = new FileWriter ("stylists.txt"))
		{
			for(Stylist stylist : stylistList)
			{
				StringBuilder line = new StringBuilder(stylist.getName());
				for(String timeSlot : stylist.getAvailableTimeSlots())
				{
					line.append(",").append(timeSlot);
				}
				writer.write(line.toString() + "\n");
				
			}
			System.out.println();
			System.out.println("Stylists saved to file.");
		}catch(IOException e)
		{
				System.out.println("An error occurred whie saving stylist data to file");
				e.printStackTrace();
		}
	
	}


	public static void writeStylistAvaibility(ArrayList<Stylist> stylistSlot) // write the new stylist available time to stylist.txt
	{
		try
		{
			FileWriter fw = new FileWriter("stylists.txt");
		
			for(Stylist stylist : stylistSlot)
			{
				
				StringBuilder avaibility = new StringBuilder(stylist.getName());
				for(String timeSlot : stylist.getAvailableTimeSlots())
				{
					avaibility.append(",").append(timeSlot);
				}
				fw.write(avaibility.toString() + "\n");
				
				
			}	
			fw.close();
			System.out.println("New week avaibility time slot update successfully.");
		}catch(IOException e)
		{
			System.out.println("An error occurred while writing to the file.");
			e.printStackTrace();
		}
		
		}
	
	
}
