package Assignment;

import java.util.*;

public class WordGenerator {

    private static final String CHARACTERS = "abcdefghijklmnopqrstuvwxyz";
    private static final int WORD_LENGTH_MIN = 3;
    private static final int WORD_LENGTH_MAX = 30;
    private static final Random RANDOM = new Random();

    // Generate a random word
    private String generateRandomWord() {
        int length = WORD_LENGTH_MIN + RANDOM.nextInt(WORD_LENGTH_MAX - WORD_LENGTH_MIN + 1);
        StringBuilder word = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            word.append(CHARACTERS.charAt(RANDOM.nextInt(CHARACTERS.length())));
        }
        return word.toString();
    }

    // This method allows duplicate words
    public List<String> generateDatasetOfWords(int wordCount) {
        List<String> words = new ArrayList<>();
        for (int i = 0; i < wordCount; i++) {
            words.add(generateRandomWord());
        }
        return words;
    }

    // Optional: Generate unique words (if needed)
    public List<String> generateUniqueWords(int wordCount) {
        Set<String> words = new HashSet<>();
        while (words.size() < wordCount) {
            words.add(generateRandomWord());
        }
        return new ArrayList<>(words);
    }

   
}

