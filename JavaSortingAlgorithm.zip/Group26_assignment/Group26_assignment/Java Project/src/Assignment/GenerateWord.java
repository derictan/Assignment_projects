package Assignment;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class GenerateWord {

		
	    public static void main(String[] args) {
	        // Initialize the word generator
	        WordGenerator generator = new WordGenerator();
	        int wordCount = 900000;  // The number of words to generate

	        // Generate the dataset with or without duplicates
	        // Use either 'generateDatasetOfWords' to allow duplicates or 'generateUniqueWords' for unique words
	        List<String> dataset = generator.generateDatasetOfWords(wordCount);  // With duplicates
	        //List<String> dataset = generator.generateUniqueWords(wordCount);     // Without duplicates

	        System.out.println("Dataset generated with size: " + dataset.size());

	        // Specify the file path for saving the dataset
	        // Use "wordsData.txt" for datasets with duplicates or another filename for unique datasets
	        String filePath = "900k_wordsData.txt";  // File for words with duplicates
	        //String filePath = "1M_wordsNonDuplicateData.txt";  // File for unique words

	        // Write the generated words to the specified file
	        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
	            for (String word : dataset) {
	                writer.write(word);
	                writer.newLine();  // Add a new line after each word
	            }
	            System.out.println("Words have been written to " + filePath);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}


