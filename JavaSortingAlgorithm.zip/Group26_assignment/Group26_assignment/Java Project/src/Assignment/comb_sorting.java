package Assignment;
import java.io.File;
import java.util.*;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
public class comb_sorting {
	    
	    
	    public static void main(String args[])
	    {
	    	//String[] fileSizes = {"numbers_100000.txt"};
	    	
	        String directoryPath = "C:/numbers_1M";

	    	// Create ArrayLists and LinkedLists for Average Case and Worst Case
	        ArrayList<Integer> numbersListAverageArray = new ArrayList<>();
	        ArrayList<Integer> numbersListWorstArray = new ArrayList<>();
	        LinkedList<Integer> numbersListAverageLinked = new LinkedList<>();
	        LinkedList<Integer> numbersListWorstLinked = new LinkedList<>();
	        
	        //Run all files in numbers_1M
	        File directory = new File(directoryPath);
	        File[] files=directory.listFiles();
	        
	        /*for (String fileName : fileSizes) {
	        File file = new File(directoryPath + fileName);*/
	    	
	        if (files != null) {
	            for (File file : files) {
	                if (file.isFile()) {
	                    // Clear lists before processing new file
	                    numbersListAverageArray.clear();
	                    numbersListWorstArray.clear();
	                    numbersListAverageLinked.clear();
	                    numbersListWorstLinked.clear();

	        //comb_sorting ob = new comb_sorting();
	        try {
	            Scanner scanner = new Scanner(file);

	            while (scanner.hasNext()) {
	                if (scanner.hasNextInt()) {
	                    int number = scanner.nextInt();
	                    numbersListAverageArray.add(number);  // For ArrayList
	                    numbersListAverageLinked.add(number);  // For LinkedList

	                    } else {
	                    scanner.next(); // Skip any non-integer values
	                }
	            }
	        scanner.close();
	        } catch (Exception ex) {
	        	System.out.println(ex);
	        }
	        
	        numbersListWorstArray.addAll(numbersListAverageArray);  // Clone the list for worst case (ArrayList)
	        Collections.sort(numbersListWorstArray, Collections.reverseOrder());  // Reverse sort for worst case (ArrayList)

	        numbersListWorstLinked.addAll(numbersListAverageLinked);  // Clone the list for worst case (LinkedList)
	        Collections.sort(numbersListWorstLinked, Collections.reverseOrder());  // Reverse sort for worst case (LinkedList)

	        // Create instances of comb sorting for both ArrayList and LinkedList
	        CombSorting<ArrayList<Integer>, Integer> combSortArrayAverage = new CombSorting<>(numbersListAverageArray, 1.3);
	        CombSorting<ArrayList<Integer>, Integer> combSortArrayWorst = new CombSorting<>(numbersListWorstArray, 1.3);
	        CombSorting<LinkedList<Integer>, Integer> combSortLinkedAverage = new CombSorting<>(numbersListAverageLinked, 1.3);
	        CombSorting<LinkedList<Integer>, Integer> combSortLinkedWorst = new CombSorting<>(numbersListWorstLinked, 1.3);

	        // Sorting and timing for ArrayList Average Case
	        long startAverageArray = System.currentTimeMillis();
	        combSortArrayAverage.sort();  // Sort the Average Case ArrayList
	        long endAverageArray = System.currentTimeMillis();
            
	        System.out.println("Time used to sort the Average Case (ArrayList)for file "+file.getName()+": " + (endAverageArray - startAverageArray) + " ms");
	        //System.out.println("Sorted Average Case (ArrayList) for file " + file.getName() + ":");
            
	        // Sorting and timing for ArrayList Worst Case
	        long startWorstArray = System.currentTimeMillis();
	        combSortArrayWorst.sort();  // Sort the Worst Case ArrayList
	        long endWorstArray = System.currentTimeMillis();
	        System.out.println("Time used to sort the Worst Case (ArrayList)for file "+file.getName()+": " + (endWorstArray - startWorstArray) + " ms");

	        // Sorting and timing for LinkedList Average Case
	        long startAverageLinked = System.currentTimeMillis();
	        combSortLinkedAverage.sort();  // Sort the Average Case LinkedList
	        long endAverageLinked = System.currentTimeMillis();
	        System.out.println("Time used to sort the Average Case (LinkedList)for file "+file.getName()+": " + (endAverageLinked - startAverageLinked) + " ms");

	        // Sorting and timing for LinkedList Worst Case
	        long startWorstLinked = System.currentTimeMillis();
	        combSortLinkedWorst.sort();  // Sort the Worst Case LinkedList
	        long endWorstLinked = System.currentTimeMillis();
	        System.out.println("Time used to sort the Worst Case (LinkedList)for file "+file.getName()+": " +(endWorstLinked - startWorstLinked) + " ms");
	        long start=System.currentTimeMillis();
	        System.out.println();

	        /*for (int i=0; i<arr.length; ++i)
	            System.out.println(arr[i]);
	        ob.sort(numbersList);
	        long end=System.currentTimeMillis();
	        System.out.println("Time used to sort the numbers: "+(end-start)+" ms");*/
	    }
	}
}else {
    System.out.println("Directory does not exist or is not a directory.");

}
	    } /*
	    printList(numbersListAverageArray);
	    private static <T> void printList(List<T> list) {
	        for (T item : list) {
	            System.out.println(item + " ");
	        }
	        System.out.println(); // Ensure a new line at the end
	    }*/
}


