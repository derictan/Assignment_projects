package Assignment;

import java.util.*;

public class DataContainer<T extends Comparable<T>> {
    
    // Define the data structures you want to store
    private List<T> arrayList;
    private List<T> linkedList;
    
    // Constructor to initialize the data structures
    public DataContainer() {
        arrayList = new ArrayList<>();
        linkedList = new LinkedList<>();
    }

    // Getters for the data structures
    public List<T> getArrayList() {
        return arrayList;
    }

    public List<T> getLinkedList() {
        return linkedList;
    }

    // Method to populate the lists with data (shared logic)
    public void loadData(T[] data) {
        arrayList.clear();
        linkedList.clear();
        Collections.addAll(arrayList, data);
        Collections.addAll(linkedList, data);
    }
    
 
}
