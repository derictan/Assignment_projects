package Assignment;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

public class TimSortLinkedList {

    // Minimum size of a run
    private static final int RUN = 64;
    private static final int THREAD_POOL_SIZE = Runtime.getRuntime().availableProcessors(); // Number of threads

    // Function to sort the given LinkedList using TimSort with multi-threading
    public static void timSort(LinkedList<Integer> list) {
        int n = list.size();
        ExecutorService executor = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
        List<Future<?>> futures = new ArrayList<>();

        // Sort individual sublists of size RUN in parallel
        try {
            int i = 0;
            while (i < n) {
                final int start = i;
                final int end = Math.min((i + RUN - 1), (n - 1));
                futures.add(executor.submit(() -> insertionSort(list, start, end)));
                i += RUN;
            }

            // Wait for all sorting tasks to complete
            for (Future<?> future : futures) {
                try {
                    future.get();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            // Merge the sorted sublists
            int size = RUN;
            while (size < n) {
                futures.clear(); // Clear the list of futures for the next round
                int left = 0;
                while (left < n) {
                    // Find the middle and right for the current sublist
                    int mid = left + size - 1;
                    int right = Math.min((left + 2 * size - 1), (n - 1));

                    // Merge the sorted sublists
                    if (mid < right) {
                        final int l = left;
                        final int m = mid;
                        final int r = right;
                        futures.add(executor.submit(() -> merge(list, l, m, r)));
                    }
                    left += 2 * size;
                }

                // Wait for all merging tasks to complete
                for (Future<?> future : futures) {
                    try {
                        future.get();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                size = 2 * size;
            }
        } finally {
            executor.shutdown();
        }
    }

    // Function to perform insertion sort on a sublist
    private static void insertionSort(LinkedList<Integer> list, int left, int right) {
        ListIterator<Integer> iterator = list.listIterator(left);

        // Create a temporary LinkedList to hold the elements
        LinkedList<Integer> tempList = new LinkedList<>();
        while (iterator.nextIndex() <= right) {
            tempList.add(iterator.next());
        }

        // Perform insertion sort on the LinkedList
        for (int i = 1; i < tempList.size(); i++) {
            int temp = tempList.get(i);
            int j = i - 1;
            while (j >= 0 && tempList.get(j) > temp) {
                tempList.set(j + 1, tempList.get(j));
                j--;
            }
            tempList.set(j + 1, temp);
        }

        // Copy the sorted list back to the LinkedList
        iterator = list.listIterator(left);
        for (int value : tempList) {
            iterator.next();
            iterator.set(value);
        }
    }

    // Function to merge two sorted sublists list[left...mid] and list[mid+1...right]
    private static void merge(LinkedList<Integer> list, int left, int mid, int right) {
        LinkedList<Integer> leftList = new LinkedList<>();
        LinkedList<Integer> rightList = new LinkedList<>();

        ListIterator<Integer> iterator = list.listIterator(left);
        for (int i = left; i <= mid; i++) {
            leftList.add(iterator.next());
        }
        for (int i = mid + 1; i <= right; i++) {
            rightList.add(iterator.next());
        }

        // Merge the temporary lists back into the original list
        int l = 0, r = 0, k = left;
        while (l < leftList.size() && r < rightList.size()) {
            if (leftList.get(l) <= rightList.get(r)) {
                list.set(k++, leftList.get(l++));
            } else {
                list.set(k++, rightList.get(r++));
            }
        }

        while (l < leftList.size()) {
            list.set(k++, leftList.get(l++));
        }

        while (r < rightList.size()) {
            list.set(k++, rightList.get(r++));
        }
    }
}
