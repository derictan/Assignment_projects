package Assignment;

import java.util.*;
import java.io.*;

public class RadixSortTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Choose what to sort: "
                    + "\n(1) Numbers "
                    + "\n(2) Words  "
                    + "\n(3) Exit");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    handleNumberSorting(scanner);
                    break;

                case 2:
                    handleWordSorting(scanner);
                    break;

                case 3:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice.");
                    break;
            }
        }
    }

    // Method numbers sorting 
    private static void handleNumberSorting(Scanner scanner) {
        System.out.println("Choose data type for sorting: "
                + "\n(1) Sort with normal data "
                + "\n(2) Sort with non-duplicated data");
        int dataChoice = scanner.nextInt();

        switch (dataChoice) {
            case 1: // press 1 to sort numbers data
                sortNumbersFromFiles("normal");
                break;

            case 2:// press 2 to sort non duplicated numbers data
                sortNumbersFromFiles("nonDuplicated");
                break;

            default:
                System.out.println("Invalid choice.");
                break;
        }
    }

    // Method for words sorting 
    private static void handleWordSorting(Scanner scanner) {
        System.out.println("Choose data type for sorting: "
                + "\n(1) Sort with normal data "
                + "\n(2) Sort with non-duplicated data");
        int dataChoice = scanner.nextInt();

        switch (dataChoice) {
            case 1:// press 1 to sort words data
                sortWordsFromFiles("normal");
                break;

            case 2:// press 2 to sort non duplicated numbers data
                sortWordsFromFiles("nonDuplicated");
                break;

            default:
                System.out.println("Invalid choice.");
                break;
        }
    }

    // Method to sort numbers from files
    private static void sortNumbersFromFiles(String type) {
        String basePath = "C:/numbers_1M/";// path location
        String suffix = type.equals("normal") ? ".txt" : "_nonDuplicated.txt";

        // Iterate for sizes 100k to 500k in increments of 100k
        for (int size = 100000; size <= 1000000; size += 100000) {
            String filePath = basePath + "numbers_" + size + suffix;
            if (new File(filePath).exists()) {
                System.out.println("Retrieving data from " + filePath + "...");
                performNumberSortingFromFile(filePath, size);
            } else {
                System.out.println("File not found: " + filePath);
            }
        }

        // Continue sorting for sizes from 1 million to 10 million in increments of 1 million
        for (int size = 1000000; size <= 10000000; size += 1000000) {
            String filePath = basePath + "numbers_" + size + suffix;
            if (new File(filePath).exists()) {
                System.out.println("Retrieving data from " + filePath + "...");
                performNumberSortingFromFile(filePath, size);
            } else {
                System.out.println("File not found: " + filePath);
            }
        }
    }

    // Method to sort words from files
    private static void sortWordsFromFiles(String type) {
        String basePath = "C:/words_1M/";
        String suffix = type.equals("normal") ? "Data.txt" : "NonDuplicateData.txt";

        // Iterate for sizes 100k to 500k in increments of 100k
        for (int size = 100000; size <= 500000; size += 100000) {
            String filePath = basePath + size / 1000 + "k_words" + suffix;
            if (new File(filePath).exists()) {
                System.out.println("Retrieving data from " + filePath + "...");
                performWordSortingFromFile(filePath, size);
            } else {
                System.out.println("File not found: " + filePath);
            }
        }
    }

    // Method to perform number sorting from a file
    private static void performNumberSortingFromFile(String filePath, int size) {
        try {
            List<Integer> arrayListNumbers = loadNumbersFromFile(filePath, new ArrayList<>());
            List<Integer> linkedListNumbers = loadNumbersFromFile(filePath, new LinkedList<>());

            System.out.println("Completed loading data for size " + size + "\n");
            performNumberSorting(arrayListNumbers, linkedListNumbers, size);
        } catch (IOException e) {
            System.out.println("Error loading numbers from " + filePath + ": " + e.getMessage());
        }
    }

    // Method to perform word sorting from a file
    private static void performWordSortingFromFile(String filePath, int size) {
        try {
            List<String> words = loadWordsFromFile(filePath);

            System.out.println("Completed loading data for size " + size + "\n");
            performWordSorting(words, size);
        } catch (IOException e) {
            System.out.println("Error loading words from " + filePath + ": " + e.getMessage());
        }
    }

    // Method to load numbers from a file into a list
    private static List<Integer> loadNumbersFromFile(String filePath, List<Integer> list) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                list.add(Integer.parseInt(line.trim()));
            }
        }
        return list;
    }

    // Method to load words from a file into a list
    private static List<String> loadWordsFromFile(String filePath) throws IOException {
        List<String> words = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                words.add(line.trim());
            }
        }
        return words;
    }

    // Method to perform number sorting
    private static void performNumberSorting(List<Integer> arrayListNumbers, List<Integer> linkedListNumbers, int size) {
        System.out.println("Sorting data of size " + size);

        // ArrayList Sorting
        System.out.println("\nSorting with ArrayList:");
        long arrayListTime = RadixSorter.sortNumbers(new ArrayList<>(arrayListNumbers));
        System.out.println("ArrayList sort (Average Case): " + arrayListTime + " ms.");

        long worstCaseArrayListTime = RadixSorter.sortWorstCaseNumbers(new ArrayList<>(arrayListNumbers));
        System.out.println("ArrayList sort (Worst Case): " + worstCaseArrayListTime + " ms.");

        // LinkedList Sorting
        System.out.println("\nSorting with LinkedList:");
        long linkedListTime = RadixSorter.sortNumbers(new LinkedList<>(linkedListNumbers));
        System.out.println("LinkedList sort (Average Case): " + linkedListTime + " ms.");

        long worstCaseLinkedListTime = RadixSorter.sortWorstCaseNumbers(new LinkedList<>(linkedListNumbers));
        System.out.println("LinkedList sort (Worst Case): " + worstCaseLinkedListTime + " ms.");
    }

    // Method to perform word sorting
    private static void performWordSorting(List<String> words, int size) {
        System.out.println("Sorting words of size " + size);

        // ArrayList Sorting
        System.out.println("\nSorting with ArrayList:");
        long arrayListTime = RadixSorter.sortWords(new ArrayList<>(words));
        System.out.println("ArrayList sort (Average Case): " + arrayListTime + " ms.");

        long worstCaseArrayListTime = RadixSorter.sortWorstCaseWords(new ArrayList<>(words));
        System.out.println("ArrayList sort (Worst Case): " + worstCaseArrayListTime + " ms.");

        // LinkedList Sorting
        System.out.println("\nSorting with LinkedList:");
        long linkedListTime = RadixSorter.sortWords(new LinkedList<>(words));
        System.out.println("LinkedList sort (Average Case): " + linkedListTime + " ms.");

        long worstCaseLinkedListTime = RadixSorter.sortWorstCaseWords(new LinkedList<>(words));
        System.out.println("LinkedList sort (Worst Case): " + worstCaseLinkedListTime + " ms.");
    }
}
