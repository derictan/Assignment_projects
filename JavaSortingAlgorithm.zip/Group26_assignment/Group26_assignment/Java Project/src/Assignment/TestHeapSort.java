package Assignment;
import java.util.*;
import java.io.*;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;


public class TestHeapSort {
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		  // Ask the user for their choice
        System.out.println("Do you want to sort numbers or words?");
        System.out.println("Type '1' for numbers or '2' for words:");
        int choice = scanner.nextInt();  // Capture user's choice
        scanner.nextLine();
        if (choice == 1) {
            sortNumbers();
        } else if (choice == 2) {
            sortWords();
        } else {
            System.out.println("Invalid choice! Please type '1' for numbers or '2' for words.");
        }
        
        scanner.close();
    }
	
	 // Method to handle number sorting
    	public static void sortNumbers() {
    		//test with small data(size 20)
    		List<String> fileNames = Arrays.asList("20_numbers.txt");
    		
    		
    		//test with duplicated data
    		//List<String> fileNames = Arrays.asList("numbers_100000.txt", "numbers_200000.txt", "numbers_300000.txt", "numbers_400000.txt", "numbers_500000.txt","numbers_600000.txt", "numbers_700000.txt", "numbers_800000.txt", "numbers_900000.txt", "numbers_1000000.txt");
    		
    		//test with non duplicate data
    		
    		//test for arraylist with data size up to 10M
    		//List<String> fileNames = Arrays.asList("numbers_2000000_nonDuplicated.txt", "numbers_3000000_nonDuplicated.txt", "numbers_4000000_nonDuplicated.txt", "numbers_5000000_nonDuplicated.txt", "numbers_6000000_nonDuplicated.txt","numbers_7000000_nonDuplicated.txt", "numbers_8000000_nonDuplicated.txt", "numbers_9000000_nonDuplicated.txt", "numbers_10000000_nonDuplicated.txt");
    		
            for (String fileName : fileNames) {
                System.out.println("Testing with file: " + fileName);

                // Create a DataContainer to hold data structures
                DataContainer<Integer> dataContainer = new DataContainer<>();

                // Load numbers into both ArrayList and LinkedList
                loadNumbersFromFile(fileName, dataContainer.getArrayList());
                dataContainer.loadData(dataContainer.getArrayList().toArray(new Integer[0]));

                // Perform the sorting (average and worst cases) for numbers, similar to previous code
                performSortingTests(fileName, dataContainer);
			
	        }
	    }
    	
    	public static void sortWords() {
    		//test with small dataset to esure correctness
    		List<String> fileNames = Arrays.asList("20_wordsData.txt");
    		
    		//test with duplicate words
    		//List<String> fileNames = Arrays.asList("100k_wordsData.txt", "200k_wordsData.txt", "300k_wordsData.txt", "400k_wordsData.txt", "500k_wordsData.txt");
    		
    		//test with non duplicate words
            //List<String> fileNames = Arrays.asList("100k_wordsNonDuplicateData.txt", "200k_wordsNonDuplicateData.txt", "300k_wordsNonDuplicateData.txt", "400k_wordsNonDuplicateData.txt", "500k_wordsNonDuplicateData.txt");

            for (String fileName : fileNames) {
                System.out.println("Testing with file: " + fileName);

                // Create a DataContainer to hold data structures
                DataContainer<String> dataContainer = new DataContainer<>();

                // Load words into both ArrayList and LinkedList
                loadWordsFromFile(fileName, dataContainer.getArrayList());
                dataContainer.loadData(dataContainer.getArrayList().toArray(new String[0]));

                // Perform the sorting (average and worst cases) for words, similar to previous code
                performSortingTests(fileName, dataContainer);
            }
        }

        // General method for performing sorting tests on both numbers and words
        public static <T extends Comparable<T>> void performSortingTests(String fileName, DataContainer<T> dataContainer) {
        	
            // Test with ArrayList - Average Case
            long startArrayList = System.currentTimeMillis();
            HeapSort.heapSort(dataContainer.getArrayList());  // Sort the ArrayList (average case)
            long endArrayList = System.currentTimeMillis();
            System.out.println("Elapsed time for ArrayList (average case) with " + fileName + " = " + (endArrayList - startArrayList) + " ms");
                  
            // Write sorted ArrayList to file
            //writeDataToFile("sorted_" + fileName + "_arraylist_average.txt", dataContainer.getArrayList());

            // Test with ArrayList - Worst Case (Inreasing order)
            long startArrayListWorst = System.currentTimeMillis();
            HeapSort.heapSort(dataContainer.getArrayList());  // Sort the sorted(increasing) ArrayList
            long endArrayListWorst = System.currentTimeMillis();
            System.out.println("Elapsed time for ArrayList (worst case) with " + fileName + " = " + (endArrayListWorst - startArrayListWorst) + " ms");

            // Write sorted ArrayList to file
            //writeDataToFile("sorted_" + fileName + "_arraylist_worst.txt", dataContainer.getArrayList());

            
            // Test with LinkedList - Average Case
            long startLinkedList = System.currentTimeMillis();
            HeapSort.heapSort(dataContainer.getLinkedList());  // Sort the LinkedList (average case)
            long endLinkedList = System.currentTimeMillis();
            System.out.println("Elapsed time for LinkedList (average case) with " + fileName + " = " + (endLinkedList - startLinkedList) + " ms");

            // Write sorted LinkedList to file
            //writeDataToFile("sorted_" + fileName + "_linkedlist_average.txt", dataContainer.getLinkedList());

            // Test with LinkedList - Worst Case (Increasing Order)
            long startLinkedListWorst = System.currentTimeMillis();
            HeapSort.heapSort(dataContainer.getLinkedList());  // Sort the sorted(increasing) LinkedList
            long endLinkedListWorst = System.currentTimeMillis();
            System.out.println("Elapsed time for LinkedList (worst case) with " + fileName + " = " + (endLinkedListWorst - startLinkedListWorst) + " ms");
            
            // Write sorted LinkedList to file
            //writeDataToFile("sorted_" + fileName + "_linkedlist_worst.txt", dataContainer.getLinkedList());
            
            //If test for small data, print out the sorted list, we will comment out if run with large data
            
            //For numbers
            /**
            System.out.println("Sorted numbers:");
            for (T number : dataContainer.getArrayList()) {
                System.out.print(number+" ");
            }**/
            
            //For words
            System.out.println("Sorted words:");
            for (T words : dataContainer.getArrayList()) {
                System.out.print(words+" ");
            }
            
            System.out.println();
        }

        // Placeholder methods to load numbers and words from files, and write results (these would need actual implementations)
        public static void loadNumbersFromFile(String fileName, List<Integer> list) {
        	try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    list.add(Integer.parseInt(line));  // Parse each line as an Integer and add it to the list
                }
            } catch (IOException e) {
                System.out.println("Error reading file: " + fileName);
                e.printStackTrace();
            }
        }

        public static void loadWordsFromFile(String fileName, List<String> list) {
        	try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    list.add(line);  // Add each line as a String (word) to the list
                }
            } catch (IOException e) {
                System.out.println("Error reading file: " + fileName);
                e.printStackTrace();
            }
        }

        public static <T> void writeDataToFile(String fileName, List<T> list) {
        	 try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
                 for (T item : list) {
                     writer.write(item.toString());
                     writer.newLine();  // Write each item on a new line
                 }
                 //System.out.println("Data successfully written to " + fileName);
             } catch (IOException e) {
                 System.out.println("Error writing to file: " + fileName);
                 e.printStackTrace();
             }
        }
/**
    // Method to load data from file into the list
    private static void loadDataFromFile(String fileName, List<Integer> list) {
        try (Scanner in = new Scanner(new File(fileName))) {
            while (in.hasNext()) {
                if (in.hasNextInt()) {
                    list.add(in.nextInt());
                } else {
                    in.next(); // Skip non-integer tokens
                }
            }
        } catch (IOException ex) {
            System.err.println("Error loading data from file: " + ex);
        }
    }

    // Method to write sorted data to a file
    private static void writeDataToFile(String fileName, List<T> list) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (Integer number : list) {
                writer.write(number.toString());
                writer.newLine();
            }
        } catch (IOException ex) {
            System.err.println("Error writing to file: " + ex);
        }
    }




    
    **/
    
    
    
    
    
    
    
    
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

		
		/**
	    for (String fileName : fileNames) {
	        System.out.println("Testing with file: " + fileName);

	        // 1. Test with ArrayList - Average Case
	        List<Integer> arrayList = new ArrayList<>();
	        loadDataFromFile(fileName, arrayList);  // Load random data into ArrayList

	        long startArrayList = System.currentTimeMillis();
	        //HeapSort.heapSort(arrayList);  // Sort the ArrayList (average case)
	        HeapSortIterator.heapSort(arrayList);  // Sort the ArrayList (average case)
	        long endArrayList = System.currentTimeMillis();
	        System.out.println("Elapsed time for ArrayList (average case) with " + fileName + " = " + (endArrayList - startArrayList) + " ms");

	        // Write sorted ArrayList (average case) to file
	        writeDataToFile("sorted_" + fileName + "_arraylist_average.txt", arrayList);

	        // 2. Test with ArrayList - Worst Case (Reverse Order)
	        //Collections.reverse(arrayList); // Reverse the sorted list to create the worst-case scenario
	        long startArrayListWorst = System.currentTimeMillis();
	        //HeapSort.heapSort(arrayList);  // Sort the reverse ArrayList (worst case)
	        HeapSortIterator.heapSort(arrayList);  // Sort the reverse ArrayList (worst case)
	        long endArrayListWorst = System.currentTimeMillis();
	        System.out.println("Elapsed time for ArrayList (worst case) with " + fileName + " = " + (endArrayListWorst - startArrayListWorst) + " ms");

	        // Write sorted ArrayList (worst case) to file
	        writeDataToFile("sorted_" + fileName + "_arraylist_worst.txt", arrayList);

	        // 3. Test with LinkedList - Average Case
	        List<Integer> linkedList = new LinkedList<>();
	        loadDataFromFile(fileName, linkedList);  // Load random data into LinkedList

	        long startLinkedList = System.currentTimeMillis();
	        //HeapSort.heapSort(linkedList);  // Sort the LinkedList (average case)
	        HeapSortIterator.heapSort(linkedList);  // Sort the LinkedList (average case)
	        long endLinkedList = System.currentTimeMillis();
	        System.out.println("Elapsed time for LinkedList (average case) with " + fileName + " = " + (endLinkedList - startLinkedList) + " ms");

	        // Write sorted LinkedList (average case) to file
	        writeDataToFile("sorted_" + fileName + "_linkedlist_average.txt", linkedList);

	        // 4. Test with LinkedList - Worst Case (Reverse Order)
	        //Collections.reverse(linkedList); // Reverse the sorted list to create the worst-case scenario
	        long startLinkedListWorst = System.currentTimeMillis();
	        //HeapSort.heapSort(linkedList);  // Sort the reverse LinkedList (worst case)
	        HeapSortIterator.heapSort(linkedList);  // Sort the reverse LinkedList (worst case)
	        long endLinkedListWorst = System.currentTimeMillis();
	        System.out.println("Elapsed time for LinkedList (worst case) with " + fileName + " = " + (endLinkedListWorst - startLinkedListWorst) + " ms");
	        System.out.println();
	        
	        
	        // Write sorted LinkedList (worst case) to file
	        writeDataToFile("sorted_" + fileName + "_linkedlist_worst.txt", linkedList);
		}
	}
		
		private static void loadDataFromFile(String fileName, List<Integer> list) {
		    try (Scanner in = new Scanner(new File(fileName))) {
		        while (in.hasNext()) {
		            if (in.hasNextInt()) {
		                list.add(in.nextInt());
		            } else {
		                in.next(); // Skip non-integer tokens
		            }
		        }
		    } catch (IOException ex) {
		        System.err.println("Error loading data from file: " + ex);
		    }
		}

		// Method to write sorted data to file
		private static void writeDataToFile(String fileName, List<Integer> list) {
		    try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
		        for (Integer number : list) {
		            writer.write(number.toString());
		            writer.newLine();
		        }
		    } catch (IOException ex) {
		        System.err.println("Error writing to file: " + ex);
		    }
		}
	
		/**
		//ArrayList numbers
		List<Integer> intList = new ArrayList<>(1000000);
		try {
            Scanner in = new Scanner(new File("100k_numbers.txt"));
            while (in.hasNext()) {
                // Check if the next token is an integer
                if (in.hasNextInt()) {
                    intList.add(in.nextInt());
                } else {
                    // Skip non-integer tokens
                    in.next(); // consume the token
                }
            }
            in.close();
        } catch (IOException ex) {
            System.err.println(ex);
        }

		long start = System.currentTimeMillis();
        //System.out.println("Original Integer List: " + intList);
        HeapSort.heapSort(intList);
        //HeapSortIterator.heapSort(intList);
        //System.out.println("Sorted Integer List: " + intList);
        long end = System.currentTimeMillis(); //stop the timer
		System.out.println("Elapse time for Arraylist =" +(end-start)+ "ms");
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("sorted_numbers.txt"))) {
            for (Integer number : intList) {
                writer.write(number.toString());
                writer.newLine(); // Write each number on a new line
            }
        } catch (IOException ex) {
            System.err.println("Error writing to file: " + ex);
        }
       
        
		
		//Testing
		//List<Integer> intListt = new LinkedList<>(Arrays.asList(2, 4, 6, 42, 64, 25, 64));
		
		
		//Numbers in LinkedList  take super long time
        List<Integer> intList1 = new LinkedList<>();
        try {
        	//try with smaller dataset
            Scanner in = new Scanner(new File("100k_numbers.txt"));
            
            // Using ListIterator to add elements
            ListIterator<Integer> iterator = intList1.listIterator();
            
            while (in.hasNext()) {
                // Check if the next token is an integer
                if (in.hasNextInt()) {
                    iterator.add(in.nextInt());
                } else {
                    // Skip non-integer tokens
                    in.next(); // consume the token
                }
            }
            in.close();
        } catch (IOException ex) {
            System.err.println(ex);
        }
		
		
        long start1 = System.currentTimeMillis();
        //System.out.println("Original Integer List: " + intList1);
        HeapSort.heapSort(intList1);
        
        //HeapSortIterator.heapSort(intList1);
        long end1 = System.currentTimeMillis(); //stop the timer
		System.out.println("Elapse time for Linkedlist =" +(end1-start1)+" ms");
		
		
        //System.out.println("Sorted Integer List: " + intList1);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("sorted_numbers_1.txt"))) {
            for (Integer number : intList1) {
                writer.write(number.toString());
                writer.newLine(); // Write each number on a new line
            }
        } catch (IOException ex) {
            System.err.println("Error writing to file: " + ex);
        }
       
       /**
		for (Integer number : intListt) {
            System.out.print(number + " ");
        }
        **/
		
		// Words example with ArrayList
		/**
        List<String> strList1 = new ArrayList<>();
        
        try (Scanner in = new Scanner(new File("wordsNonDuplicateData.txt"))) {
            while (in.hasNextLine()) {
                String line = in.nextLine();
                String[] words = line.split("\\W+"); // Split based on non-word characters

                // For each word in the line
                for (String word : words) {
                    if (word.trim().length() > 0) {
                        strList1.add(word.trim());
                    }
                }
            }
        } catch (Exception ex) {
            System.err.println(ex);
        }
        
        long start2 = System.currentTimeMillis();
        //System.out.println("Original String List: " + strList1);
        HeapSort.heapSort(strList1);
        //System.out.println("Sorted String List: " + strList1);
        long end2 = System.currentTimeMillis(); //stop the timer
		System.out.println("Elapse time for Words in Arraylist =" +(end2-start2));
		
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("sorted_unique_words.txt"))) {
			for (String word : strList1) {
	                writer.write(word);
	                writer.newLine(); // Write each word on a new line
	            }
	        } catch (IOException ex) {
	            System.err.println("Error writing to file: " + ex);
	        }
	    }
		**/
		
		/**
        // Words example with LinkedList
        List<String> strList = new LinkedList<>();
        //System.out.println("Original String List: " + strList);
        
        try (Scanner in = new Scanner(new File("wordsData.txt"))) {
            while (in.hasNextLine()) {
                String line = in.nextLine();
                String[] words = line.split("\\W+"); // Split based on non-word characters

                // For each word in the line
                for (String word : words) {
                    if (word.trim().length() > 0) {
                        strList.add(word.trim());
                    }
                }
            }
        } catch (Exception ex) {
            System.err.println(ex);
        }
        
        long start3 = System.currentTimeMillis();
        //System.out.println("Original String List: " + strList);
        HeapSort.heapSort(strList);
        //System.out.println("Sorted String List: " + strList);
        long end3 = System.currentTimeMillis(); //stop the timer
		System.out.println("Elapse time for Words in Arraylist =" +(end3-start3));
		
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("sorted_words.txt"))) {
			for (String word : strList) {
	                writer.write(word);
	                writer.newLine(); // Write each word on a new line
	            }
	        } catch (IOException ex) {
	            System.err.println("Error writing to file: " + ex);
	        }
	    }
        
		
		**/
	
		/**
		  List<String> fileNames = Arrays.asList("100k_numbers.txt", "200k_numbers.txt", "300k_numbers.txt", "400k_numbers.txt", "500k_numbers.txt");
	
			for (String fileName : fileNames) {
	            System.out.println("Testing with file: " + fileName);
	
	            // Create a DataContainer to hold data structures
	            DataContainer<Integer> dataContainer = new DataContainer<>();
	
	            // Load data into both ArrayList and LinkedList
	            loadDataFromFile(fileName, dataContainer.getArrayList());
	            dataContainer.loadData(dataContainer.getArrayList().toArray(new Integer[0]));
	
	            // 1. Test with ArrayList - Average Case
	            long startArrayList = System.currentTimeMillis();
	            HeapSort.heapSort(dataContainer.getArrayList());  // Sort the ArrayList (average case)
	            long endArrayList = System.currentTimeMillis();
	            System.out.println("Elapsed time for ArrayList (average case) with " + fileName + " = " + (endArrayList - startArrayList) + " ms");
	
	            // Write sorted ArrayList to file
	            writeDataToFile("sorted_" + fileName + "_arraylist_average.txt", dataContainer.getArrayList());
	
	            // 2. Test with ArrayList - Worst Case (Reverse Order)
	            //Collections.reverse(dataContainer.getArrayList()); // Reverse to create the worst-case scenario
	            long startArrayListWorst = System.currentTimeMillis();
	            HeapSort.heapSort(dataContainer.getArrayList());  // Sort the reversed ArrayList
	            long endArrayListWorst = System.currentTimeMillis();
	            System.out.println("Elapsed time for ArrayList (worst case) with " + fileName + " = " + (endArrayListWorst - startArrayListWorst) + " ms");
	
	            // Write sorted ArrayList to file
	            writeDataToFile("sorted_" + fileName + "_arraylist_worst.txt", dataContainer.getArrayList());
	
	            // 3. Test with LinkedList - Average Case
	            long startLinkedList = System.currentTimeMillis();
	            HeapSort.heapSort(dataContainer.getLinkedList());  // Sort the LinkedList (average case)
	            long endLinkedList = System.currentTimeMillis();
	            System.out.println("Elapsed time for LinkedList (average case) with " + fileName + " = " + (endLinkedList - startLinkedList) + " ms");
	
	            // Write sorted LinkedList to file
	            writeDataToFile("sorted_" + fileName + "_linkedlist_average.txt", dataContainer.getLinkedList());
	
	            // 4. Test with LinkedList - Worst Case (Reverse Order)
	            //Collections.reverse(dataContainer.getLinkedList()); // Reverse the sorted list
	            long startLinkedListWorst = System.currentTimeMillis();
	            HeapSort.heapSort(dataContainer.getLinkedList());  // Sort the reversed LinkedList
	            long endLinkedListWorst = System.currentTimeMillis();
	            System.out.println("Elapsed time for LinkedList (worst case) with " + fileName + " = " + (endLinkedListWorst - startLinkedListWorst) + " ms");
	
	            // Write sorted LinkedList to file
	            writeDataToFile("sorted_" + fileName + "_linkedlist_worst.txt", dataContainer.getLinkedList());
		 */
		
		
	

