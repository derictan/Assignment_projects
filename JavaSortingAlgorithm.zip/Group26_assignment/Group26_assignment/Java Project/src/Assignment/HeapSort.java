package Assignment;

import java.util.*;


	public class HeapSort{
		public static <T extends Comparable<T>> void heapSort(List<T> list) {
	        if (list == null || list.size() < 2) {
	            return; // No need to sort if list is null or has fewer than 2 elements
	        }

	        int n = list.size();
	        if (list instanceof ArrayList) {
	            // Handle ArrayList
	            // Build the heap
	            int i = n / 2 - 1;
	            while (i >= 0) {
	                heapifyArrayList((ArrayList<T>) list, n, i);
	                i--;
	            }

	            // Extract elements from the heap one by one
	            i = n - 1;
	            while (i >= 0) {
	                // Move current root to the end
	                Collections.swap(list, 0, i);

	                // Call heapify on the reduced heap
	                heapifyArrayList((ArrayList<T>) list, i, 0);
	                i--;
	            }
	        } else if (list instanceof LinkedList) {
	            // Handle LinkedList
	            // Build the heap
	            int i = n / 2 - 1;
	            while (i >= 0) {
	                heapifyLinkedList((LinkedList<T>) list, n, i);
	                i--;
	            }

	            // Extract elements from the heap one by one
	            i = n - 1;
	            while (i >= 0) {
	                // Move current root to the end
	                Collections.swap(list, 0, i);

	                // Call heapify on the reduced heap
	                heapifyLinkedList((LinkedList<T>) list, i, 0);
	                i--;
	            }
	        }
	    }

	    private static <T extends Comparable<T>> void heapifyArrayList(ArrayList<T> list, int n, int i) {
	        int largest = i;
	        int left = 2 * i + 1;
	        int right = 2 * i + 2;

	        while (left < n) {
	            T largestValue = list.get(largest);
	            T leftValue = list.get(left);

	            if (leftValue.compareTo(largestValue) > 0) {
	                largest = left;
	                largestValue = leftValue;
	            }

	            if (right < n) {
	                T rightValue = list.get(right);
	                if (rightValue.compareTo(largestValue) > 0) {
	                    largest = right;
	                    largestValue = rightValue;
	                }
	            }

	            if (largest == i) {
	                break;
	            }

	            Collections.swap(list, i, largest);

	            i = largest;
	            left = 2 * i + 1;
	            right = 2 * i + 2;
	        }
	    }

	    private static <T extends Comparable<T>> void heapifyLinkedList(LinkedList<T> list, int n, int i) {
	        ListIterator<T> iterator = list.listIterator(i);
	        T rootValue = iterator.next(); // Cache the root value to be sifted down
	        int largest = i;
	        int left = 2 * i + 1;
	        int right = 2 * i + 2;

	        while (left < n) {
	            T largestValue = rootValue;
	            T leftValue = getValueAt(list, left);

	            if (leftValue != null && leftValue.compareTo(largestValue) > 0) {
	                largest = left;
	                largestValue = leftValue;
	            }

	            if (right < n) {
	                T rightValue = getValueAt(list, right);
	                if (rightValue != null && rightValue.compareTo(largestValue) > 0) {
	                    largest = right;
	                    largestValue = rightValue;
	                }
	            }

	            if (largest == i) {
	                break;
	            }

	            setValueAt(list, i, largestValue);

	            i = largest;
	            left = 2 * i + 1;
	            right = 2 * i + 2;

	            // Reposition the iterator
	            iterator = list.listIterator(i);
	            rootValue = iterator.next();
	        }

	        // Place the original root value in its correct position
	        setValueAt(list, i, rootValue);
	    }

	    private static <T extends Comparable<T>> void setValueAt(LinkedList<T> list, int index, T value) {
	        ListIterator<T> iterator = list.listIterator(index);
	        iterator.next(); // Move to the element at the specified index
	        iterator.set(value);
	    }

	    private static <T extends Comparable<T>> T getValueAt(LinkedList<T> list, int index) {
	        if (index >= list.size()) {
	            return null;
	        }

	        ListIterator<T> iterator = list.listIterator(index);
	        return iterator.next(); // Move to the element at the specified index
	    }

	  
}
	
	