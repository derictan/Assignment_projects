package Assignment;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

public class TimSort {

    public static void main(String[] args) {
        int[] sizes = {100000,200000,300000,400000,500000,600000,700000,800000,900000,1000000};  // Modify sizes as needed
        int index = 0;  // Initialize index for while loop
        
        while (index < sizes.length) {
            int size = sizes[index];
            String fileName = "numbers_"+ size + "_nonDuplicated.txt";
            System.out.println("Sorting file: " + fileName);

            // Read numbers from the file into ArrayList
            ArrayList<Integer> arrayList = readNumbersFromFile(fileName);
            
            // Clone ArrayList for worst-case scenario
            ArrayList<Integer> worstCaseArrayList = new ArrayList<>(arrayList);
            Collections.reverse(worstCaseArrayList);

            // Measure time taken for ArrayList sorting
            long startTimeArrayList = System.currentTimeMillis();
            TimSortArrayList.timSort(arrayList);
            long endTimeArrayList = System.currentTimeMillis();
            long durationArrayList = endTimeArrayList - startTimeArrayList;

            // Measure time taken for worst-case ArrayList sorting
            long startTimeWorstArrayList = System.currentTimeMillis();
            TimSortArrayList.timSort(worstCaseArrayList);
            long endTimeWorstArrayList = System.currentTimeMillis();
            long durationWorstArrayList = endTimeWorstArrayList - startTimeWorstArrayList;

            // Convert ArrayList to LinkedList
            LinkedList<Integer> linkedList = new LinkedList<>(arrayList);
            LinkedList<Integer> worstCaseLinkedList = new LinkedList<>(linkedList);
            Collections.reverse(worstCaseLinkedList);

            // Measure time taken for LinkedList sorting
            long startTimeLinkedList = System.currentTimeMillis();
            TimSortLinkedList.timSort(linkedList);
            long endTimeLinkedList = System.currentTimeMillis();
            long durationLinkedList = endTimeLinkedList - startTimeLinkedList;

            // Measure time taken for worst-case LinkedList sorting
            long startTimeWorstLinkedList = System.currentTimeMillis();
            TimSortLinkedList.timSort(worstCaseLinkedList);
            long endTimeWorstLinkedList = System.currentTimeMillis();
            long durationWorstLinkedList = endTimeWorstLinkedList - startTimeWorstLinkedList;

            // Print time taken for each
            System.out.println("Time taken for ArrayList (average case) with " + fileName + " 	: " + durationArrayList + " ms");
            System.out.println("Time taken for ArrayList (worst case) with " + fileName + "	: " + durationWorstArrayList + " ms");

            System.out.println("Time taken for LinkedList (average case) with " + fileName + " 	: " + durationLinkedList + " ms");
            System.out.println("Time taken for LinkedList (worst case) with " + fileName + "	: " + durationWorstLinkedList + " ms");
            System.out.println();

            index++;  // Increment index for the next iteration
        }
    }

    private static ArrayList<Integer> readNumbersFromFile(String filename) {
        ArrayList<Integer> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Assuming numbers are space-separated
                String[] numbers = line.split("\\s+");
                for (String number : numbers) {
                    list.add(Integer.parseInt(number));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }
}
