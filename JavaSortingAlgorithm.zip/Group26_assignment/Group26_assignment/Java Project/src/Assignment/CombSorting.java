package Assignment;
import java.util.*;
public class CombSorting<T extends List<E>, E extends Comparable<E>> {
	

	    private T list;
	    private double shrinkFactor;

	    // Constructor for both ArrayList and LinkedList
	    public CombSorting(T list, double shrinkFactor) {
	        this.list = list;
	        this.shrinkFactor = shrinkFactor;
	    }

	    // To find gap between elements
	    private int getNextGap(int gap) {
	        // Shrink gap by shrink factor
	        gap = (int) (gap / shrinkFactor);
	        if (gap < 1) {
	            return 1;
	        }
	        return gap;
	    }

	    // Function to sort the list using Comb Sort
	    public void sort() {
	        int n = list.size();
	        int gap = n;
	        boolean swapped = true;

	        while (gap != 1 || swapped) {
	            gap = getNextGap(gap);
	            swapped = false;

	            // For ArrayList
	            if (list instanceof ArrayList) {
	                ArrayList<E> arrayList = (ArrayList<E>) list;
	                for (int i = 0; i < n - gap; i++) {
	                    if (arrayList.get(i).compareTo(arrayList.get(i + gap)) > 0) {
	                        // Swap arrayList[i] and arrayList[i + gap]
	                        E temp = arrayList.get(i);
	                        arrayList.set(i, arrayList.get(i + gap));
	                        arrayList.set(i + gap, temp);
	                        swapped = true;
	                    }
	                }
	            } 
	            // For LinkedList
	            else if (list instanceof LinkedList) {
	                LinkedList<E> linkedList = (LinkedList<E>) list;
	                ListIterator<E> iter1 = linkedList.listIterator();
	                ListIterator<E> iter2 = linkedList.listIterator();

	                // Move iter2 forward by "gap" positions
	                int count = 0;
	                while (count < gap && iter2.hasNext()) {
	                    iter2.next();
	                    count++;
	                }

	                // Iterate through the list with both iterators in sync
	                while (iter2.hasNext()) {
	                    E value1 = iter1.next();
	                    E value2 = iter2.next();

	                    // If the first value is greater than the second, swap them
	                    if (value1.compareTo(value2) > 0) {
	                        iter1.set(value2);
	                        iter2.set(value1);
	                        swapped = true;
	                    }
	                }
	            }
	        }
	    }

	
	/*
	    private T list;  // This will accept both ArrayList and LinkedList

	    // Constructor for both ArrayList and LinkedList
	    public CombSorting(T list) {
	        this.list = list;  // Pass the list to be sorted when the thread is created
	    }

//To find gap between elements
int getNextGap(int gap)
{
    // Shrink gap by Shrink factor
    gap = (gap*10)/13;
    if (gap < 1)
        return 1;
    return gap;
}

// Function to sort arr[] using Comb Sort
public void sort()
{
    int n = list.size();

    // initialize gap
    int gap = n;

    // Initialize swapped as true to make sure that
    // loop runs
    boolean swapped = true;

    // Keep running while gap is more than 1 and last
    // iteration caused a swap
    while (gap != 1 || swapped == true)
    {
        // Find next gap
        gap = getNextGap(gap);

        // Initialize swapped as false so that we can
        // check if swap happened or not
        swapped = false;

        // Compare all elements with current gap
        for (int i = 0; i < n - gap; i++) {
            if (list.get(i) > list.get(i + gap)) {
                // Swap list[i] and list[i + gap]
                int temp = list.get(i);
                list.set(i, list.get(i + gap));
                list.set(i + gap, temp);

                // Set swapped
                swapped = true;
            }
        }
    }
}*/
		

	

}


