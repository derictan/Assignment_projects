package Assignment;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class SmallDataSorter {

    private static final RadixSorter radixSorter = new RadixSorter();

    // Sort small data numbers using ArrayList
    public void sortSmallDataNumbers(List<Integer> numbers) {
        System.out.println("Original numbers: \n" + numbers);

        // Sort using ArrayList
        List<Integer> arrayListNumbers = new ArrayList<>(numbers);
        long arrayListTime = radixSorter.sortNumbers(arrayListNumbers);
        System.out.println("Sorted numbers (ArrayList):\n " + arrayListNumbers);
        System.out.println("Time taken (ArrayList):\n " + arrayListTime + " ms.");

        // Sort using LinkedList
        List<Integer> linkedListNumbers = new LinkedList<>(numbers);
        long linkedListTime = radixSorter.sortNumbers(linkedListNumbers);
        System.out.println("Sorted numbers (LinkedList):\n " + linkedListNumbers);
        System.out.println("Time taken (LinkedList):\n " + linkedListTime + " ms.");
    }

    // Sort small data words
    public void sortSmallDataWords(List<String> words) {
        System.out.println("Original words:\n " + words);

        // Sort words using RadixSorter
        long wordsTime = radixSorter.sortWords(words);
        System.out.println("Sorted words:\n " + words);
        System.out.println("Time taken: " + wordsTime + " ms.");
    }
}
