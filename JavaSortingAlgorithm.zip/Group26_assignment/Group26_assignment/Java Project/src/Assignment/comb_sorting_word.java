package Assignment;
import java.util.*;
import java.io.*;
public class comb_sorting_word {
	public static void main(String[] args) {
        
        //File file = new File("C:/word/wordsData.txt");
		/*String[] fileSizes = {"100k_wordsData.txt", 
				  "100k_wordsNonDuplicateData.txt", 
				  "200k_wordsData.txt"};*/
		
		//Import the words_data into OS(C)
		String directoryPath = "C:/words_1M";

            // Create ArrayLists and LinkedLists for testing
            ArrayList<String> wordsListAverageArray = new ArrayList<>();
            ArrayList<String> wordsListWorstArray = new ArrayList<>();
            LinkedList<String> wordsListAverageLinked = new LinkedList<>();
            LinkedList<String> wordsListWorstLinked = new LinkedList<>();
           
            //Run all files in words_1M
            File directory = new File(directoryPath);
	        File[] files=directory.listFiles();
        
        /*for (String fileName : fileSizes) {
        File file = new File(directoryPath + fileName);*/

    		if (files != null) {
	            for (File file : files) {
	                if (file.isFile()) {
	                    // Clear lists before processing new file
	                    wordsListAverageArray.clear();
	                    wordsListWorstArray.clear();
	                    wordsListAverageLinked.clear();
	                    wordsListWorstLinked.clear();
        try {
            Scanner scanner = new Scanner(file);

            while (scanner.hasNext()) {
                String word = scanner.next();
                wordsListAverageArray.add(word);  // For ArrayList
                wordsListAverageLinked.add(word);  // For LinkedList
            }
            scanner.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }

        // Clone the list for worst case (ArrayList and LinkedList)
        wordsListWorstArray.addAll(wordsListAverageArray);
        Collections.sort(wordsListWorstArray, Collections.reverseOrder()); // Reverse sort for worst case (ArrayList)

        wordsListWorstLinked.addAll(wordsListAverageLinked);
        Collections.sort(wordsListWorstLinked, Collections.reverseOrder()); // Reverse sort for worst case (LinkedList)

        // Create instances of CombSorting for both ArrayList and LinkedList
        CombSorting<ArrayList<String>,String> combSortAverageArray = new CombSorting<>(wordsListAverageArray,1.3);
        CombSorting<ArrayList<String>,String> combSortWorstArray = new CombSorting<>(wordsListWorstArray,1.3);
        CombSorting<LinkedList<String>,String> combSortAverageLinked = new CombSorting<>(wordsListAverageLinked,1.3);
        CombSorting<LinkedList<String>,String> combSortWorstLinked = new CombSorting<>(wordsListWorstLinked,1.3);

        // Sorting and timing for ArrayList Average Case
        long startAverageArray = System.currentTimeMillis();
        combSortAverageArray.sort();  // Sort the Average Case ArrayList
        long endAverageArray = System.currentTimeMillis();
        System.out.println("Time used to sort the Average Case (ArrayList)for file "+file.getName()+": " + (endAverageArray - startAverageArray) + " ms");

        // Sorting and timing for ArrayList Worst Case
        /*combSortWorstArray = new CombSorting<>(wordsListWorstArray); */ //Reinitialize with worst case list
        long startWorstArray = System.currentTimeMillis();
        combSortWorstArray.sort();  // Sort the Worst Case ArrayList
        long endWorstArray = System.currentTimeMillis();
        System.out.println("Time used to sort the Worst Case (ArrayList)for file "+file.getName()+": " + (endWorstArray - startWorstArray) + " ms");

        // Sorting and timing for LinkedList Average Case
        long startAverageLinked = System.currentTimeMillis();
        combSortAverageLinked.sort();  // Sort the Average Case LinkedList
        long endAverageLinked = System.currentTimeMillis();
        System.out.println("Time used to sort the Average Case (LinkedList)for file "+file.getName()+": " + (endAverageLinked - startAverageLinked) + " ms");

        // Sorting and timing for LinkedList Worst Case
        //combSortLinked = new CombSorting<>(wordsListWorstLinked);  // Reinitialize with worst case list
        long startWorstLinked = System.currentTimeMillis();
        combSortWorstLinked.sort();  // Sort the Worst Case LinkedList
        long endWorstLinked = System.currentTimeMillis();
        System.out.println("Time used to sort the Worst Case (LinkedList)for file "+file.getName()+": " +(endWorstLinked - startWorstLinked) + " ms");
        System.out.println();

        }
}
}else {
    System.out.println("Directory does not exist or is not a directory.");

}
	}
	
	}
