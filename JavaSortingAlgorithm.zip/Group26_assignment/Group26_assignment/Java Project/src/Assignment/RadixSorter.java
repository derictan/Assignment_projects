package Assignment;

import java.util.*;

public class RadixSorter {

    // Radix sort for numbers (average-case)
    public static long sortNumbers(List<Integer> numbers) {
        int max = Collections.max(numbers);
        long startTime = System.currentTimeMillis();
        lsdRadixSort(numbers, max);
        return System.currentTimeMillis() - startTime;
    }

    // Radix sort for numbers (worst-case)
    public static long sortWorstCaseNumbers(List<Integer> numbers) {
        Collections.sort(numbers, Collections.reverseOrder()); // Create worst-case
        int max = Collections.max(numbers);
        long startTime = System.currentTimeMillis();
        lsdRadixSort(numbers, max);
        return System.currentTimeMillis() - startTime;
    }

    private static void lsdRadixSort(List<Integer> numbers, int max) {
        int maxAbs = Math.max(max, -Collections.min(numbers)); // Handling negative numbers
        int numBuckets = 10;
        int[] bucketCounts = new int[numBuckets];
        int[] bucketIndices = new int[numBuckets];
        int[] tempArray = new int[numbers.size()];

        for (int exp = 1; maxAbs / exp > 0; exp *= 10) {
            Arrays.fill(bucketCounts, 0);

            // Count occurrences in each bucket
            for (int number : numbers) {
                int bucketIndex = ((number / exp) % 10 + 10) % 10;
                bucketCounts[bucketIndex]++;
            }

            // Compute bucket start indices
            bucketIndices[0] = 0;
            for (int i = 1; i < numBuckets; i++) {
                bucketIndices[i] = bucketIndices[i - 1] + bucketCounts[i - 1];
            }

            // Distribute numbers to buckets
            for (int number : numbers) {
                int bucketIndex = ((number / exp) % 10 + 10) % 10;
                tempArray[bucketIndices[bucketIndex]++] = number;
            }

            // Copy sorted numbers back to original list
            for (int i = 0; i < numbers.size(); i++) {
                numbers.set(i, tempArray[i]);
            }
        }
    }

    // Radix sort for words (average-case)
    public static long sortWords(List<String> words) {
        int maxLength = findMaxLength(words);
        long startTime = System.currentTimeMillis();
        lsdRadixSortWords(words, maxLength);
        return System.currentTimeMillis() - startTime;
    }

    // Radix sort for words (worst-case)
    public static long sortWorstCaseWords(List<String> words) {
        Collections.sort(words, Collections.reverseOrder()); // Create worst-case
        int maxLength = findMaxLength(words);
        long startTime = System.currentTimeMillis();
        lsdRadixSortWords(words, maxLength);
        return System.currentTimeMillis() - startTime;
    }

    // Find maximum length of strings in the list
    private static int findMaxLength(List<String> words) {
        return words.stream().mapToInt(String::length).max().orElse(0);
    }

    // LSD radix sort for words using arrays
    private static void lsdRadixSortWords(List<String> words, int maxLength) {
        final int ASCII_SIZE = 256; // ASCII character set size
        List<String>[] buckets = new ArrayList[ASCII_SIZE];
        for (int i = 0; i < ASCII_SIZE; i++) {
            buckets[i] = new ArrayList<>();
        }

        List<String> tempList = new ArrayList<>(words.size());

        // Sort by each character position from right (least significant) to left (most significant)
        for (int pos = maxLength - 1; pos >= 0; pos--) {
            // Clear buckets
            for (int i = 0; i < ASCII_SIZE; i++) {
                buckets[i].clear();
            }

            // Place each word into the appropriate bucket based on the current character
            for (String word : words) {
                char currentChar = pos < word.length() ? word.charAt(pos) : 0; // Use ASCII value 0 for padding
                buckets[currentChar].add(word);
            }

            // Collect words back from buckets into the temporary list
            tempList.clear();
            for (List<String> bucket : buckets) {
                tempList.addAll(bucket);
            }

            // Transfer sorted words back to the original list
            for (int i = 0; i < words.size(); i++) {
                words.set(i, tempList.get(i));
            }
        }
    }
}
