package Assignment;

import java.util.Arrays;
import java.util.List;

public class SmallDataSorterTest {

    public static void main(String[] args) {
        SmallDataSorter sorter = new SmallDataSorter();

        // Test data
        List<Integer> numbers = Arrays.asList(4, 10, 3, 5, 1, 6, 7, 8, 9, 2, 15, 12, 14, 11, 13, 20, 18, 16, 19, 17);
        List<String> words = Arrays.asList("vllqy", "xeuds", "etzc", "hkrulbtcl", "mtyxtf", "nsvnflmtfy",
                "gajpwjr", "bptplhk", "kixocfpr", "dmhajpqb", "cwayo", "awehbguoif", "vhbvoxbq",
                "zpwoxmdy", "hoqkeel", "ubuiq", "bxyvglgos", "qnyhzpxleo", "ogktrb", "pyb");

        // Perform sorting
        System.out.println("Sorting small data...\n");
        sorter.sortSmallDataNumbers(numbers);
        System.out.println("\n");
        sorter.sortSmallDataWords(words);
    }
}
