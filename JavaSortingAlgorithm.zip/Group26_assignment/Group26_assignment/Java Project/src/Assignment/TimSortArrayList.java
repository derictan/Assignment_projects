package Assignment;

import java.util.ArrayList;

public class TimSortArrayList {

    // Minimum size of a run
    private static final int RUN = 64;

    // Function to sort the given ArrayList using TimSort
    public static void timSort(ArrayList<Integer> arr) {
        int n = arr.size();
        int i = 0;

        // Sort individual subarrays of size RUN
        while (i < n) {
            insertionSort(arr, i, Math.min((i + RUN - 1), (n - 1)));
            i += RUN;
        }

        // Merge the sorted runs
        int size = RUN;
        while (size < n) {
            int left = 0;
            while (left < n) {

                // Find the middle and right for the current subarray
                int mid = left + size - 1;
                int right = Math.min((left + 2 * size - 1), (n - 1));

                // Merge the sorted subarrays
                if (mid < right) {
                    merge(arr, left, mid, right);
                }
                left += 2 * size;
            }
            size = 2 * size;
        }
    }

    // Function to perform insertion sort on a subarray
    private static void insertionSort(ArrayList<Integer> arr, int left, int right) {
        int i = left + 1;
        while (i <= right) {
            Integer temp = arr.get(i);
            int j = i - 1;

            // Shift elements of arr[left...i-1], that are greater than temp, to one position ahead
            while (j >= left && arr.get(j).compareTo(temp) > 0) {
                arr.set(j + 1, arr.get(j)); // Move element one position ahead
                j--;
            }

            // Insert temp in its correct position
            arr.set(j + 1, temp);
            i++;
        }
    }

    // Function to merge two sorted subarrays arr[left...mid] and arr[mid+1...right]
    private static void merge(ArrayList<Integer> arr, int left, int mid, int right) {
        int len1 = mid - left + 1;
        int len2 = right - mid;

        // Primitive arrays for better performance
        int[] leftArr = new int[len1];
        int[] rightArr = new int[len2];

        // Copy data to temporary arrays
        for (int i = 0; i < len1; i++) {
            leftArr[i] = arr.get(left + i);
        }

        for (int j = 0; j < len2; j++) {
            rightArr[j] = arr.get(mid + 1 + j);
        }

        // Merge the temporary arrays back into arr[left...right]
        int i = 0, j = 0, k = left;

        while (i < len1 && j < len2) {
            if (leftArr[i] <= rightArr[j]) {
                arr.set(k++, leftArr[i++]);
            } else {
                arr.set(k++, rightArr[j++]);
            }
        }

        // Copy the remaining elements of leftArr[], if any
        while (i < len1) {
            arr.set(k++, leftArr[i++]);
        }

        // Copy the remaining elements of rightArr[], if any
        while (j < len2) {
            arr.set(k++, rightArr[j++]);
        }
    }
}
