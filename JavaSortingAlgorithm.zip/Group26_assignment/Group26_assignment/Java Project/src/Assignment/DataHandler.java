package Assignment;

import java.io.*;
import java.util.*;

public class DataHandler {
    private String numberFilePath;
    private String wordFilePath;

    public DataHandler(String numberFilePath, String wordFilePath) {
        this.numberFilePath = numberFilePath;
        this.wordFilePath = wordFilePath;
    }

    // Load numbers from file into ArrayList
    public List<Integer> loadNumbersToArrayList() throws IOException {
        List<Integer> numbers = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(numberFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                numbers.add(Integer.parseInt(line.trim()));
            }
        }
        return numbers;
    }

    // Load numbers from file into LinkedList
    public List<Integer> loadNumbersToLinkedList() throws IOException {
        List<Integer> numbers = new LinkedList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(numberFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                numbers.add(Integer.parseInt(line.trim()));
            }
        }
        return numbers;
    }

    // Load words from the file into ArrayList
    public List<String> loadWords() throws IOException {
        List<String> words = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(wordFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                words.add(line.trim());
            }
        }
        return words;
    }
}
