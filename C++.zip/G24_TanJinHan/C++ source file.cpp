/*
Programming and Problem Solving Assignment

Group Leader		: Tan Jin Han, 2106059, AM
Group member 1		: Khor Boon Qian, 2207611, AM
Group member 2		: Tai Jia Xin, 2103404, AM
Group member 3		: Ryan Lee Yung Hong, 2102195, AM
Group member 4		: Lee Yong Quan, 2207456, AM
Faculty				: LKC FES
Course code			: UECS1004
Course Description	: Programming and Problem Solving
Group number		: G24
*/

//This program will allow users to check their category based on the Covid-19 test.
//This program also reminds users to follow the SOP at all times

//Preprocessing directives used in this program
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <cctype>
#include <cstring>
#include <fstream>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sstream>


using namespace std;

typedef struct
{
	char Q1;
	char Q2;
	char Q3;
	char Q4;
	char Q5;
} QUESTION;

//Function prototypes
void login_ch(int *progress);
void login_system(int *user, int *progress);
void main_menu(int *progress);
void profile_info(int *user, int *progress);
void delete_line(int user);
void new_user(int *progress);
void refresh();
void find_user(int *user);
void display_categories_of_covid19();
void SOP();
void home();
void time();
QUESTION answer_script(int *progress);

int main(void)
{
	int progress = 0;
	int n;
	int user;
	while (true)
	
	if (progress == -1)
		return 0;
		
	else if (progress == 0)
	{
		login_ch(&progress);
	}
	
	else if (progress == 1)
	{
		login_system(&user, &progress);
	}
	
	else if (progress == 2)
	{
		main_menu(&progress);
	}
	
	else if (progress == 3)
	{
		profile_info(&user, &progress);
		refresh();//refresh the screen
	}
	
	else if (progress == 4)
	{
		display_categories_of_covid19();
		refresh();//refresh the screen
		progress = 2;
	}
	
	else if (progress == 5)
	{
		answer_script(&progress);
		refresh();//refresh the screen
		progress = 2;
	}
	
	else if (progress == 6)
	{
		HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
		new_user(&progress);
		SetConsoleTextAttribute(h,2);
		cout << "Congratulations! You have successfully edited" << endl;
		SetConsoleTextAttribute(h,7);
		refresh(); //refresh the screen
		delete_line(user);
		find_user(&user);
		progress = 3;
	}
	
	else if (progress == 7)
	{
		new_user(&progress);
		HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleTextAttribute(h,2);
		cout << "Congratulation! You have registered your own account" << endl;
		SetConsoleTextAttribute(h,7);
		refresh(); //refresh the screen
		progress = 0;
	}
	
	return 0;
}

void login_ch(int *progress)
{
	cout << "***************************************************************************************************" << endl;
	cout << "Welcome to Covid-19 Management System                                      ";
	time();
	cout << "***************************************************************************************************" << endl;
	
	string ch;
	
	//User can only choose 3 options, Login, Register and Exit the program.
	cout << "<1> Login to Covid-19 Management System" << endl;
	cout << "<2> Register new account" << endl;
	cout << "<3> Exit" << endl;
	
	//Remind users to follow SOPs during the COVID-19 pandemic.
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(h,9);
	cout << "\nFOLLOW SOP :";
	SOP();
	SetConsoleTextAttribute(h,7);
	
	cout << "Enter your option : ";
	cin >> ch; //read the options
	
	//If the user chooses to log in, the program becomes the login system.
	if (ch == "1")
	{
		system("cls"); //refresh the screen
		*progress = 1;
	}
	
	//If the user chooses to sign up for a new account, the program becomes the signup part.
	else if (ch == "2")
	{
		refresh();//refresh the screen
		cout << "***************************************************************************************************" << endl;
		cout << "Welcome to Covid-19 Management System                                      ";
		time();
		cout << "***************************************************************************************************" << endl;
		cout << "Registration Part\n" << endl;
		*progress = 7;
	}
	
	//If the user chooses to exit the program, the loop will stop.
	else if (ch == "3")
	{
		*progress = -1;
	}
	
	//If it is not in the options, the program will display an error.
	else
	{
		HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleTextAttribute(h,4);
		cout << "Invalid, Please try again" << endl;
		SetConsoleTextAttribute(h,7);
		refresh(); //refresh the screen
		*progress = 0;
	}
}

//The login system allows users to enter their IC number and phone number as a password to log in to the application.
void login_system(int *user, int *progress)
{
	cout << "***************************************************************************************************" << endl;
	cout << "Welcome to Covid-19 Management System                                      ";
	time();
	cout << "***************************************************************************************************" << endl;
	
	//Remind users to follow SOPs during the COVID-19 pandemic.
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(h,9);
	cout << "FOLLOW SOP :";
	SOP();
	SetConsoleTextAttribute(h,7);
	
	char username[50], phone_num[50];
	string username_file, phone_file,users;
	char ch; 
	*user = -1;
		
	cout << "\nusername\t\t:";
	cin.ignore();
	cin.get(username, 50);//read the username as user ID
	cout << "Password (Phone number)\t:";
	cin.ignore();
	cin.get(phone_num,50); //read the phone number as password
	
	ifstream in_file("users.txt");
	while (getline(in_file, users)) //read the line from the "users" text file
    {
        *user += 1; //used to read the specific line
        //parse the line and extract the values separated by semicolons
        stringstream ss(users); 
        getline(ss, username_file, ';');
        getline(ss, phone_file, ';');
        
        //After successful registration, the user can log in
        if (username_file == username && phone_file == phone_num)
        {
        	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
			cout << "\n";
			SetConsoleTextAttribute(h,2);
			cout << "Congrats!Login successfully!" << endl;
			SetConsoleTextAttribute(h,7);
			refresh(); //refresh the screen
			*progress = 2;
			break; //Stop the loop and continue to the next function
        }		
	}
	in_file.close();

	//Login will fail if the user is not registered
	//IC number or phone number is different from text file
	if (username_file != username || phone_file != phone_num)
	{
		HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
		cout << "\n"<< endl;
		SetConsoleTextAttribute(h,4);
		cout << "Sorry, your username and password is incorrect, please try again" << endl;
		SetConsoleTextAttribute(h,15);
		cout << "Don't have an account? Please register in main page" << endl;
		SetConsoleTextAttribute(h,7);
		refresh(); //refresh the screen
		*progress = 0;
	}
}

//Main menu display the functions of the application
void main_menu(int *progress)
{
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	
	cout << "***************************************************************************************************" << endl;
	cout << "Welcome to Covid-19 Management System                                      ";
	time();
	cout << "***************************************************************************************************" << endl;
	
	string ch;
	
	cout << "<1> Profile" << endl; //The user can check and edit the infomation
	cout << "<2> Check Categories of Covid-19" << endl; //Used to check the details of catogory of COVID-19
	cout << "<3> Questionnaire (compulsory)" << endl; //User needs to answer the question to know the status
	SetConsoleTextAttribute(h,12);
	cout << "**Please do the questionnaire at least every 3 days" << endl;
	SetConsoleTextAttribute(h,7);
	cout << "<4> Logout" << endl; //Exit the program.
	
	//Remind users to follow SOPs during the COVID-19 pandemic.
	SetConsoleTextAttribute(h,9);
	cout << "\nFOLLOW SOP :";
	SetConsoleTextAttribute(h,7);
	
	cout << "Enter your option : " ;
	cin >> ch; //read the option
	
	if (ch == "1")
	{
		refresh(); //refresh the screen
		*progress = 3;
	}
	
	else if (ch == "2")
	{
		refresh();//refresh the screen
		*progress = 4;
	}
		
	else if (ch == "3")
	{
		refresh();//refresh the screen
		*progress = 5;
	}

	else if (ch == "4")
	{

		SetConsoleTextAttribute(h,2);
		cout << "Thank you for using our app, see you next time" << endl;
		SetConsoleTextAttribute(h,7);
		
		home(); //display a home with slogan "STAY AT HOME"
		refresh();//refresh the screen
		*progress = 0;
	}
		
	else
	{
		//If it is not in the options, the program will display an error.
		SetConsoleTextAttribute(h,4);
		cout << "Invalid, Please try again" << endl;
		SetConsoleTextAttribute(h,7);
		
		*progress = 2;
		refresh(); //refresh the screen
	}
}

//The user can check and edit the infomation
void profile_info(int *user, int *progress)
{
    char ch;
    int n = *user; //get the specific line
    
    ifstream in_file("user_info.txt");
    string line;
    for (int i = 0; i <= n; i++)
    {
        getline(in_file, line); // read the specific line from the file
    }
    in_file.close();
    
    // Now, parse the line and extract the values separated by semicolons
    stringstream ss(line);
    string x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
    getline(ss, x1, ';');
    getline(ss, x2, ';');
    getline(ss, x3, ';');
    getline(ss, x4, ';');
    getline(ss, x5, ';');
    getline(ss, x6, ';');
    getline(ss, x7, ';');
    getline(ss, x8, ';');
    getline(ss, x9, ';');
    getline(ss, x10, ';');
    getline(ss, x11, ';');
    
	//display the user's information
	cout << "***************************************************************************************************" << endl;
	cout << "Welcome to Covid-19 Management System                                      ";
	time();
	cout << "***************************************************************************************************" << endl;
	cout << "Username\t:" << x1 << endl;
	cout << "Age\t\t:" << x2 << endl;
	cout << "Gender\t\t:" << x3 << endl;
	cout << "IC\t\t:" << x4 << endl;
	cout << "Contact Number\t:" << x5 << endl;
	cout << "Address1\t:" << x6 << endl;
	cout << "Address2\t:" << x7 << endl;
	cout << "Address3\t:" << x8 << endl;
	cout << "Postcode\t:" << x9 << endl;
	cout << "State\t\t:" << x10 << endl;
	cout << "Email\t\t:" << x11 << endl;
	
	cout << "<E>dit / <B>ack to menu" << endl; //User can choose either edit the information or back to main menu
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(h,2);
	cout << "If you wish to change your password, kindly access to <1>Profile for edit";
	SetConsoleTextAttribute(h,7);
	cin >> ch; //read the options
	ch = toupper(ch); 
	
	if (ch == 'E')
	{
		*progress = 6;
	}
	
	else if (ch == 'B')
		*progress = 2;
		
	else
	{
		//If it is not in the options, the program will display an error.
		HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleTextAttribute(h,4);
		cout << "Invalid, Please try again" << endl;
		SetConsoleTextAttribute(h,7);

		*progress = 3;
	}
}

QUESTION answer_script(int *progress) //Users should answer the question to know their status
{
	cout << "***************************************************************************************************" << endl;
	cout << "Welcome to Covid-19 Management System                                      ";
	time();
	cout << "***************************************************************************************************" << endl;
	QUESTION Q;
	int  q= 1, ans = 0, result = 0;
	
	while (true)
	
	if (q == 1)
	{
		cout << "Have you had a fever in the last 14 days? (<Y>es/<N>o): ";
		cin >> Q.Q1; //read the answer for question 1
		Q.Q1 = toupper(Q.Q1);
		if (Q.Q1 == 'Y')
		{
			ans += 1;
			q += 1;
		}
			
		else if (Q.Q1 == 'N')
			q += 1;
			
		else
		{
			//If it is not in the options, the program will display an error.
			HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
			SetConsoleTextAttribute(h,4);
			cout << "Invalid, Please try again" << endl;
			SetConsoleTextAttribute(h,7);

			q = 1;
		}	
	}
	
	else if (q == 2)
	{
		cout << "Have you had a cough in the last 14 days? (<Y>es/<N>o):";
		cin >> Q.Q2; //read the answer for question 2
		Q.Q2 = toupper(Q.Q2);
		if (Q.Q2 == 'Y')
		{
			ans += 1;
			q += 1;
		}
			
		else if (Q.Q2 == 'N')
			q += 1;
			
		else
		{
			//If it is not in the options, the program will display an error.
			HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
			SetConsoleTextAttribute(h,4);
			cout << "Invalid, Please try again" << endl;
			SetConsoleTextAttribute(h,7);
			
			q = 2;
		}
	}
	else if (q == 3)
	{
		cout << "Have you had shortness of breath in the last 14 days? (<Y>es/<N>o): ";
		cin >> Q.Q3; //read the answer for question 3
		Q.Q3 = toupper(Q.Q3);
		if (Q.Q3 == 'Y')
		{
			ans += 1;
			q += 1;
		}
			
		else if (Q.Q3 == 'N')
			q += 1;
			
		else
		{
			//If it is not in the options, the program will display an error.
			HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
			SetConsoleTextAttribute(h,4);
			cout << "Invalid, Please try again" << endl;
			SetConsoleTextAttribute(h,7);
			
			q = 3;
		}
	}
	else if (q == 4)
	{
		cout << "Have you had close contact with a confirmed or suspected COVID-19 case in the last 14 days? (<Y>es/<N>o): ";
		cin >> Q.Q4; //read the answer for question 4
		Q.Q4 = toupper(Q.Q4);
		if (Q.Q4 == 'Y')
		{
			ans += 1;
			q += 1;
		}
			
		else if (Q.Q4 == 'N')
			q += 1;
			
		else
		{
			//If it is not in the options, the program will display an error.
			HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
			SetConsoleTextAttribute(h,4);
			cout << "Invalid, Please try again" << endl;
			SetConsoleTextAttribute(h,7);
			
			q = 4;
		}
	}
	
	else if (q == 5)
	{
		cout << "Covid-19 Self-test Result (<P>ositive / <N>egative)";
		cin >> Q.Q5; //read the answer for question 5;
		Q.Q5 = toupper(Q.Q5);
		if (Q.Q5 == 'P')
		{
			result += 1;
			q += 1;
		}
			
		else if (Q.Q5 == 'N')
			q += 1;
			
		else
		{
			//If it is not in the options, the program will display an error.
			HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
			SetConsoleTextAttribute(h,4);
			cout << "Invalid, Please try again" << endl;
			SetConsoleTextAttribute(h,7);
			
			q = 5;
		}
	}
	
	//If a user is tested positive, they are classified as Category A.
	//If the user is tested negative and has at least 2 symptoms, they are classified as category B.
	//If a user tests negative and has no symptoms, they are classified as normal.
	else if (q == 6)
	{
		string status;
    	if (result == 1) 
		{
			HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
			cout << "Your COVID-19 status has been updated to ";
			SetConsoleTextAttribute(h,12);
			cout << "Category A" << endl;
			cout << "You are confirmed case\n" << endl;
			SetConsoleTextAttribute(h,7);
			
			SetConsoleTextAttribute(h,13);
			cout << "To check more details, please refer to 'Categories of COVID-19' in menu" << endl;
			SetConsoleTextAttribute(h,7);
    	} 
		else if (ans >= 2)
		{
        	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
			cout << "Your COVID-19 status has been updated to ";
			SetConsoleTextAttribute(h,6);
			cout << "Category B" << endl;
			cout << "You are close contact\n" << endl;
			SetConsoleTextAttribute(h,7);
			
			SetConsoleTextAttribute(h,13);
			cout << "To check more details, please refer to 'Categories of COVID-19' in menu" << endl;
			SetConsoleTextAttribute(h,7);
    	}
    	else
    	{
    		HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
			cout << "Your COVID-19 status has been updated to ";
			SetConsoleTextAttribute(h,2);
			cout << "Normal" << endl;
			SetConsoleTextAttribute(h,7);
			
			SetConsoleTextAttribute(h,13);
			cout << "To check more details, please refer to 'Categories of COVID-19' in menu" << endl;
			SetConsoleTextAttribute(h,7);
		}
    	break;
    	*progress = 2;
	}
}

void delete_line(int user) //delete the specific line from text file
{
	ifstream in_file("user_info.txt"); //read the "user_info" file
	ofstream out_file("temp.txt", ios::out);
	
	ifstream in_file2("users.txt");  //read the "users" file
	ofstream out_file2("temp2.txt", ios::out);
	
	string line, line2;
	int n_users = 0;
	int n_user_info = 0;
	
	while (getline(in_file, line)) 
	{
		//delete the specific line from "user_info" text file
		if (n_users != user) 
		{
			out_file << line << endl; 
		}
		n_users++;
	}
	
	while (getline(in_file2, line2))
	{
		//delete the specific line from "users" text file
		if (n_user_info != user)
		{
			out_file2 << line2 << endl;
		}
		n_user_info++;
	}
	
	in_file.close();
	in_file2.close();
	out_file.close();
	out_file2.close();
	
	remove("user_info.txt"); //Remove the old file
	rename("temp.txt", "user_info.txt"); //Rename the new file to be the same as the old file
	
	remove("users.txt"); //Remove the old file
	rename("temp2.txt", "users.txt"); //Rename the new file to be the same as the old file
	
}

void new_user(int *progress) //Add new line information as account
{
	ofstream out_file("users.txt", ios::app);
	ofstream out_file2("user_info.txt", ios::app);
	
	char x1[50], x2[10], x4[20], x5[20], x6[60], x7[60], x8[60], x9[20], x10[20], x11[30];
	string x3;
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	
	int step = 1;
	while (true)
	{
		if (step == 1)
		{
			cout << "Username\t\t\t:";
			cin.get(x1,50); //read the username
			
			step = 2;
			
		}
		else if (step == 2)
		{
			int len, loop = 0;
			
			cout << "Age\t\t\t\t:";
			cin >> x2; //read the age
			
			len = strlen(x2);
			
			for (int i = 0; i < len ; i++)
			{
				if (!isdigit(x2[i]))
					loop ++;
			}
			
			if (loop > 0)
			{
				//Age must be integer
				SetConsoleTextAttribute(h,4);
				cout << "Invalid, please try again" << endl;
				SetConsoleTextAttribute(h,7);
				step = 2;
			}
			else
			{
				step = 3;
			}
		}
		
		else if (step == 3)
		{
    		while (true) 
			{
		        cout << "Gender (male or female)\t\t:";
		        cin >> x3; //read gender
		        if (x3 == "male" || x3 == "female") 
				{
		            break; // Exit the loop if the input is valid
		        }
		        
		        //gender must be male or female
		        SetConsoleTextAttribute(h,4);
				cout << "Invalid input. Please enter either male or female in small letters." << endl;
				SetConsoleTextAttribute(h,7);
		    }
			
			step = 4;
			
		}
		
		else if (step == 4)
		{
			int len, loop = 0;
			
			cout << "IC (without dash '-')\t\t:";
			cin >> x4; //read IC number
			
			len = strlen(x4);
			
			for (int i = 0; i < len ; i++)
			{
				//IC number must be integer
				if (!isdigit(x4[i]))
					loop ++;
			}
			
			//IC number must be 12 digits
			if (len != 12)
				loop ++;
			
			if (loop > 0)
			{
				SetConsoleTextAttribute(h,4);
				cout << "Invalid, please try again" << endl;
				SetConsoleTextAttribute(h,7);
				step = 4;
			}
			else
			{
				step = 5;
			}
		}
		
		else if (step == 5)
		{
			int len, loop = 0;
			
			cout << "Contact Number(without space)\t:";
			cin >> x5; //read contact number
			
			len = strlen(x5);
			
			for (int i = 0; i < len ; i++)
			{
				//contact number must be integer
				if (!isdigit(x5[i]))
					loop ++;
			}
			
			//contact number should be more than 9 digits
			if (len < 10)
				loop ++;
				
			if (loop > 0)
			{
				SetConsoleTextAttribute(h,4);
				cout << "Invalid, please try again" << endl;
				SetConsoleTextAttribute(h,7);
				step = 5;
			}
			else
			{
				step = 6;
			}
		}
		
		else if (step == 6)
		{
			cin.ignore(); // Ignore the newline character left in the input stream by getline()
			cout << "Address 1\t\t\t:"; 
			cin.get(x6,60); //read Address 1
			
			step = 7;
		}
		
		else if (step == 7)
		{
			cin.ignore(); // Ignore the newline character left in the input stream by getline()
			cout << "Address 2\t\t\t:";
			cin.get(x7,60); //read Address 2
			
			step = 8;
		}
		
		else if (step == 8)
		{
			cin.ignore(); // Ignore the newline character left in the input stream by getline()
			cout << "Address 3\t\t\t:";
			cin.get(x8,60); //read Address 3
			
			step = 9;
		}
		
		else if (step == 9)
		{
			int len, loop = 0;
			
			cout << "Postcode\t\t\t:";
			cin >> x9; //read postcode
			
			len = strlen(x9);
			
			for (int i = 0; i < len ; i++)
			{
				//postcode must be integer
				if (!isdigit(x9[i]))
					loop ++;
			}
			
			if (len < 5)
			{
				//postcode should be 5 digits
				loop ++;
			}
			
			if (loop > 0)
			{
				SetConsoleTextAttribute(h,4);
				cout << "Invalid, please try again" << endl;
				SetConsoleTextAttribute(h,7);
				step = 9;
			}
			else
			{
				step = 10;
			}
		}
		
		else if (step == 10)
		{
			int len, loop = 0;
			
			cout << "State\t\t\t\t:";
			cin >> x10; //read state
			
			step = 11;
		}
		
		else if (step == 11)
		{
			int len, loop = 0;
			
			cout << "Email\t\t\t\t:";
			cin >> x11; //read email
			
			step = 12;
		}
		
		else
		{
			//Save the information in the "users" and "user_info" text files, separated by semicolons
			out_file << x1 << ";" << x5 << endl;
			out_file2 << x1 << ";" << x2 << ";" << x3 << ";" << x4 << ";" << x5 << ";" << x6 << ";" << x7 << ";" << x8 << ";" << x9 << ";" << x10 << ";" << x11 << endl;
			out_file.close();
			out_file2.close();
			
			break;
		}
	}
	
}

void refresh() // refresh the screen
{
	cout << "Press ENTER to continue";
	cin.get();
	cin.get();
	system("cls");
}

void find_user(int *user) //Find a specific line for a user in a file
{
    string users, username_file, phone_file, username, phone_num;
    *user = -1;
    
    ifstream in_file("users.txt");
    while (getline(in_file, users)) 
    {
        *user += 1;
        stringstream ss(users);
        getline(ss, username_file, ';');
        getline(ss, phone_file, ';');
        if (username_file == username && phone_file == phone_num)
        {
            break;
        }
    }
    	in_file.close();
}

void display_categories_of_covid19() //display the details of categories of covid_19
{
	cout << "=======================================================================================================================================\n"
		 "Categories of	COVID-19\n"
		"=======================================================================================================================================\n"
		"Category A - confirmed case\n"
		"Quarantine for 7 days and can be released within the 7 days once tested negative.\n"
		"---------------------------------------------------------------------------------------------------------------------------------------\n"
		"Category B - close contact\n"
		"1) Asymptomatic:\n"
		"   If staying with positve patient, 3 days of quaratine is required and need to do self-test everyday throughout the quarantine period.\n"
		"   If not staying with positve patient, no quarantine is needed.\n\n"
		"2) Symptomatic:\n"
		"   3 days of quaratine is required and need to do self-test everyday throughout the quarantine period.\n"
		"   Released from quarantine on day 3 if tested negative and show no symptoms.\n\n"
		"---------------------------------------------------------------------------------------------------------------------------------------\n"
		"Casual contact - likely exposded to COVID-19 patient \n"
		"   No need to quarantine if asymptomatic.\n"
		"   Symptomatic but allowed to work as usual if tested negative.\n"
		"---------------------------------------------------------------------------------------------------------------------------------------\n"
		"*You will be categorized as category A once tested positive.\n"
		"---------------------------------------------------------------------------------------------------------------------------------------\n";
}

void SOP() //display the SOP for user to follow
{
	int n;
	srand(time(NULL)); 
	n = rand()%4+1; //read the random number from 1-4
	
	if (n == 1)
	{
		cout << "Avoid large social gatherings" << endl;
		cout << "(Current public health orders restrict indoors gatherings to no more than 10 people)" << endl;
	}
	else if (n == 2)
	{
		cout << "Wear a mask on campus and when around anyone outside your immediate household" << endl;
	}
	else if (n == 3)
	{
		cout << "Get tested for COVID-19 regularly" << endl;
	}
	else 
	{
		cout << "Watch for systems, and isolate and seek medical care immediately if sysmtems develop" << endl;
	}
}

void home() //display a home with slogan "STAY AT HOME"
{
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(h,15);	
	cout << "                *           " << endl;
	cout << "            ***   ***       " << endl;
	cout << "         ***         ***    " << endl;
	cout << "      ********************* " << endl;
	cout << "      *                   * " << endl;
	cout << "      *    STAY AT HOME   * " << endl;
	cout << "      *                   * " << endl;
	cout << "      ********************* " << endl;
	SetConsoleTextAttribute(h,7);
}

void time()
{
	// declaring argument of time()
    time_t my_time = time(NULL);
  
    // ctime() used to give the present time
    printf("%s", ctime(&my_time));
}

