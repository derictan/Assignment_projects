<?php
// Check if the user is logged in
$isLoggedIn = isset($_SESSION['id']);

echo $isLoggedIn;
// Initialize the user ID variable
$userId = null;

// Get the logged-in user's ID if available
if ($isLoggedIn) {
    $userId = $_SESSION['id'];
}

?>

<?php
// Use the appropriate header template based on login status
if ($isLoggedIn) {
    // User is logged in, use template_header2
	include ('login/function.php');
    echo template_header2('Home');
} else {
    // User is not logged in, use default template_header
    echo template_header('Home');
}
?>
<?php
// Check to make sure the id parameter is specified in the URL
if (isset($_GET['id'])) {
    // Prepare statement and execute, prevents SQL injection
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
    $stmt->execute([$_GET['id']]);
    // Fetch the product from the database and return the result as an Array
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    // Check if the product exists (array is not empty)
    if (!$product) {
        // Simple error to display if the id for the product doesn't exists (array is empty)
        exit('Product does not exist!');
    }
} else {
    // Simple error to display if the id wasn't specified
    exit('Product does not exist!');
}
?>

<div class="product content-wrapper">
    <img src="imgs/<?=$product['img']?>" width="500" height="500" alt="<?=$product['name']?>">
    <div>
		<?php
			if ($product['name'] == 'Samsung 98 inch Q80CA QLED 4K TV') {
				echo '<h1 class="name"><a href="Product1.php">' . $product['name'] . '</a></h1>';
			} elseif($product['name'] == 'LG 77 inch OLED evo G3 Gallery Edition 4K UHD Smart TV (2023)'){
				echo '<h1 class="name"><a href="Product2.php">' . $product['name'] . '</a></h1>';
			}elseif($product['name'] == 'Haier 75 Inch HQ LED Google TV - H75P750UX'){
				echo '<h1 class="name"><a href="Product3.php">' . $product['name'] . '</a></h1>';
			}elseif($product['name'] == 'Samsung 65 Inch QLED 4K TV Q70CA'){
				echo '<h1 class="name"><a href="Product4.php">' . $product['name'] . '</a></h1>';
			}elseif($product['name'] == 'Sony 7.1.2ch Dolby Atmos®/ DTS:X® Soundbar SNY-HTA7000'){
				echo '<h1 class="name"><a href="Product5.php">' . $product['name'] . '</a></h1>';
			}elseif($product['name'] == 'Sony HT-S2000 3.1ch Dolby Atmos Soundbar - HTS2000'){
				echo '<h1 class="name"><a href="Product6.php">' . $product['name'] . '</a></h1>';
			}else {
				echo '<h1 class="name">' . $product['name'] . '</h1>';
			}
		?>

        <span class="price">
            &dollar;<?=$product['price']?>
            <?php if ($product['rrp'] > 0): ?>
            <span class="rrp">&dollar;<?=$product['rrp']?></span>
            <?php endif; ?>
        </span>
        <form action="index.php?page=cart" method="post">
            <input type="number" name="quantity" value="1" min="1" max="<?=$product['quantity']?>" placeholder="Quantity" required>
            <input type="hidden" name="product_id" value="<?=$product['id']?>">
            <input type="submit" value="Add To Cart">
        </form>
        <div class="description">
            <?=$product['description']?>
        </div>
    </div>
</div>

<?=template_footer()?>