<!DOCTYPE html>
<html lang = "en">
<head>
	<meta charset = "UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="styles2.css">
	<link rel="stylesheet" href="styles1.css">
	<title>Shuan Q</title>
	
</head>
<body>
<?php include('function.php');?>
<?php template_header('Account');?>

<br>
<br>
<div>
<?php include('login/login.php');?></div>



</body>
<?php template_footer();?>
</html>
