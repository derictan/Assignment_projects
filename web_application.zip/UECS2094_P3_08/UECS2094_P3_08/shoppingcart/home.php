<?php
session_destroy();
session_start();
// Check if the user is logged in
$isLoggedIn = isset($_SESSION['id']) && !empty($_SESSION['id']);

echo $isLoggedIn;
// Initialize the user ID variable
$userId = null;

// Get the logged-in user's ID if available
if ($isLoggedIn) {
    $userId = $_SESSION['id'];
	include 'function.php';
	include 'login/function.php';
    // User is logged in, use template_header2
    echo template_header2('Home');
	
}else {
    // User is not logged in, use default template_header
    echo template_header('Home');
}
$pdo = pdo_connect_mysql();
$stmt = $pdo->prepare('SELECT * FROM products ORDER BY date_added DESC LIMIT 4');
$stmt->execute();
$recently_added_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?php include('slider.php')?>
<div class="recentlyadded content-wrapper">
    
    <div class="products">
        <?php foreach ($recently_added_products as $product): ?>
        <a href="index.php?page=product&id=<?=$product['id']?>" class="product">
            <img src="imgs/<?=$product['img']?>" width="200" height="200" alt="<?=$product['name']?>">
            <span class="name"><?=$product['name']?></span>
            <span class="price">
                &dollar;<?=$product['price']?>
                <?php if ($product['rrp'] > 0): ?>
                <span class="rrp">&dollar;<?=$product['rrp']?></span>
                <?php endif; ?>
            </span>
        </a>
        <?php endforeach; ?>
    </div>
</div>


<?=template_footer()?>
