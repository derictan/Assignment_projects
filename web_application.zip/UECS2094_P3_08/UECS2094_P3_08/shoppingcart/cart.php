<?php
// Check if the user is logged in
$isLoggedIn = isset($_SESSION['id']);

// Initialize the user ID variable
$userId = $isLoggedIn ? $_SESSION['id'] : null;

// Include appropriate header template based on login status
if ($isLoggedIn) {
    include 'login/function.php';
    echo template_header2('Cart');
} else {
    echo template_header('Cart');
}

// Retrieve the logged-in user's ID (if logged in)
$user_id = $userId;

// Initialize products and subtotal variables
$products = [];
$subtotal = 0.00;

// Fetch products added by the user from the usercart table
if ($user_id) {
    $stmt = $pdo->prepare('SELECT products.*, usercart.quantity AS cart_quantity FROM usercart INNER JOIN products ON usercart.product_id = products.id WHERE usercart.user_id = ?');
    $stmt->execute([$user_id]);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate subtotal of the cart
    foreach ($products as $product) {
        $subtotal += $product['price'] * $product['cart_quantity'];
    }
}

// Process add to cart functionality
if (isset($_POST['product_id'], $_POST['quantity']) && is_numeric($_POST['product_id']) && is_numeric($_POST['quantity'])) {
    $product_id = (int)$_POST['product_id'];
    $quantity = (int)$_POST['quantity'];

    // Fetch product details from the database
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if the product exists and quantity is valid
    if ($product && $quantity > 0) {
        // Add or update the product in the cart session
        if (isset($_SESSION['products'][$product_id])) {
            $_SESSION['products'][$product_id]['quantity'] += $quantity;
        } else {
            $_SESSION['products'][$product_id] = [
                'id' => $product['id'],
                'name' => $product['name'],
                'price' => $product['price'],
                'quantity' => $quantity
            ];
        }

        // Update or insert the cart item into the usercart table (if user is logged in)
        if ($user_id) {
            try {
                $stmt = $pdo->prepare('INSERT INTO usercart (user_id, product_id, quantity) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)');
                $stmt->execute([$user_id, $product_id, $quantity]);
            } catch (PDOException $e) {
                echo "Database error: " . $e->getMessage();
            }
        }

        // Redirect to the cart page to prevent form resubmission
        header('Location: index.php?page=cart');
        exit;
    }
}

// Process update cart functionality
if (isset($_POST['update'])) {
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'quantity-') === 0 && is_numeric($value)) {
            $product_id = (int)substr($key, strlen('quantity-'));
            $new_quantity = (int)$value;

            if ($new_quantity > 0) {
                $_SESSION['products'][$product_id]['quantity'] = $new_quantity;

                // Update the usercart table (if user is logged in)
                if ($user_id) {
                    try {
                        $stmt = $pdo->prepare('UPDATE usercart SET quantity = ? WHERE user_id = ? AND product_id = ?');
                        $stmt->execute([$new_quantity, $user_id, $product_id]);
                    } catch (PDOException $e) {
                        echo "Database error: " . $e->getMessage();
                    }
                }
            }
        }
    }

    // Redirect to cart page after updating quantities
    header('Location: index.php?page=cart');
    exit;
}

// Process remove item from cart functionality
if (isset($_GET['remove']) && is_numeric($_GET['remove'])) {
    $product_id_to_remove = (int)$_GET['remove'];
	$stmt = $pdo->prepare('DELETE FROM usercart WHERE user_id = ? AND product_id = ?');
    $stmt->execute([$user_id, $product_id_to_remove]);
    
    header('Location: index.php?page=cart');
    exit;
}


if (isset($_POST['placeorder'])) {
    
    // Clear the cart after placing the order
    unset($_SESSION['cart']);

    // Redirect the user to the place order page
    header('Location: index.php?page=payment');
    exit;
}
?>

<div class="cart content-wrapper">
    <h1>Shopping Cart</h1>
    <?php if ($user_id): ?>
        <form action="index.php?page=cart" method="post">
            <table>
                <thead>
                    <tr>
                        <td colspan="2">Product</td>
                        <td>Price</td>
                        <td>Quantity</td>
                        <td>Total</td>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($products)): ?>
                        <tr>
                            <td colspan="5" style="text-align:center;">You have no products added in your Shopping Cart</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($products as $product): ?>
                            <tr>
                                <td class="img">
                                    <a href="index.php?page=product&id=<?= $product['id'] ?>">
                                        <img src="imgs/<?= $product['img'] ?>" width="50" height="50" alt="<?= $product['name'] ?>">
                                    </a>
                                </td>
                                <td>
                                    <a href="index.php?page=product&id=<?= $product['id'] ?>"><?= $product['name'] ?></a>
                                    <br>
                                    <a href="index.php?page=cart&remove=<?= $product['id'] ?>" class="remove">Remove</a>
                                </td>
                                <td class="price">&dollar;<?= $product['price'] ?></td>
                                <td class="quantity">
                                    <input type="number" name="quantity-<?= $product['id'] ?>" value="<?= $product['cart_quantity'] ?>" min="1" max="<?= $product['quantity'] ?>" placeholder="Quantity" required>
                                </td>
                                <td class="price">&dollar;<?= $product['price'] * $product['cart_quantity'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <div class="subtotal">
                <span class="text">Subtotal</span>
                <span class="price">&dollar;<?= $subtotal ?></span>
            </div>
            <div class="buttons">
                <input type="submit" value="Update" name="update">
                <input type="submit" value="Place Order" name="placeorder">
            </div>
        </form>
    <?php else: ?>
        <p>Please log in to view your shopping cart.</p>
		<a href="account.php">Login Here</a>
    <?php endif; ?>
</div>

<?php template_footer(); ?>
