<?php
session_start();
// Check if the user is logged in
$isLoggedIn = isset($_SESSION['id']);

include 'function.php';
// Initialize the user ID variable
$userId = null;

// Get the logged-in user's ID if available
if ($isLoggedIn) {
    $userId = $_SESSION['id'];
}

// Use the appropriate header template based on login status
if ($isLoggedIn) {
    include 'login/function.php';
    // User is logged in, use template_header2
    echo template_header2('Place Order');
} else {
    // User is not logged in, use default template_header
    echo template_header('Place Order');
}

?>
<div class="placeorder">
    <h1>Your Order Has Been Placed</h1>
    <p>Thank you for ordering with us! We'll contact you by email with your order details.</p>
</div>

<?=template_footer()?>
