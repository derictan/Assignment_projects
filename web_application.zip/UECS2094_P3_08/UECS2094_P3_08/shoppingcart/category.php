<?php
// Fetch distinct categories
$stmt = $pdo->query('SELECT DISTINCT category FROM products');
$categories = $stmt->fetchAll(PDO::FETCH_COLUMN);

?>

<?php

// Check if the user is logged in
$isLoggedIn = isset($_SESSION['id']);

echo $isLoggedIn;
// Initialize the user ID variable
$userId = null;

// Get the logged-in user's ID if available
if ($isLoggedIn) {
    $userId = $_SESSION['id'];
}
?>

<?php
// Use the appropriate header template based on login status
if ($isLoggedIn) {
	include 'login/function.php';
    // User is logged in, use template_header2
    echo template_header2('Home');
} else {
    // User is not logged in, use default template_header
    echo template_header('Home');
}
?>

<div class="recentlyadded content-wrapper">
    <?php foreach ($categories as $category): ?>
        <div class="category">
            <h3><?= $category ?></h3>
            <div class="products">
                <?php
                // Fetch products for the current category
                $stmt = $pdo->prepare('SELECT * FROM products WHERE category = ?');
                $stmt->execute([$category]);
                $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
                ?>
                <?php foreach ($products as $product): ?>
                    <a href="index.php?page=product&id=<?= $product['id'] ?>" class="product">
                        <img src="imgs/<?=$product['img']?>" width="200" height="200" alt="<?=$product['name']?>">
						<?= $product['name'] ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?= template_footer() ?>
