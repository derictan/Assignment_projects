<!DOCTYPE html>
<html>
<head>
	<title>SuanQ_AboutUs</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scala=1.0">
	<link rel = "stylesheet" href="style/myStyle03.css">
</head>
<body>
<?php

// Check if the user is logged in
$isLoggedIn = isset($_SESSION['id']);

echo $isLoggedIn;
// Initialize the user ID variable
$userId = null;

// Get the logged-in user's ID if available
if ($isLoggedIn) {
    $userId = $_SESSION['id'];
}
?>

<?php
// Use the appropriate header template based on login status
if ($isLoggedIn) {
	include 'login/function.php';
    // User is logged in, use template_header2
    echo template_header2('Home');
} else {
    // User is not logged in, use default template_header
    echo template_header('Home');
}
?>
	<br>
      <div class = "contact-bg">
        <h2>ABOUT US</h2>
      </div>
	<div class="wrapper">
		<div class ="aboutUs">
			<article>
				<div class="content">
					<div class="card">
						<img src = "picture/nickson.jpg">
						<h4>Nickson, CEO</h4>
					</div>
					<div class="card">
						<img src = "picture/YQ.jpg">
						<h4>Yong Quan, IT Manager</h4>
					</div>
					<div class="card">
						<img src = "picture/teddy.jpg">
						<h4>Teddy, Marketing Manager</h4>
					</div>
					<div class="card">
						<img src = "picture/JH.jpg">
						<h4>Deric, Vice President</h4>
					</div>
				</div>
				
				
				<blockquote>
					"SuanQ was founded in 2003 by Nickson, a tech enthusiast 
					with a vision to create a premier destination for digital 
					gadget enthusiasts. With a small team and a big dream, 
					SuanQ launched its online platform, offering a curated 
					selection of the latest digital gadgets and accessories. 
					From smartphones and tablets to wearable tech and drones, 
					SuanQ quickly gained traction among tech-savvy consumers, 
					establishing a reputation for quality products and 
					exceptional customer service.
				</blockquote>
		</div>
	</div>

</body>
<?php template_footer();?>
</html>