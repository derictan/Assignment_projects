<!DOCTYPE html>
<html lang = "en">
<head>
<meta charset = "UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="styles1.css">
	<title>Image Slider</title>
</head>

<body>

<div class ="container">
	<div class = "slider">
		<div class = "slides">
			
			<input type = "radio" name="radio-btn" id ="radio1"width="500" height="250">
			<input type = "radio" name="radio-btn" id ="radio2"width="500" height="250">
			
			
			<div class = "slide first">
				<img src ="samsungtv2.png" alt="pic1" >
			</div>
			<div class = "slide">
				<img src ="slidepic2.png" alt="pic2" >
			</div>
			
			<div class = "navigation-auto">
				<div class ="auto-btn1"></div>
				<div class ="auto-btn2"></div>
			</div>
			
			
		</div>
		
		<div class="navigation-manual">
			<label for="radio1" class="manual-btn"></label>
			<label for="radio2" class="manual-btn"></label>
		</div>
		
	</div>
</div>	
	<script type ="text/javascript">
	var counter = 1;
	setInterval(function(){
		document.getElementById('radio' + counter).checked=true;
		counter ++;
		if(counter>2){
			counter =1;
		}
	},5000);
	</script>

</body>
</html>