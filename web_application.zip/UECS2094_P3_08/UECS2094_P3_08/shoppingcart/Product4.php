<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Samsung 65 Inch QLED 4K TV Q70CA</title>
    <style>
        /* Basic styling for demonstration purposes */
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .product-img {
            max-width: 100%;
            height: auto;
        }
        .product-details {
            margin-top: 20px;
        }
		.slideshow-container {
			max-width: 1000px;
			position: relative;
			margin: auto;
		}
		.mySlides{
			display: none;
		}
		.prev, .next {
			cursor: pointer;
			position: absolute;
			top: 50%;
			width: auto;
			margin-top: -22px;
			padding: 16px;
			color: white;
			font-weight: bold;
			font-size: 18px;
			transition: 0.6s ease;
			border-radius: 0 3px 3px 0;
			user-select: none;
			}
        .next {
			right: 400px;
			border-radius: 3px 0 0 3px;
			left: auto;
			}
		.prev {
            left: 5px;
            border-radius: 0 3px 3px 0;
            right: auto;
        }	
		.prev:hover, .next:hover {
			background-color: rgba(0,0,0,0.8);
			}
			.fade {
			animation-name: fade;
			animation-duration: 1.5s;
			}
		@keyframes fade {
			from {opacity: .4}
			to {opacity: 1}
				}
		.description {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 5px;
            margin-top: 20px;
        }
        .features {
            background-color: #f3f3f3;
            padding: 20px;
            border-radius: 5px;
            margin-top: 20px;
        }
        
		table{
			border-collapse: collapse;
			width: 100%;
			background-color: black;
			margin-top: 20px;
		}
		td{
			border:0;
			padding:8px;
			text-align: center;
		}
		.table-img{
			max-width:200px;
			height: auto;
			border-radius: 5px;
			transition: transform 0.3s ease;
		}
		img:hover{
			transform: scale(1.1);
		}
		.header-row {
            background-color: #333;
            color: white;
        }
        .header-row td {
            padding: 20px;
            font-weight: bold;
        }
		.header-row:hover {
            background-color: #555;
			transform: scale(1.1);
        }
		.container{
		position: relative;
		text-align: center;
		color: black;
		}
		.top-left {
		position: absolute;
		top: 30px;
		left: 40px;
		font-size:20px;
		font-weight:bold;
		}
		.quantum{
		background-color: black;
		color:white;
		}
		
    </style>
</head>
<body>
<?php
session_start();
// Check if the user is logged in
$isLoggedIn = isset($_SESSION['id']);

echo $isLoggedIn;
// Initialize the user ID variable
$userId = null;

// Get the logged-in user's ID if available
if ($isLoggedIn) {
    $userId = $_SESSION['id'];
}

?>

<?php
// Use the appropriate header template based on login status
if ($isLoggedIn) {
    // User is logged in, use template_header2
	include ('login/function.php');
	include ('function.php');
    echo template_header2('Home');
} else {
    // User is not logged in, use default template_header
	include ('function.php');
    echo template_header('Home');
}
?>
	<section>
    <div class="product-details">
	<br><br><br><br><br><br><br>
        <h1>Samsung 65 Inch QLED 4K TV Q70CA</h1>
        <div><?php include('slider/slider4.php');?></div>
		
	<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
	<a class="next" onclick="plusSlides(1)">&#10095;</a>
	
	</div>
        <h2>Price: RM 4999.00</h2>
        <div class="description">
		<h2>Description</h2> 
		<p>Enjoy stunning visuals and smart features with the Samsung 65 Inch QLED 4K TV Q70CA. Its QLED technology delivers rich, vibrant colors and deep blacks for an immersive viewing experience. With 4K resolution and Quantum HDR, every scene comes to life with incredible detail.</p>
        </div>
		<table >
		<tr>
		<tr class="header-row">
                <td colspan="4">Top 4 Features</td>
		</tr>
		<tr>
			<td><img src="image/image5.png" alt="1" class ="table-img"></td>
			<td><img src="image/image6.png" alt="2" class ="table-img"></td>
			<td><img src="image/image7.png" alt="3" class ="table-img"></td>
			<td><img src="image/image8.png" alt="4" class ="table-img"></td>
		</tr>
		</table>
		<div class="features">
		<h2>Features</h2>
            <ul>
                <li>65-inch QLED display</li>
                <li>4K UHD resolution</li>
                <li>Quantum HDR for enhanced contrast</li>
                <li>Smart TV with Tizen OS</li>
                <li>Built-in voice assistant and One Remote Control</li>
            </ul>
        </div>
		<br>
		<center>
			<div class="container">
			<img src="image/samsung654.WEBP" style="width:100%;">
			<div class="top-left">Experience intelligence and realism in 4K</div>
			</div>
			<div class="quantum">
			<p style ="font-size:5vw">Quantum Processor 4K</p>
			<p style ="font-size:2vw">INTELLIGENCE BEHIND THE GLORIOUS PICTURE AND SOUND</p>
			<p>Quantum Processor 4K intelligently optimizes picture, sound and more to give you a truly breathtaking experience.</p>
			<img src="image/samsung655.WEBP" style="width:100%;">
			<p style ="font-size:5vw">Motion Xcelerator Turbo+</p>
			<p style ="font-size:2vw">EXCEPTIONAL MOTION ENHANCEMENTS IN 4K 120HZ</p>
			<p>Conquer every enemy at soaring speeds. With motion enhancements up to 4K 120Hz, you can enjoy ultra-smooth gameplay without lag and motion blur.</p>
			<img src="image/samsung656.WEBP" style="width:100%;">
			<p style ="font-size:5vw">Quantum HDR</p>
			<p style ="font-size:2vw">WIDER RANGE OF CONTRAST IN CINEMATIC SCALE</p>
			<p>Fully enjoy every image with details that pop. Dynamic tone mapping of HDR10+ creates deeper blacks and vibrant imagery that always shines through.</p>
			<img src="image/samsung657.WEBP" style="width:100%;">
			<p style ="font-size:5vw">Smart Hub</p>
			<p style ="font-size:2vw">DISCOVER YOUR FAVORITE CONTENT IN ONE PLACE</p>
			<p>Optimize content curation and discovery, so you spend less time searching and more time streaming movies, games and shows you love.</p>
			<img src="image/samsung658.WEBP" style="width:100%;">
			</div>
			
		</center>
		<script>
		let slideIndex = 1;
		showSlides(slideIndex);

// Next/previous controls
		function plusSlides(n) {
			showSlides(slideIndex += n);
		}

// Thumbnail image controls
		function currentSlide(n) {
			showSlides(slideIndex = n);
		}

		function showSlides(n) {
		let i;
		let slides = document.getElementsByClassName("mySlides");

		if (n > slides.length) {slideIndex = 1}
		if (n < 1) {slideIndex = slides.length}
		for (i = 0; i < slides.length; i++) {
			slides[i].style.display = "none";
		}
 
		slides[slideIndex-1].style.display = "block";
		}
		</script>
		</section>
        <<p><a href="index.php?page=product&id=4">Back to Product Listing</a></p>
    </div>
</body>
<?php template_footer();?>
</html>
