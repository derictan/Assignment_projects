<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>LG 77 inch OLED evo G3 Gallery Edition 4K UHD Smart TV (2023)</title>
    <style>
body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .product-img {
            width: 1000px;
            height: 600px;
            margin-right: 20px;
        }
        .product-details {
           
       margin-top: 20px;
        }
        .p2 {
            width: 100%; /* Take full width */
            display: flex;
            align-items: flex-start;
            margin-top: 20px;
        }
        .p2 img.secondary-img {
            max-width: 400px; /* Adjust the size of the secondary image */
            margin-right: 20px; /* Add spacing between the images and text */
        }
        .p2-details {
            flex: 1;
            width: 100%; /* Take full width */
        }
        .p2-details ul {
            list-style-type: none;
            padding: 0;
        }
        .p2-details li {
            margin-bottom: 10px;
            padding-left: 25px; /* Adjust spacing between bullet points and text */
            position: relative;
        }
        .p2-details li::before {
            content: "\2022";  /* Bullet point character */
            position: absolute;
            left: 0;
            color: #007bff; /* Adjust color as needed */
        }
        .p2-details p {
            margin-bottom: 10px;
        }
		l.swiper-container {
            width: 100%;
            height: 100%;
        }
        .swiper-slide img {
            width: 400px;
            height: auto;
        }
		div.scroll-container {
		background-color: #333;
		overflow: auto;
		white-space: nowrap;
		padding: 10px;
		}

		div.scroll-container img {
		padding: 10px;
		}
		img:hover{
			transform: scale(1.1);
		}
    </style>
   
</head>
<body>
<?php
session_start();
// Check if the user is logged in
$isLoggedIn = isset($_SESSION['id']);

echo $isLoggedIn;
// Initialize the user ID variable
$userId = null;

// Get the logged-in user's ID if available
if ($isLoggedIn) {
    $userId = $_SESSION['id'];
}

?>

<?php
// Use the appropriate header template based on login status
if ($isLoggedIn) {
    // User is logged in, use template_header2
	include ('login/function.php');
	include ('function.php');
    echo template_header2('Home');
} else {
    // User is not logged in, use default template_header
	include ('function.php');
    echo template_header('Home');
}
?>
	<section style="padding : 1% 1% 1% 1%;">
	
    <div class="product-details">
	<br><br><br><br><br><br><br>
        <h1>LG 77 inch OLED evo G3 Gallery Edition 4K UHD Smart TV (2023)</h1>
		
		<div><?php include('slider/slider2.php');?></div>
		
     <div class="product-details">   
        <h2>Price: RM 25999.00</h2>
		
		<div class="p2">
		<img src="image/p2.WEBP" alt="Secondary Image" class="secondary-img">
			<div class="p2-details">
		<h2>
		<span class="title-left">LG 77 inch OLED evo G3 Gallery Edition</span>
                    <span class="title-right">4K UHD Smart TV (2023)</span>
                </h2>

                  <p>LG 77 inch OLED evo G3 Gallery Edition</p>
                    
        <p>LG OLED evo G3 Gallery Edition 77 inch 120Hz Dolby Vision & HDR10 4K UHD Smart TV (2023)</p>

            <ul>
                <li>Advanced picture and functionality with the α9 AI Processor 4K Gen6</li>
                <li>Bright, bold visuals of Brightness Booster Max</li>
                <li>Flush fit with One Wall Design's nearly zero gap wall mount *Stand sold separately</li>
                <li>Smart Functionality, including ThinQ AI, WebOS, and Hands-Free Voice Recognition</li>
                <li>Immersive entertainment with Dolby Atmos & Vision, VRR, G-sync, and Freesync</li>
            </ul>
       
			</div>
			
		</div>
		<br>
		<center>
			<p style ="font-size:2vw"> Vast Size Range</p>
			<p style="font-size:5vw"> Any Size You Like</p>
			<p style="font-size:1vw" >From the 55" for solo movie marathons to the crowd-pleasing 83" for the most exciting sporting showdowns, the vast LG OLED G3 size range features something for everyone.</p>
			
			<img src ="image/lg774.WEBP">
			
			<p style ="font-size:5vw">Spellbinding Cinema</p>
			<p style ="font-size:1vw">Scenes come to life with Dolby Vision's ultra-vivid picture and the immersive, spatial audio of Dolby Atmos.</p>
			<img src ="image/lg775.WEBP">
		</center>
	</div>
	</section>
	<p><a href="index.php?page=product&id=2">Back to Product Listing</a></p>
	
	

</body>
<?php template_footer();?>
</html>
