<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Frequently Asked Questions</title>
    <link rel="stylesheet" href="style/myStyle05.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
      integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
  </head>
  
  <body>
  
  <?php

// Check if the user is logged in
$isLoggedIn = isset($_SESSION['id']);

echo $isLoggedIn;
// Initialize the user ID variable
$userId = null;

// Get the logged-in user's ID if available
if ($isLoggedIn) {
    $userId = $_SESSION['id'];
}
?>

<?php
// Use the appropriate header template based on login status
if ($isLoggedIn) {
	include 'login/function.php';
    // User is logged in, use template_header2
    echo template_header2('Home');
} else {
    // User is not logged in, use default template_header
    echo template_header('Home');
}
?>
	<div class="wrapper">
      <h1>Frequently Asked Questions</h1>

      <div class="faq">
        <button class="accordion">
          How to register for a suanQ Account?
          <i class="fa-solid fa-chevron-down"></i>
        </button>
        <div class="pannel">
          <p>
            Simply look for the "LOG IN/Sign Up" button on your right corner, 
			click on it and it'll bring you to the Log in page, you should click 
			the "Signup" button to sign up your account.
          </p>
        </div>
      </div>
	  
	  
	  <div class="faq">
        <button class="accordion">
          How do I place an order?
          <i class="fa-solid fa-chevron-down"></i>
        </button>
        <div class="pannel">
          <p>
            To place an order, simply select the product(s) you'd like to purchase
			and add them to cart. Then fill in your Shipping Address, Phone number, 
			and choose the Payment Method. Then click the "Confirm Order" button to 
			place order.
          </p>
        </div>
      </div>
	  
	  <div class="faq">
        <button class="accordion">
          How can I cancel my order?
          <i class="fa-solid fa-chevron-down"></i>
        </button>
        <div class="pannel">
          <p>
            To cancel your order, you'll need to sign in and click into "CART", then 
			click the "Remove" on the following item.

          </p>
        </div>
      </div>
	  
	  <div class="faq">
        <button class="accordion">
          What are the payment method available?
          <i class="fa-solid fa-chevron-down"></i>
        </button>
        <div class="pannel">
          <p>
            The payment options available are by direct credit or debit card.
          </p>
        </div>
      </div>
	  
	  <div class="faq">
        <button class="accordion">
          Which credit cards are accepted for payment?
          <i class="fa-solid fa-chevron-down"></i>
        </button>
        <div class="pannel">
          <p>
            All credit cards issued from major banks in Malaysia are accepted.
          </p>
        </div>
      </div>
	  
	  <div class="faq">
        <button class="accordion">
          Do you keep my credit card details?
          <i class="fa-solid fa-chevron-down"></i>
        </button>
        <div class="pannel">
          <p>
            Any personal information you disclose to us is handled with the 
			strictest confidence.
          </p>
        </div>
      </div>
	  
	</div>
	
	
	<script>
      var acc = document.getElementsByClassName("accordion");
      var i;

      for (i = 0; i < acc.length; i++) {
        acc[i].addEventListener("click", function () {
          this.classList.toggle("active");
          this.parentElement.classList.toggle("active");

          var pannel = this.nextElementSibling;

          if (pannel.style.display === "block") {
            pannel.style.display = "none";
          } else {
            pannel.style.display = "block";
          }
        });
      }
    </script>
	
	</body>
	<?php template_footer();?>
</html>