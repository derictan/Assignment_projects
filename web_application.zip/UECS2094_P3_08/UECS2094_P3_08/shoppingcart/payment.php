<?php
// Check if the user is logged in
$isLoggedIn = isset($_SESSION['id']);

// Initialize the user ID variable
$userId = null;

// Get the logged-in user's ID if available
if ($isLoggedIn) {
    $userId = $_SESSION['id'];
}

// Use the appropriate header template based on login status
if ($isLoggedIn) {
    include 'login/function.php';
    // User is logged in, use template_header2
    echo template_header2('Payment');
} else {
    // User is not logged in, use default template_header
    echo template_header('Payment');
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['submit'])) {
        // Redirect to place order page
        header('Location: placeorder.php');
        exit;
    }
}
?>

<div class="ShippingDetails">
    <form action="index.php?page=payment" method="post" onsubmit="return validateForm()">
        <h2>Shipping Details</h2>
        <label for="ShippingAddress">Shipping Address</label><br>
        <textarea id="ShippingAddress" name="ShippingAddress" placeholder="Insert Address Here." rows="6" cols="30"></textarea><br><br>
        <label for="phoneNum">Phone Number</label><br>
        <input type="text" id="phoneNum" name="phoneNum"><br><br>
        <label for="payment">Payment Method</label><br>
        <select id="payment" name="payment">
            <option value="creditcard">Credit Card</option>
            <option value="debitcard">Debit Card</option>
        </select><br><br>

        <div id="paymentDetails" style="display: none;">
            <h2>Payment Details</h2>
            <label for="cardnum">Card Number:</label><br>
            <input type="text" id="cardnum" name="cardnum"><br><br>
            <label for="CVV">CVV:</label><br>
            <input type="text" id="CVV" name="CVV"><br><br>
            <label for="expdate">Expired Date:</label><br>
            <input type="text" id="expdate" name="expdate"><br><br>
        </div>

        <input type="submit" name="submit" value="Confirm Order">
    </form>
</div>

<script>
// Validate form function
function validateForm() {
    var paymentMethod = document.getElementById("payment").value;

    // Validate based on selected payment method
    if (paymentMethod === "creditcard" || paymentMethod === "debitcard") {
        var cardNumber = document.getElementById("cardnum").value;
        var cvv = document.getElementById("CVV").value;
        var expiryDate = document.getElementById("expdate").value;

        // Check if payment details are filled out
        if (cardNumber.trim() === '' || cvv.trim() === '' || expiryDate.trim() === '') {
            alert("Please fill out all payment details.");
            return false;
        }
		
		// Check if card number is numeric
        if (!isNumeric(cardNumber)) {
            alert("Card number must be numeric.");
            return false;
        }
		
        // Check if card number is maximum 16 numbers long
        if (cardNumber.trim().length > 16) {
            alert("Card number must be maximum 16 numbers long.");
            return false;
        }
    }

    // Additional validation for shipping details (e.g., phone number)
    var phoneNumber = document.getElementById("phoneNum").value;
    if (phoneNumber.trim() === '') {
        alert("Please provide a phone number.");
        return false;
    }

    // Form is valid, allow submission
    return true;
}

function isNumeric(value) {
    return /^\d+$/.test(value);
}

// Show/hide payment details based on selected payment method
document.getElementById("payment").addEventListener("change", function() {
    var paymentMethod = this.value;
    var paymentDetails = document.getElementById("paymentDetails");

    if (paymentMethod === "creditcard" || paymentMethod === "debitcard") {
        paymentDetails.style.display = "block";
    } else {
        paymentDetails.style.display = "none";
    }
});
</script>

<?=template_footer()?>
