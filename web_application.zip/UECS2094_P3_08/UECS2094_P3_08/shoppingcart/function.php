<?php
function pdo_connect_mysql() {
    // Update the details below with your MySQL details
    $DATABASE_HOST = 'localhost';
    $DATABASE_USER = 'root';
    $DATABASE_PASS = null;
    $DATABASE_NAME = 'cart';
    try {
        return new PDO('mysql:host=' . $DATABASE_HOST . ';dbname=' . $DATABASE_NAME . ';charset=utf8', $DATABASE_USER, $DATABASE_PASS);
    } catch (PDOException $exception) {
        // If there is an error with the connection, stop the script and display the error.
        exit('Failed to connect to database!');
    }
}


function template_header($title) {
    // Get the number of items in the shopping cart
    $num_items_in_cart = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;

    echo <<<EOT
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>$title</title>
    <link rel="stylesheet" href="styles2.css">
	<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
</head>
<body>
    <header>
        <div class="navbar">
            <a href="index.php">
                <img src="SUANQ.png" alt="Your Logo" class="logo" width="120" height="100">
            </a>
            <ul>
                <li><i class='bx bx-cart'></i><a href="index.php?page=cart">Cart</a></li>
                <li><i class='bx bx-user'></i><a href="account.php">Log In/Sign Up</a></li>
            </ul>
        </div>
        <div class="navbar">
            <div class="menu-bar">
                <ul>
                    <li><a href="index.php?page=products">Products</a></li>
                    <li><a href="index.php?page=category">Shop By Category</a></li>
                    <li><a href="index.php?page=aboutUs">About Us</a></li>
                    <li><a href="index.php?page=contactUs">Contact Us</a></li>
					<li><a href="index.php?page=FAQ">FAQ</a></li>
                </ul>
            </div>
        </div>
    </header>
    <main>
EOT;
}

// Template footer
function template_footer() {
    $year = date('Y'); // Get the current year
    
    // Output the footer section with dynamic content
    echo <<<EOT
        </main>
        <footer>
            <div class="footerwrapper">
                <div class="row">
                    <div class="col">
                        <img src="SUANQ.png" alt="Your Logo" class="logo" width="120" height="100">
                    </div>
                    <div class="col">
                        <h3>General Info</h3>
                        <p><a href="index.php?page=aboutUs">About Us</a></p>
                        <p><a href="index.php?page=contactUs">Contact Us</a></p>
                        <p><a href="index.php?page=contactUs#map">Locate Us</a></p>
                        <p><a href="index.php?page=FAQ">FAQ</a></p>
                    </div>
                    <div class="col">
                        <h3>We accept</h3>
                        <img src="pic1.png" alt="payment" class="logo" width="100" height="50">
                        <br>
                        <h3>Available Installment</h3>
                    </div>
                </div>
                <hr>
                <p>&copy; $year SUANQ ELECTRIC (UTAR) SDN. BHD. 505454554 (5487-X) ALL RIGHTS RESERVED</p>
            </div>
        </footer>
    </body>
</html>
EOT;
}

?>
