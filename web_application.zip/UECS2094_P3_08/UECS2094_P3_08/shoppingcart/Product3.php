<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Haier 75 Inch HQ LED Google TV - H75P750UX</title>
    <style>
        
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .product-img {
            max-width: 100%;
            height: auto;
        }
        .product-details {
            margin-top: 20px;
        }
		.slideshow-container {
			max-width: 1000px;
			position: relative;
			margin: auto;
		}
		.mySlides{
			display: none;
		}
		.prev, .next {
			cursor: pointer;
			position: absolute;
			top: 50%;
			width: auto;
			margin-top: -22px;
			padding: 16px;
			color: white;
			font-weight: bold;
			font-size: 18px;
			transition: 0.6s ease;
			border-radius: 0 3px 3px 0;
			user-select: none;
			
			}
        .next {
			right: 400px;
			border-radius: 3px 0 0 3px;
			left: auto;
			}
		.prev {
            left: 5px;
            border-radius: 0 3px 3px 0;
            right: auto;
        }	
		.prev:hover, .next:hover {
			background-color: rgba(0,0,0,0.8);
			}
			.fade {
			animation-name: fade;
			animation-duration: 1.5s;
			}
		@keyframes fade {
			from {opacity: .4}
			to {opacity: 1}
				}
		.description {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 5px;
            margin-top: 20px;
        }
        .features {
            background-color: #f3f3f3;
            padding: 20px;
            border-radius: 5px;
            margin-top: 20px;
        }
       
		
    </style>
</head>
<body>
<?php
session_start();
// Check if the user is logged in
$isLoggedIn = isset($_SESSION['id']);

echo $isLoggedIn;
// Initialize the user ID variable
$userId = null;

// Get the logged-in user's ID if available
if ($isLoggedIn) {
    $userId = $_SESSION['id'];
}

?>

<?php
// Use the appropriate header template based on login status
if ($isLoggedIn) {
    // User is logged in, use template_header2
	include ('login/function.php');
	include ('function.php');
    echo template_header2('Home');
} else {
    // User is not logged in, use default template_header
	include ('function.php');
    echo template_header('Home');
}
?>
	<section>
    <div class="product-details">
	<br><br><br><br><br><br><br>
        <h1>Haier 75 Inch HQ LED Google TV - H75P750UX</h1>
		<div><?php include('slider/slider3.php');?></div>
		
	<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
	<a class="next" onclick="plusSlides(1)">&#10095;</a>
	
	</div>
        
  
        <h2>Price: RM 4499.00</h2>
		
		<div class="description">
        <h2>Description</h2>
		<p>Immerse yourself in stunning visuals with the Haier 75 Inch HQ LED Google TV. This smart TV combines a large 75-inch screen with HQ LED technology for vivid colors and sharp details. With Google TV, you have access to a wide range of apps and streaming services.</p>
        </div>
		
		<div class="features">
		<h2>Features</h2>
            <ul>
                <li>75-inch HQ LED display</li>
                <li>Google TV for easy content discovery</li>
                <li>High-quality sound with Dolby Audio</li>
                <li>Voice remote with Google Assistant</li>
                <li>Multiple HDMI and USB ports</li>
            </ul>
        </div>
		<br>
		<center>
		<img src="image/haier4.WEBP">
		<img src="image/haier5.WEBP">
		<img src="image/haier6.WEBP">

		</center>
		
		<script>
		let slideIndex = 1;
		showSlides(slideIndex);

// Next/previous controls
		function plusSlides(n) {
			showSlides(slideIndex += n);
		}

// Thumbnail image controls
		function currentSlide(n) {
			showSlides(slideIndex = n);
		}

		function showSlides(n) {
		let i;
		let slides = document.getElementsByClassName("mySlides");

		if (n > slides.length) {slideIndex = 1}
		if (n < 1) {slideIndex = slides.length}
		for (i = 0; i < slides.length; i++) {
			slides[i].style.display = "none";
		}
 
		slides[slideIndex-1].style.display = "block";
		}
		</script>
		</div>
		</section>
        <<p><a href="index.php?page=product&id=3">Back to Product Listing</a></p>
   </body>
<?php template_footer();?>
</html>
