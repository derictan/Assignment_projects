<!DOCTYPE html>
<html>
  <head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel = "stylesheet" href="style/myStyle02.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  </head>
  <body>
<?php

// Check if the user is logged in
$isLoggedIn = isset($_SESSION['id']);

echo $isLoggedIn;
// Initialize the user ID variable
$userId = null;

// Get the logged-in user's ID if available
if ($isLoggedIn) {
    $userId = $_SESSION['id'];
}
?>

<?php
// Use the appropriate header template based on login status
if ($isLoggedIn) {
	include 'login/function.php';
    // User is logged in, use template_header2
    echo template_header2('Home');
} else {
    // User is not logged in, use default template_header
    echo template_header('Home');
}
?>
    <section class = "contact-section">
      <div class = "contact-bg">
        <h3>Get in Touch with Us</h3>
        <h2>contact us</h2>
        <div class = "line">
          <div></div>
          <div></div>
          <div></div>
        </div>
        <p class = "text">We value your feedback and welcome any suggestions 
		you may have to improve our products, services or website. Let us 
		know how we're doing and how we can serve you better.</p>
      </div>


      <div class = "contact-body">
        <div class = "contact-info">
          <div>
            <span><i class="fa fa-phone-volume"></i></span>
            <span>Phone No.</span>
            <span class = "text">012-1234567</span>
          </div>
          <div>
            <span><i class="fa fa-envelope"></i></i></span>
            <span>E-mail</span>
            <span class = "text">suanq@gmail.com</span>
          </div>
          <div>
            <span><i class="fa fa-map"></i></span>
            <span>Address</span>
            <span class = "text">UTAR Sungai Long Campus Jalan Sungai Long, Bandar Sungai Long Cheras 43000, Kajang, Selangor</span>
          </div>
          <div>
            <span><i class="fa fa-clock"></i></span>
            <span>Opening Hours</span>
            <span class = "text">Monday - Friday (9:00 AM to 5:00 PM)
			<br>Saturday & Sunday (9.00 AM to 1.00 PM)</span>
          </div>
        </div>
		

<?php
$servername ="localhost";
$username = "root";
$password = "";
$dbname ="cart";

$conn = new mysqli($servername,$username, $password,$dbname);

if($conn -> connect_error){
	die("Connection failed: " .$conn->connect_error);
}

$sql = "CREATE TABLE IF NOT EXISTS contactusform (
    id INT AUTO_INCREMENT PRIMARY KEY,
    firstName VARCHAR(255) NOT NULL,
    lastName VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    posted TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

// Execute the query
if ($conn->query($sql) === TRUE) {
    echo "Table contactusform created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

function createContactusform($conn, $firstName,$lastName,$email,$phone,$message){
	$sql = $conn->prepare("INSERT INTO contactusform(firstName, lastName, email, phone, message,posted)VALUES(?,?,?,?,?,NOW())");
	$sql -> bind_param("sssss",$firstName,$lastName,$email,$phone,$message);
	if($sql->execute()){
		echo "New contactUsForm created successfully<br>";
	}else{
		echo "Error: " .$sql->error;
	}
}

function updateContactusform($conn,$id, $firstName,$lastName,$email,$phone,$message){
	$sql = $conn->prepare("UPDATE contactusform SET firstName =?, lastName=?, email=?, phone=?, message=? WHERE id =?");
	$sql->bind_param("sssssi",$firstName,$lastName,$email,$phone,$message,$id);
	if($sql->execute()){
		echo"contactusform updated successfully <br>";
	}else{
		echo"Error: ".$sql->error;
	}
}

function deleteContactusform($conn, $id){
	$sql = $conn-> prepare("DELETE FROM contactusform WHERE id =?");
	$sql ->bind_param("i",$id);
	if($sql->execute()){
		echo "contactusform deleted successfully<br>";
	}else{
		echo "Error: " .$sql->error;
}}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $submitType = $_POST['submit'] ?? '';
    $firstName = $_POST['firstName'] ?? '';
    $lastName = $_POST['lastName'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $message = $_POST['message'] ?? '';

    switch ($submitType) {
        case 'send message':
            createContactusform($conn, $firstName, $lastName, $email, $phone, $message);
            break;
        // Add cases for update and delete if needed
    }
}

?>
        <div class = "contact-form">
          <form method ="post">
            <div>
			  <input type = "text" id = "firstName" name = "firstName" class = "form-control" placeholder = "First Name" required >
			  <input type = "text" id = "lastName" name = "lastName" class = "form-control" placeholder = "Last Name" required >
            </div>
            <div>
			  <input type = "email" id = "email" name = "email" class = "form-control" placeholder = "E-mail" required>
			  <input type = "tel" id = "phone" name = "phone" pattern = "[0-9]{3}-[0-9]{7}" class = "form-control" placeholder = "Phone" required>
            </div>
			<textarea id="message" name="message" rows="5" placeholder="Message" class = "form-control" required></textarea>
            <input type = "submit" name ="submit" class = "send-btn" value = "send message">
          </form>
          <div>
			<img src = "picture/ContactUs.jpg" alt ="">
          </div>
        </div>
      </div>
      <div id = "map", class = "map">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3984.204958249872!2d101.79166137567603!3d3.039649653814553!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cc34a5f21a8235%3A0x78796ffc32ce3fcd!2sUniversiti%20Tunku%20Abdul%20Rahman%20(UTAR)!5e0!3m2!1sen!2smy!4v1711213284305!5m2!1sen!2smy" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
      </div>

    </section>

    

  </body>
  <?php template_footer();?>
</html>