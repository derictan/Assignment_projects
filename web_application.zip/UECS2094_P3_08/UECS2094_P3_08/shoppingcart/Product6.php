<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sony HT-S2000 3.1ch Dolby Atmos Soundbar - HTS2000</title>
    <style>
        /* Basic styling for demonstration purposes */
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .product-img {
            max-width: 100%;
            height: auto;
        }
        .product-details {
            margin-top: 20px;
        }
		.slideshow-container {
			max-width: 1000px;
			position: relative;
			margin: auto;
		}
		.mySlides{
			display: none;
		}
		.prev, .next {
			cursor: pointer;
			position: absolute;
			top: 50%;
			width: auto;
			margin-top: -22px;
			padding: 16px;
			color: white;
			font-weight: bold;
			font-size: 18px;
			transition: 0.6s ease;
			border-radius: 0 3px 3px 0;
			user-select: none;
			}
        .next {
			right: 400px;
			border-radius: 3px 0 0 3px;
			left: auto;
			}
		.prev {
            left: 5px;
            border-radius: 0 3px 3px 0;
            right: auto;
        }
		.prev:hover, .next:hover {
			background-color: rgba(0,0,0,0.8);
			}
			.fade {
			animation-name: fade;
			animation-duration: 1.5s;
			}
		@keyframes fade {
			from {opacity: .4}
			to {opacity: 1}
				}
		.description {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 5px;
            margin-top: 20px;
        }
        .features {
            background-color: #f3f3f3;
            padding: 20px;
            border-radius: 5px;
            margin-top: 20px;
        }
       
		table{
			border-collapse: collapse;
			width: 100%;
			background-color: white;
			margin-top: 20px;
		}
		td{
			border:0;
			padding:8px;
			text-align: center;
		}
		.table-img{
			max-width:500px;
			height: auto;
			border-radius: 5px;
			transition: transform 0.3s ease;
		}
		img:hover{
			transform: scale(1.1);
		}
    </style>
</head>
<body>
<?php
session_start();
// Check if the user is logged in
$isLoggedIn = isset($_SESSION['id']);

echo $isLoggedIn;
// Initialize the user ID variable
$userId = null;

// Get the logged-in user's ID if available
if ($isLoggedIn) {
    $userId = $_SESSION['id'];
}

?>

<?php
// Use the appropriate header template based on login status
if ($isLoggedIn) {
    // User is logged in, use template_header2
	include ('login/function.php');
	include ('function.php');
    echo template_header2('Home');
} else {
    // User is not logged in, use default template_header
	include ('function.php');
    echo template_header('Home');
}
?>
<section>
    <div class="product-details">
	<br><br><br><br><br><br><br>
        <h1>Sony HT-S2000 3.1ch Dolby Atmos Soundbar - HTS2000</h1>
		<div><?php include('slider/slider6.php');?></div>
	<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
	<a class="next" onclick="plusSlides(1)">&#10095;</a>
	
	</div>
        <h2>Price: RM 2049.00</h2>
        <div class="description">
		<h2>Description</h2>
		<p>Bring cinema-quality sound to your living room with the Sony HT-S2000 3.1ch Dolby Atmos Soundbar. This soundbar system delivers powerful audio with 3.1 channels and Dolby Atmos support. With easy wireless connectivity and a compact design, it fits seamlessly into any home entertainment setup.</p>
        </div>
		<div class="features">
		<h2>Features</h2>
            <ul>
                <li>3.1 channel soundbar system</li>
                <li>Dolby Atmos and DTS:X support</li>
                <li>Wireless subwoofer for deep bass</li>
                <li>Bluetooth and NFC connectivity</li>
                <li>Virtual Surround Sound technology</li>
            </ul>
    
		</div>
		<table>
		<tr>
			<td><img src="image/image18.png" alt="1" class ="table-img"></td>
			<td><img src="image/image19.png" alt="2" class ="table-img"></td>
			<td><img src="image/image20.png" alt="3" class ="table-img"></td>
		
		</tr>
		<tr>
			<td><img src="image/image21.png" alt="1" class ="table-img"></td>
			<td><img src="image/image22.png" alt="2" class ="table-img"></td>
			<td><img src="image/image23.png" alt="3" class ="table-img"></td>
		
		</tr>
		<tr>
			<td><img src="image/image24.png" alt="1" class ="table-img"></td>
			<td><img src="image/image25.png" alt="2" class ="table-img"></td>
			<td><img src="image/image26.png" alt="3" class ="table-img"></td>
		
		</tr>
		</table>
		<script>
		let slideIndex = 1;
		showSlides(slideIndex);

// Next/previous controls
		function plusSlides(n) {
			showSlides(slideIndex += n);
		}

// Thumbnail image controls
		function currentSlide(n) {
			showSlides(slideIndex = n);
		}

		function showSlides(n) {
		let i;
		let slides = document.getElementsByClassName("mySlides");

		if (n > slides.length) {slideIndex = 1}
		if (n < 1) {slideIndex = slides.length}
		for (i = 0; i < slides.length; i++) {
			slides[i].style.display = "none";
		}
 
		slides[slideIndex-1].style.display = "block";
		}
		</script>
		</section>
        <<p><a href="index.php?page=product&id=6">Back to Product Listing</a></p>
    </div>
</body>
<?php template_footer();?>
</html>
