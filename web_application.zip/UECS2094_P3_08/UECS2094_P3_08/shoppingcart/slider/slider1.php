<!DOCTYPE html>
<html>
<head>
<title>IMAGE Slider1</title>
<link rel="stylesheet" href="styles9.css">
</head>
<body>
<div class ="container">
	<div class = "slider">
		<div class = "slides">
			
			<input type = "radio" name="radio-btn" id ="radio1"width="500" height="250">
			<input type = "radio" name="radio-btn" id ="radio2"width="500" height="250">
			<input type = "radio" name="radio-btn" id ="radio3"width="500" height="250">
			
			<div class = "slide first">
				<img src ="image/samsung981.WEBP" alt="pic1" >
			</div>
			<div class = "slide">
				<img src ="image/samsung983.WEBP" alt="pic2" >
			</div>
			<div class = "slide">
				<img src ="image/samsung982.WEBP" alt="pic2" >
			</div>
			<div class = "navigation-auto">
				<div class ="auto-btn1"></div>
				<div class ="auto-btn2"></div>
				<div class ="auto-btn3"></div>
			</div>
			
			
		</div>
		
		<div class="navigation-manual">
			<label for="radio1" class="manual-btn"></label>
			<label for="radio2" class="manual-btn"></label>
			<label for="radio3" class="manual-btn"></label>
		</div>
		
	</div>
</div>	
	<script type ="text/javascript">
	var counter = 1;
	setInterval(function(){
		document.getElementById('radio' + counter).checked=true;
		counter ++;
		if(counter>3){
			counter =1;
		}
	},5000);
	</script>

</body>
</html>