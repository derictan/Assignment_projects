<!DOCTYPE html>
<html lang = "en">
<head>
	<meta charset = "UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="styles2.css">
	<title>Shuan Q</title>
	
</head>


<footer >
		<div class = "row">
			<div class = "col">
				<img src="SUANQ.png" alt="Your Logo" class="logo" width="120" height="100">
			</div>
			<div class="col">
				<h3> General Info</h3>
				<p><a href = "#">About Us</a></p>
				<p><a href = "#">Contact Us</a></p>
				<p><a href = "#">Locate Us</a></p>
				<p><a href = "#">FaQ</a></p>
			</div>
			<div class="col">
				<h3>We accept</h3>
				<img src="pic1.png" alt="payment" class="logo" width="100" height="50">
				<br>
				<h3>Available Installment</h3>
			</div>
		</div>
		<hr>
		<p> &copy; 2022 SUANQ ELECTRIC (UTAR) SDN. BHD. 505454554 (5487-X) ALL RIGHT'S RESERVED</p>
</footer>