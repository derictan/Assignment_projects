<?php
	session_start();
	header('Location:../home.php?variable=' . $_SESSION['id']);
?>
