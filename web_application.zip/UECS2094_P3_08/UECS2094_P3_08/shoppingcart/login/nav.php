<!DOCTYPE html>
<html lang = "en">
<head>
<meta charset = "UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="styles2.css">
	<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
	<title>Shuan Q</title>
	
</head>

<body>
<div class = "navbar">
	<div class = "menu-bar">
		<ul>
			<li><a href ="#">Shop By Category</a>
			<ul class = "sub-menu">
					<li><a href = "#">Kitchen Appliances</a>
							<ul class="sub-sub-menu">
								<li><a href="#">Sub-submenu Item 1 </a></li>
								<li><a href="#">Sub-submenu Item 2 </a></li>
							</ul>
					</li>
					<li><a href = "#">Home Electronics</a></li>
			</ul>
			</li>
			<li><a href ="#">Brand Stores</a></li>
			<li><a href = "#">SPECIAL DEALS</a></li>
			<li><a href = "#">About Us</a></li>
			<li><a href = "#">Contact Us</a></li>
						
		</ul>
	</div>
	</div>
</body>
</html>

