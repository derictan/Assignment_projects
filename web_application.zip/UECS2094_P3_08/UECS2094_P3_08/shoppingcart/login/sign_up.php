<?php
session_start();
	include("connection.php");
	include("function.php");

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		
		$user_name = mysqli_real_escape_string($conn, $_POST['username']);
		$password = mysqli_real_escape_string($conn, $_POST['password']);
		
		$checkQuery = "SELECT * FROM users WHERE username = '$user_name'";
		$checkResult = mysqli_query($conn, $checkQuery);
		
		if(mysqli_num_rows($checkResult)>0){
			$username_error = 'Username already exists. Please use a different username.';
		}else{
			$hashed_password=md5($password);
			$query = "INSERT INTO users(username,password) VALUES('$user_name','$hashed_password')";
			
			if(mysqli_query($conn,$query)){
				$message = 'Account created successfully';
			}else{
				$message = 'Please enter some valid information!';
			}
		}
	}
		
?>


<!DOCTYPE html>
<html>
<head>
	<title>Signup</title>
</head>
<body>
	<style type ="text/css">
	#text{
		height:25px;
		border-radius: 5px;
		padding :4px;
		border: solid this #aaa;
		width:100%;
		
	}
	
	#button{
		padding:10px;
		width: 100%;
		color: white;
		background-color: #d32026;
		border: none;
		border-radius: 5px;
	}
	
	#box{
		background-color: white;
		margin: auto;
		width:500px;
		height:550px;
		padding: 20px;
	}
	
	table{
		width:100%;
		padding:100px 80px;
	}
	
	label {
		text-align: left;
	}
	</style>

	<?php include('../function.php');?>
	<?php template_header('Account');?>

<br>
<br>
<br>
<br>
<div>

<style>
    .error {
		margin: 0;
        color: red;
        font-size: 14px;
        text-align: left;
    }
</style>

	<table>
	<tr>
	<th><img src="Login1.png" alt="Login pic" height ="600px"> </th>
	<th>
	<div id = "box">
		<form method = "post">
		<img src="SUANQ.png" alt="Login pic" width="150px" height ="100px"> 
			<div style ="font-size: 20px; margin:10px;color:black;">Signup</div>
			<label for="username">Username:</label>
			<input id ="text" type="text" name ="username" required>
			<?php if (isset($username_error)) echo "<span class='error'>$username_error</span>"; ?><br><br>
			
			<label for="password">Password:</label>
			<input id ="text" type="password" name ="password" required><br><br>
			<input id="button" type="submit" value ="Signup"><br><br>
			
		<?php
			if (!empty($message) && $message === 'Account created successfully') {
			echo 'Congrats!Account created successfully! ';
			echo '<a href="../account.php">Login here</a>';
			}
		?>
	</div>
</th>
</tr>
</table>	
</div>
	
			
</body>
<?php template_footer();?>
</html>