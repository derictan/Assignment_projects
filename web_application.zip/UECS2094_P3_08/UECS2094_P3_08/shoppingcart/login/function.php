<?php

function check_login($conn)
{
	if(isset($_SESSION['id']))
	{
			
		$id = $_SESSION['id'];
		$query = "select * from users where id = '$id' limit 1 ";
		
		$result = mysqli_query($conn, $query);
		if($result && mysqli_num_rows($result)>0)
		{
			$user_data = mysqli_fetch_assoc($result);
			return $user_data;
		}
	}
	
	//redirect to login
	header("Location: account.php");
	die;


}

function template_header2($title) {
    // Get the number of items in the shopping cart
    $num_items_in_cart = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;

    echo <<<EOT
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>$title</title>
    <link rel="stylesheet" href="styles2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
</head>
<body>
    <header>
        <div class="navbar">
            <a href="login/index.php">
                <img src="SUANQ.png" alt="Your Logo" class="logo" width="120" height="100">
            </a>
            <ul>
                <li><i class='bx bx-cart'></i><a href="index.php?page=cart">Cart</a></li>
                <li><i class='bx bx-user'></i><a id="logoutLink" href ="login/logout.php">Log Out</a>
            </ul>
        </div>
<div class="navbar">
            <div class="menu-bar">
                <ul>
                    <li><a href="index.php?page=products">Products</a></li>
                    <li><a href="index.php?page=category">Shop By Category</a></li>
                    <li><a href="index.php?page=aboutUs">About Us</a></li>
                    <li><a href="index.php?page=contactUs">Contact Us</a></li>
					<li><a href="index.php?page=FAQ">FAQ</a></li>
                </ul>
            </div>
        </div>
    </header>
    <main>
EOT;
}
?>