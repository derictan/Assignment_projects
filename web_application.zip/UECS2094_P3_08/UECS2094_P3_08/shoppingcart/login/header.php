<!DOCTYPE html>
<html lang = "en">
<head>
<meta charset = "UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="styles2.css">
	<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
	<title>Shuan Q</title>
</head>

<body>
	<div class = "navbar">
		
		<img src="SUANQ.png" alt="Your Logo" class="logo" width="120" height="100">
		
		<ul>
			<li><i class='bx bx-cart'></i><a href ="#">Cart</a>
			</li>
			<li><i class='bx bx-user'></i><a href ="login/account.php">Log In/Sign Up</a>
					
		</ul>
	</div>
</body>
</html>