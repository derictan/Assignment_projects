<?php
$dbHost = "localhost";
$dbUser = "root";
$dbPassword = null;
$dbName = "cart";

if(!$conn = mysqli_connect($dbHost,$dbUser, $dbPassword, $dbName))
{
	die("Failed to connect");
}
?>