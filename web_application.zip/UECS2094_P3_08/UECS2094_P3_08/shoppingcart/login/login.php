<?php

	include("connection.php");
	session_start();
	if($_SERVER['REQUEST_METHOD']=="POST")
	{
		//somthing was posted
		$user_name = $_POST['username'];
		$password = $_POST['password'];
		
		if(!empty($user_name)&&!empty($password)&& !is_numeric($user_name))
		{
			//read from database
			$query ="SELECT * FROM users WHERE username ='$user_name' AND password='" .md5($password) . "'";
			
			//Execute the query
			$result = mysqli_query($conn, $query);
			
			if($result)
			{
				//check if there was a match
				if(mysqli_num_rows($result)===1){
					$user_data = mysqli_fetch_assoc($result);
					$_SESSION['id'] = $user_data['id'];
					header("Location:login/index.php");
					die;

				}else{
					$error = 'Invalid username or password.';
				}
			}
		}
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
	<style type ="text/css">
	
	#text{
		height:25px;
		border-radius: 5px;
		padding :4px;
		border: solid this #aaa;
		width:100%;
		
	}
	
	#button{
		padding:10px;
		width: 100%;
		color: white;
		background-color: #d32026;
		border: none;
		border-radius: 5px;
	}
	
	#box{
		background-color: white;
		margin: auto;
		width:500px;
		height:550px;
		padding: 20px;
	}
	
	table{
		width:100%;
		padding:100px 80px;
	}
	
	label {
		text-align: left;
	}
	</style>
	
	<br><br><br><br>
	<table>
	<tr>
	<th><img src="Login1.png" alt="Login pic" height ="600px"> </th>
	<th>
	<div id = "box">
		<form method = "post">
			<img src="SUANQ.png" alt="Login pic" width="150px" height ="100px"> 
			<div style ="font-size: 30px; margin:10px;color:black;">LOGIN</div>
			<label for="username">Username:</label>
			<input id ="text" type="text" name ="username" required><br><br>
			<label for="password">Password:</label>
			<input id ="text" type="password" name ="password" required><br><br>
			<input id="button" type="submit" value ="Login"><br><br>
			<a href ="login/sign_up.php">Signup</a><br><br>
	</div>
</th>
</tr>
</table>	
</body>
</html>