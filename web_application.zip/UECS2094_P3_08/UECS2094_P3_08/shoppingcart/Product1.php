<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Samsung 98 inch Q80CA QLED 4K TV</title>
    <style>
        /* Basic styling for demonstration purposes */
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .product-img {
            max-width: 100%;
            height: auto;
        }
        .swiper-container {
            width: 100%;
            height: 100%;
			margin-bottom: 20px;
        }
        .swiper-slide img {
            width: 30%;
            height: auto;
        }
		        
		.table1{
			border-collapse: collapse;
			width: 100%;
			background-color: black;
			margin-top: 20px;
		}
		.table1 td{
			border:0;
			padding:8px;
			text-align: center;
		}
		.table-img{
			max-width:200px;
			height: auto;
			border-radius: 5px;
			transition: transform 0.3s ease;
		}
		img:hover{
			transform: scale(1.1);
		}
		.header-row {
            background-color: #333;
            color: white;
        }
        .header-row td {
            padding: 20px;
            font-weight: bold;
        }
		.header-row:hover {
            background-color: #555;
			transform: scale(1.1);
        }
        .description {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 5px;
            margin-top: 20px;
        }
        .features {
            background-color: #f3f3f3;
            padding: 20px;
            border-radius: 5px;
            margin-top: 20px;
        }
    </style>
    
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">
</head>
<body>
<?php
session_start();
// Check if the user is logged in
$isLoggedIn = isset($_SESSION['id']);

echo $isLoggedIn;
// Initialize the user ID variable
$userId = null;

// Get the logged-in user's ID if available
if ($isLoggedIn) {
    $userId = $_SESSION['id'];
}

?>

<?php
// Use the appropriate header template based on login status
if ($isLoggedIn) {
    // User is logged in, use template_header2
	include ('login/function.php');
	include ('function.php');
    echo template_header2('Home');
} else {
    // User is not logged in, use default template_header
	include ('function.php');
    echo template_header('Home');
}
?>
    <div class="product-details">
	<br><br><br><br><br><br><br><br>
    <h1>Samsung 98 inch Q80CA QLED 4K TV</h1>
     <div><?php include('slider/slider1.php');?></div>
    <div class="swiper-pagination"></div>
    </div>

    <h2>Price: RM 29999.00</h2>
	<div class="description">
    <h2>Description</h2>
	<p>Punch up the contrast with super-precise LEDs and elevate the ordinary to something more impressive. Direct Full Array and Dolby Atmos technology headline Samsung QLED’s refined audio/visual experience. Not to mention the instant transformation to vivid 4K resolution completed by the powerful Quantum Processor.</p>
	</div>
	
	<table class="table1">
		
		<tr class="header-row">
                <td colspan="4">Top 4 Features</td>
				</tr>
		<tr>
			<td><img src="image/image1.png" alt="1" class ="table-img"></td>
			<td><img src="image/image2.png" alt="2" class ="table-img"></td>
			<td><img src="image/image3.png" alt="3" class ="table-img"></td>
			<td><img src="image/image4.png" alt="4" class ="table-img"></td>
		</tr>
		</table>
    <div class="features">
	<h2>Features</h2>
        <ul>
            <li>Neural Quantum Processor 4K</li>
            <li>Supersize Picture Enhancer</li>
            <li>SuperSlim Design</li>
            <li>Smart Hub Streaming Movies and Games</li>
        </ul>
   </div>
	<table>
		<tr>
			<td><img src="image/samsung984.WEBP" ></td>
			<td><p><b>Supersize your entertainment</b></p>
				<p>Punch up the contrast with super-precise LEDs and elevate the ordinary to something more impressive. Direct Full Array and Dolby Atmos technology headline Samsung QLED’s refined audio/visual experience. Not to mention the instant transformation to vivid 4K resolution completed by the powerful Quantum Processor.</p>
			</td>
			</tr>
		<tr>
			<td>
			<h1>It's lit</h1>
			<p><b>DIRECT FULL ARRAY</b></p>
			<p>See incredible contrast even in sunlit rooms with our Direct Full Array technology that precisely controls the amount of lighting across every part of the picture. When you see, you know. Get caught up in the details as you experience the silver screen in a new way as the picture comes alive from your screen.</p>
			<td><img src="image/samsung985.WEBP" ></td>
			</tr>
		<tr>
			<td><img src="image/samsung986.WEBP" ></td>
			<td>
			<h1>Game all day</h1>
			<p><b>SAMSUNG GAMING HUB</b></p>
			<p>Widen your world of gaming instantly without a console. Gaming Hub is where gaming comes together–bringing the best of console games, streaming games and more–all in one place. With easier access to your favorite games, standalone apps and accessories–start playing faster than ever.</p>
		</tr>
		<tr>
			<td>
			<h1>A greener future</h1>
			<p><b>SOLARCELL REMOTE™</b></p>
			<p>Turn up the volume on sustainability with the innovative SolarCell Remote™. It features a solar panel for charging, as well as other smart features including a built-in microphone to use with your favorite voice assistant.</p>
			<td><img src="image/samsung985.WEBP" ></td>
			</tr>
	</table>
	<p><a href="index.php?page=product&id=1">Back to Product Listing</a></p>
</div>	

<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script>
    var swiper = new Swiper('.swiper-container', {
        loop: true,
        autoplay: {
            delay: 5000, 
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
    });
</script>
</body>
<?php template_footer();?>
</html>
