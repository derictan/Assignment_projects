<?php
$servername = "localhost";
$username = "root";
$password = null;

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else{
	
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = null;
$database = "cart";

// Check if the database exists
$sql = "SHOW DATABASES LIKE '$database'";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    // Database does not exist, so create it
    $create_database_sql = "CREATE DATABASE $database";
    if ($conn->query($create_database_sql) === TRUE) {
        echo "Database created successfully";
    } else {
        echo "Error creating database: " . $conn->error;
    }
} else {
    echo "Database '$database' already exists";
}


// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// SQL query to create the users table
$sql = "CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL
)";

// Execute SQL query
if ($conn->query($sql) === TRUE) {
    echo "Table users created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}


$sql = "CREATE TABLE IF NOT EXISTS usercart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT(100) NOT NULL,
    product_id INT(100) NOT NULL,
	quantity INT(100) NOT NULL
)";

if ($conn->query($sql) === TRUE) {
    echo "Table users created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

// SQL query to drop the users table if it exists
$conn->query("DROP TABLE IF EXISTS products");

// SQL query to create the users table
$sql_create_table = "CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    rrp DECIMAL(10, 2) NOT NULL,
    quantity INT NOT NULL,
    img VARCHAR(255) NOT NULL,
    date_added DATE NOT NULL,
    category VARCHAR(50) NOT NULL
);";

// Execute SQL query to create table
if ($conn->query($sql_create_table) === TRUE) {
    echo "Table created successfully<br>";
} else {
    echo "Error creating table: " . $conn->error . "<br>";
}

// SQL query to insert data into the products table
$sql_insert_data = "INSERT INTO products (name, description, price, rrp, quantity, img, date_added, category) 
        VALUES 
        ('Samsung 98 inch Q80CA QLED 4K TV', '<ul><li>Direct Full Array</li><li>Neural Quantum Processor 4K</li><li>Real Depth Enhancer Smart Hub</li></ul>', 29999.00, 0.00, 100, 'samsung98.WEBP', NOW(), 'TV'),
        ('LG 77 inch OLED evo G3 Gallery Edition 4K UHD Smart TV (2023)', '<ul><li>Advanced picture and functionality with the α9 AI Processor 4K Gen6</li><li>Bright, bold visuals of Brightness Booster Max</li><li>Flush fit with One Wall Design\'s nearly zero gap wall mount *Stand sold separately</li><li>Smart Functionality, including ThinQ AI, WebOS, and Hands-Free Voice Recognition</li><li>Immersive entertainment with Dolby Atmos & Vision, VRR, G-sync, and Freesync</li></ul>', 25999.00, 0.00, 150, 'lg77.WEBP', NOW(), 'TV'),
        ('Haier 75 Inch HQ LED Google TV - H75P750UX', '<ul><li>HQLED</li><li>Dolby Vision & Dolby Audio</li><li>Google TV</li><li>4K HDR</li><li>Bezel-Less</li></ul>', 4499.00, 0.00, 200, 'haier.WEBP', NOW(), 'TV'),
        ('Samsung 65 Inch QLED 4K TV Q70CA', '<ul><li>Quantum Processor 4K</li><li>Motion Xcelerator Turbo+</li><li>Quantum HDR</li><li>Smart Hub</li></ul>', 4999.99, 0.00, 200, 'samsung65.WEBP', NOW(), 'TV'),
        ('Sony 7.1.2ch Dolby Atmos®/ DTS:X® Soundbar SNY-HTA7000', '<ul><li>Multi-dimensional sound</li><li>Immerse audio enhancement</li><li>Wireless connectivity</li><li>Built-in subwoofer</li><li>Dolby Atmos & DTS:X support</li><li>4K HDR pass-through</li><li>Wi-Fi/Bluetooth streaming</li></ul>', 5099.00, 0.00, 100, 'product1.WEBP', NOW(), 'SB'),
        ('Sony HT-S2000 3.1ch Dolby Atmos Soundbar - HTS2000', '<ul><li>3.1ch Dolby Atmos Soundbar</li><li>Compact and powerful sound</li><li>Dolby Atmos & DTS:X support</li><li>4K HDR pass-through</li><li>Bluetooth streaming</li></ul>', 2049.00, 0.00, 100, 'product2.WEBP', NOW(), 'SB'),
        ('LG 420W Soundbar LG-SP8A', '<ul><li>420W Soundbar</li><li>Dolby Atmos & DTS:X</li><li>Hi-Res Audio</li><li>AI Sound Pro</li><li>Wireless Subwoofer</li><li>Bluetooth Streaming</li></ul>', 1799.00, 0.00, 100, 'product3.WEBP', NOW(), 'SB'),
        ('Sony 3.1ch Dolby Atmos® DTS:X™ Soundbar HT-G700', '<ul><li>3.1ch Dolby Atmos® DTS:X™ Soundbar</li><li>Immersive Audio Enhancement</li><li>7.1.2ch Virtual Surround</li><li>4K HDR pass-through</li><li>Bluetooth Streaming</li></ul>', 1949.00, 0.00, 100, 'product4.WEBP', NOW(), 'SB'),
        ('ACER Predator Helios Neo 16 PHN16-71-778U', '<ul><li>NVIDIA® GeForce RTX™ 4050 with 6GB of dedicated GDDR6 VRAM</li><li>Windows 11 Home<br>Intel® Core™ i7-13700HX</li><li>16 WUXGA IPS SlimBezel 165Hz</li><li>16 GB DDR5 4800Mhz Memory ; 1TB PCIe NVMe Gen 4 SSD</li><li>4-Zone RGB Keyboard</li><li>Warranty : 2 Years Onsite Warranty + Accidental Damage / Theft Warranty</li></ul>', 5499.00, 0.00, 100, 'ACER.WEBP', NOW(), 'LT'),
        ('HP Victus Gaming Laptop 15-FA1120TX', '<ul><li>AMD Ryzen™ 7 6800H processor</li><li>16GB DDR5 RAM</li><li>512GB PCIe NVMe M.2 SSD</li><li>NVIDIA® GeForce RTX™ 3050 Ti (4GB GDDR6 dedicated)</li><li>15.6 diagonal, FHD (1920 x 1080), IPS, micro-edge, anti-glare, 144 Hz</li><li>RGB Backlit Keyboard</li></ul>', 3399.00, 0.00, 100, 'HP.WEBP', NOW(), 'LT'),
        ('HP Victus Gaming Laptop 15-FA1121TX', '<ul><li>AMD Ryzen™ 5 6600H processor</li><li>8GB DDR5 RAM</li><li>512GB PCIe NVMe M.2 SSD</li><li>NVIDIA® GeForce RTX™ 3050 (4GB GDDR6 dedicated)</li><li>15.6 diagonal, FHD (1920 x 1080), IPS, micro-edge, anti-glare, 144 Hz</li><li>RGB Backlit Keyboard</li></ul>', 3399.00, 0.00, 199, 'HP2.WEBP', NOW(), 'LT'),
        ('ASUS TUF Gaming F15 FX506H-EHN062W', '<ul><li>Intel® Core™ i5-11400H Processor</li><li>8GB DDR4 RAM</li><li>512GB M.2 NVMe™ PCIe® 3.0 SSD</li><li>NVIDIA® GeForce RTX™ 3050 4GB GDDR6</li><li>15.6 FHD (1920 x 1080) IPS-level panel, 144Hz</li><li>RGB Keyboard</li></ul>', 3699.00, 0.00, 110, 'ASUS.WEBP', NOW(), 'LT')";

// Execute SQL query to insert data
if ($conn->multi_query($sql_insert_data) === TRUE) {
    echo "Records inserted successfully";
} else {
    echo "Error inserting records: " . $conn->error;
}


// Close connection
$conn->close();
	
	
}

?>
