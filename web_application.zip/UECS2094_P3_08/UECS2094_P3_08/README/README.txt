#SuanQ Electronics

SuanQ is launching an online platform, offering a curated selection of the latest digital gadgets and accessories. From smartphones and tablets to wearable tech and drones, SuanQ has developed a premier destination to establish a reputation for digital gadget enthusiasts.

##Features
- Product browsing: Users can view a list of available products and search for specific items with detailed descriptions.

- User authentication: Users can sign up, log in, and log out. Log-in is mandatory for users to purchase items.

- Shopping cart: Users can add or remove products to their shopping cart and view the items they've added. Subtotal costs for items purchased by users will be displayed.

- Checkout process: Users can proceed to checkout, enter shipping address and payment information, and complete their purchase.

- Contact Us: Users can contact the store for inquiries or support.

- About Us: Users can learn more about the store and its mission.

##Installation
To access the SuanQ Electronics online platform, follow these steps:

1. Download the zip file

2. Extract the file and copy shoppingcart folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Navigate to the project directory: 

5.Import the database:
- Access phpMyAdmin in your web browser.
- Create a new database named `cart`.

6.Start the local development server:

7.Access the application in your web browser at:
- Platform_URL=http://localhost/shoppingcart/index.php

##Technologies Used
- Front-end: HTML, CSS, JavaScript
- Back-end: PHP, MySQL, phpMyAdmin 

##License

To the extent possible under law, the founder of SuanQ, Nickson has waived all copyright and related or neighboring rights to this work.

